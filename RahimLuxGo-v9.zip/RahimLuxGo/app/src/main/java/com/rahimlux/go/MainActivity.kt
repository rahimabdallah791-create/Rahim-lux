package com.rahimlux.go

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private val homeHost = "home.rahimlux.go"
    private val home = "https://$homeHost/"
    private val accent = Color.parseColor("#FFB300")

    private val brand = mapOf(
        "Google" to "#4285F4", "YouTube" to "#FF0000", "Facebook" to "#1877F2",
        "Instagram" to "#E1306C", "WhatsApp" to "#25D366", "TikTok" to "#222222",
        "Wikipedia" to "#636466", "Mwananchi" to "#E53935"
    )
    private val palette = listOf("#FF7043", "#26A69A", "#5C6BC0", "#AB47BC", "#EC407A", "#29B6F6", "#9CCC65", "#FFA726")

    private lateinit var store: Store
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var tabsCount: TextView
    private val tabs = mutableListOf<WebView>()
    private var cur = 0
    private var fullUrl = ""
    private val web get() = tabs[cur]
    private var pendingDl: (() -> Unit)? = null
    private lateinit var adBox: FrameLayout
    private lateinit var adView: AdView
    private var adOk = false

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) load(said)
        }
    }

    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pendingDl?.invoke() else toast("Ruhusa ya kuhifadhi inahitajika ili kupakua")
        pendingDl = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        AdBlock.init(applicationContext)
        BlockLog.load(store.blockLogJson)
        if (AdBlock.isStale()) Thread { AdBlock.update() }.start()

        urlBar = findViewById(R.id.url)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.container)
        tabsCount = findViewById(R.id.tabsCount)
        adBox = findViewById(R.id.adBox)

        MobileAds.initialize(this) { }
        adView = AdView(this)
        adView.setAdSize(AdSize.LARGE_BANNER)
        adView.adUnitId = getString(R.string.admob_banner_id)
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() { adOk = true; updateAd() }
            override fun onAdFailedToLoad(e: LoadAdError) { adOk = false; updateAd() }
        }
        adBox.addView(adView, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        adView.loadAd(AdRequest.Builder().build())

        urlBar.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                load(urlBar.text.toString()); true
            } else false
        }
        urlBar.setOnFocusChangeListener { _, f ->
            if (f) { urlBar.setText(fullUrl); urlBar.selectAll() } else urlBar.setText(pretty(fullUrl))
        }
        findViewById<View>(R.id.mic).setOnClickListener { startVoice() }
        findViewById<View>(R.id.back).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.fwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.homeBtn).setOnClickListener { web.loadUrl(home) }
        findViewById<View>(R.id.tabsBox).setOnClickListener { showTabs() }
        findViewById<View>(R.id.menuBtn).setOnClickListener { showMenu() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    web.canGoBack() -> web.goBack()
                    tabs.size > 1 -> closeTab()
                    else -> finish()
                }
            }
        })

        newTab(intent?.data?.toString() ?: home)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String, incognito: Boolean = false) {
        val w = WebView(this)
        w.tag = if (incognito) "inc" else null
        w.setBackgroundColor(Color.parseColor("#0B0B0D"))
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = store.dataSaver
        if (incognito) w.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        applyDark(w)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false)
        w.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val host = r.url.host ?: return null
                if (host == homeHost) {
                    val p = r.url.path
                    return when {
                        p.isNullOrEmpty() || p == "/" -> html(homeHtml(v.tag == "inc"))
                        p == "/logo.png" -> WebResourceResponse("image/png", null, resources.openRawResource(R.raw.logo))
                        else -> empty()
                    }
                }
                if (store.adblock && AdBlock.isBlocked(host)) { store.addBlocked(); BlockLog.add(host); return empty() }
                if (store.dataSaver && AdBlock.isHeavyMedia(r.url.path ?: "")) { store.addBlocked(); BlockLog.add("🎞 $host"); return empty() }
                return null
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: return false
                if (s == "http" || s == "https" || s == "about" || s == "data") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }

            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                if (v === web) { showUrl(u); progress.visibility = View.VISIBLE }
            }

            override fun onPageFinished(v: WebView, u: String) {
                if (v === web) progress.visibility = View.GONE
                if (v.tag != "inc" && u.startsWith("http") && Uri.parse(u).host != homeHost) {
                    store.addHistory(v.title ?: u, u)
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === web) progress.progress = p
            }
        }
        tabs.add(w)
        show(tabs.size - 1)
        w.loadUrl(url)
    }

    private fun applyDark(w: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, store.darkWeb)
        }
    }

    private fun download(url: String, ua: String, cd: String, mime: String) {
        if (!url.startsWith("http")) { toast("Kiungo hiki hakiwezi kupakuliwa"); return }
        val go: () -> Unit = {
            try {
                val name = URLUtil.guessFileName(url, cd, mime)
                val req = DownloadManager.Request(Uri.parse(url))
                if (mime.isNotEmpty()) req.setMimeType(mime)
                req.addRequestHeader("User-Agent", ua)
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setTitle(name)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                toast("Inapakua: $name")
            } catch (e: Exception) {
                toast("Imeshindwa kupakua")
            }
        }
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDl = go
            storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else go()
    }

    private fun html(s: String) = WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(s.toByteArray()))
    private fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;")

    private fun floaters(): String {
        val sym = listOf("✦", "◆", "➤", "★", "⚡", "👑", "🌐", "✧", "▶", "●", "✦", "◆", "★", "✧")
        return sym.mapIndexed { i, t ->
            val left = (i * 83 + 7) % 94
            val size = 14 + (i * 7) % 22
            val dur = 14 + (i * 5) % 12
            val delay = -((i * 3) % 14)
            "<span style='left:$left%;font-size:${size}px;animation-duration:${dur}s;animation-delay:${delay}s'>$t</span>"
        }.joinToString("")
    }

    private fun homeHtml(inc: Boolean): String {
        val acc = if (inc) "#8E5CFF" else "#FFB300"
        val glow = if (inc) "rgba(142,92,255,.45)" else "rgba(255,179,0,.40)"
        val tiles = store.sites().joinToString("") { (n, u) ->
            val c = brand[n] ?: palette[Math.abs(n.hashCode()) % palette.size]
            "<a class=t href='${esc(u)}'><i style='background:$c'>${esc(n.take(1).uppercase())}</i><b>${esc(n)}</b></a>"
        }
        val ds = if (store.dataSaver) "ON" else "OFF"
        val ab = if (store.adblock) "ON" else "OFF"
        val logo = if (inc) "<div class=lg>&#128374;</div>" else "<img class=lg src='/logo.png'>"
        val tag = if (inc) "Tab ya faragha: historia haihifadhiwi" else "Kivinjari cha haraka na salama"
        return """<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><meta name=color-scheme content=dark><title>Rahim Lux Go</title><style>
body{margin:0;min-height:100vh;background:radial-gradient(circle at 50% 12%,#2a2008 0%,#0B0B0D 62%);color:#fff;font-family:sans-serif;text-align:center;box-sizing:border-box}
.c{position:relative;z-index:1;padding:28px 18px}
.f{position:fixed;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;z-index:0}
.f span{position:absolute;bottom:-60px;color:$acc;opacity:0;animation-name:up;animation-timing-function:linear;animation-iteration-count:infinite}
@keyframes up{0%{transform:translateY(0) rotate(0deg);opacity:0}12%{opacity:.22}85%{opacity:.18}100%{transform:translateY(-115vh) rotate(300deg);opacity:0}}
h1{margin:18px 0 4px;font-size:30px}h1 span{color:$acc}
p{margin:0 0 28px;color:#a8a290;font-size:14px}
.lg{width:96px;height:96px;border-radius:26px;margin:10px auto 0;display:flex;align-items:center;justify-content:center;font-size:42px;background:$acc;box-shadow:0 0 38px $glow}
img.lg{display:block;background:none;object-fit:cover}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:20px 8px;max-width:420px;margin:0 auto}
.t{text-decoration:none;color:#ddd;font-size:12px}
.t i{display:flex;width:56px;height:56px;border-radius:18px;margin:0 auto 8px;align-items:center;justify-content:center;font-style:normal;font-size:24px;font-weight:700;color:#fff}
.t b{font-weight:500;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.s{margin:34px auto 0;max-width:420px;background:rgba(30,30,34,.85);border:1px solid rgba(255,179,0,.25);border-radius:18px;padding:16px;display:flex;justify-content:space-around}
.s div{font-size:12px;color:#a8a290}.s strong{display:block;font-size:22px;color:#fff;margin-bottom:2px}
</style></head><body>
<div class=f>${floaters()}</div>
<div class=c>
$logo
<h1>Rahim Lux <span>Go</span></h1><p>$tag</p>
<div class=g>$tiles</div>
<div class=s><div><strong>${store.blocked}</strong>Vilivyozuiwa</div><div><strong>$ds</strong>Data saver</div><div><strong>$ab</strong>Ad-block</div></div>
</div>
</body></html>"""
    }

    private fun pretty(u: String): String =
        if (u.isEmpty()) "" else (Uri.parse(u).host?.removePrefix("www.") ?: u)

    private fun showUrl(u: String) {
        fullUrl = if (Uri.parse(u).host == homeHost) "" else u
        if (!urlBar.hasFocus()) urlBar.setText(pretty(fullUrl))
        updateAd()
    }

    /** Tangazo linaonekana kwenye Home tu. */
    private fun updateAd() {
        adBox.visibility = if (fullUrl.isEmpty() && adOk) View.VISIBLE else View.GONE
    }

    private fun show(i: Int) {
        cur = i
        container.removeAllViews()
        container.addView(web, FrameLayout.LayoutParams(-1, -1))
        urlBar.hint = if (web.tag == "inc") "🕶 Tab ya faragha" else "Tafuta au andika anwani"
        showUrl(web.url ?: "")
        tabsCount.text = tabs.size.toString()
    }

    private fun closeTab() {
        if (tabs.size == 1) { web.loadUrl(home); return }
        container.removeAllViews()
        val w = tabs.removeAt(cur)
        if (w.tag == "inc") { w.clearCache(true); w.clearHistory() }
        w.destroy()
        show(minOf(cur, tabs.size - 1))
    }

    private fun load(input: String) {
        val t = input.trim()
        val url = when {
            t.isEmpty() -> return
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(" ") && t.contains(".") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
        urlBar.clearFocus()
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "sw-TZ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Sema unachotafuta…")
        }
        try { voice.launch(i) } catch (e: Exception) {
            toast("Voice search haipatikani kwenye simu hii")
        }
    }

    private fun showTabs() {
        val names = tabs.map {
            (if (it.tag == "inc") "🕶 " else "") + (it.title?.take(40) ?: pretty(it.url ?: "").ifEmpty { "Tab mpya" })
        } + "＋ Tab mpya"
        AlertDialog.Builder(this).setTitle("Tabs")
            .setItems(names.toTypedArray()) { _, i ->
                if (i == tabs.size) newTab(home) else show(i)
            }.show()
    }

    private fun manageSites() {
        val s = store.sites()
        if (s.isEmpty()) { toast("Home haina tovuti"); return }
        AlertDialog.Builder(this).setTitle("Gusa tovuti ili kuiondoa")
            .setItems(s.map { it.first }.toTypedArray()) { _, i ->
                store.removeSite(s[i].second)
                toast("Imeondolewa")
            }.show()
    }

    private fun showMenu() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = layoutInflater.inflate(R.layout.sheet_menu, null)
        val statsView = root.findViewById<TextView>(R.id.stats)
        statsView.text = "🛡 ${store.blocked} zimezuiwa ›"
        statsView.setOnClickListener { d.dismiss(); showBlocked() }
        val grid = root.findViewById<GridLayout>(R.id.grid)

        fun cell(icon: String, label: String, on: Boolean? = null, action: () -> Unit) {
            val color = when (on) {
                true -> accent
                false -> Color.parseColor("#8A8A94")
                null -> Color.WHITE
            }
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            box.setPadding(0, 22, 0, 22)
            val ic = TextView(this)
            ic.text = icon; ic.textSize = 24f; ic.gravity = Gravity.CENTER
            val lb = TextView(this)
            lb.text = label; lb.textSize = 11f; lb.gravity = Gravity.CENTER; lb.setTextColor(color)
            box.addView(ic)
            box.addView(lb)
            box.setOnClickListener { d.dismiss(); action() }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            grid.addView(box, lp)
        }

        cell("➕", "Tab mpya") { newTab(home) }
        cell("🕶", "Faragha") { newTab(home, true) }
        cell("✖️", "Funga tab") { closeTab() }
        cell("🔄", "Pakia upya") { web.reload() }

        cell("⭐", "Bookmark") {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) { store.addBookmark(web.title ?: u, u); toast("Imehifadhiwa ⭐") }
        }
        cell("📚", "Bookmarks") { pick("Bookmarks", store.bookmarks()) }
        cell("🕘", "History") { pick("History", store.history()) }
        cell("⬇️", "Vipakuliwa") {
            try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (e: Exception) { toast("Fungua Files > Downloads") }
        }

        cell("🛡️", "Ad-block", store.adblock) {
            store.adblock = !store.adblock
            web.reload()
            toast(if (store.adblock) "Ad-block imewashwa" else "Ad-block imezimwa")
        }
        cell("📉", "Data saver", store.dataSaver) {
            store.dataSaver = !store.dataSaver
            tabs.forEach { t -> t.settings.blockNetworkImage = store.dataSaver }
            web.reload()
            toast(if (store.dataSaver) "Data saver imewashwa" else "Data saver imezimwa")
        }
        cell("🌙", "Dark web", store.darkWeb) {
            store.darkWeb = !store.darkWeb
            tabs.forEach { t -> applyDark(t) }
            web.reload()
            toast(if (store.darkWeb) "Dark mode imewashwa" else "Dark mode imezimwa")
        }
        cell("🏠", "Ongeza Home") {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) {
                store.addSite((web.title ?: pretty(u)).take(14), u)
                toast("Imeongezwa kwenye Home")
            } else toast("Fungua tovuti kwanza")
        }

        cell("✏️", "Dhibiti Home") { manageSites() }
        cell("🔁", "Sasisha list") {
            toast("Inasasisha ad-list…")
            Thread {
                val n = AdBlock.update()
                runOnUiThread { toast(if (n > 0) "Ad-list imesasishwa: $n domains" else "Imeshindwa, jaribu tena") }
            }.start()
        }
        cell("🚫", "Zilizozuiwa") { showBlocked() }
        cell("🔗", "Share") {
            if (fullUrl.isNotEmpty()) {
                val s = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, fullUrl) }
                startActivity(Intent.createChooser(s, "Tuma kupitia"))
            }
        }
        cell("🗑️", "Futa data") {
            store.clearHistory()
            tabs.forEach { t -> t.clearCache(true); t.clearHistory() }
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            toast("Data imefutwa")
        }

        d.setContentView(root)
        d.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun showBlocked() {
        val l = BlockLog.top()
        if (l.isEmpty()) { toast("Hakuna kilichozuiwa bado"); return }
        AlertDialog.Builder(this).setTitle("🚫 Zilizozuiwa (${store.blocked})")
            .setItems(l.map { "${it.first}  ×${it.second}" }.toTypedArray(), null)
            .setPositiveButton("Funga", null)
            .setNeutralButton("Futa orodha") { _, _ ->
                BlockLog.clear(); store.resetBlocked(); store.blockLogJson = "{}"
                toast("Imefutwa")
            }.show()
    }

    private fun pick(title: String, items: List<Pair<String, String>>) {
        if (items.isEmpty()) { toast("Hakuna kitu bado"); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(items.map { it.first.take(40) + "\n" + it.second.take(50) }.toTypedArray()) { _, i ->
                web.loadUrl(items[i].second)
            }.show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onPause() { adView.pause(); super.onPause() }

    override fun onResume() { super.onResume(); adView.resume() }

    override fun onStop() {
        store.blockLogJson = BlockLog.toJson()
        super.onStop()
    }

    override fun onDestroy() {
        adView.destroy()
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
