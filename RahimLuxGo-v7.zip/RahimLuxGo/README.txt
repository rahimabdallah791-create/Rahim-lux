v7 TEST: matangazo ya majaribio (Test Ad). Rudi kwenye IDs halisi kwenye toleo linalofuata.
