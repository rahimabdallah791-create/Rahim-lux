RAHIM LUX GO v22 - Android browser (Kotlin + WebView)
Mpya v22: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
