package com.rahimlux.go

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private val homeHost = "home.rahimlux.go"
    private val home = "https://$homeHost/"
    private val accent = Color.parseColor("#FF1B2D")

    private lateinit var store: Store
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var tabsCount: TextView
    private val tabs = mutableListOf<WebView>()
    private var cur = 0
    private var fullUrl = ""
    private val web get() = tabs[cur]

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) load(said)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        urlBar = findViewById(R.id.url)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.container)
        tabsCount = findViewById(R.id.tabsCount)

        urlBar.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                load(urlBar.text.toString()); true
            } else false
        }
        urlBar.setOnFocusChangeListener { _, f ->
            if (f) { urlBar.setText(fullUrl); urlBar.selectAll() } else urlBar.setText(pretty(fullUrl))
        }
        findViewById<View>(R.id.mic).setOnClickListener { startVoice() }
        findViewById<View>(R.id.back).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.fwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.homeBtn).setOnClickListener { web.loadUrl(home) }
        findViewById<View>(R.id.tabsBox).setOnClickListener { showTabs() }
        findViewById<View>(R.id.menuBtn).setOnClickListener { showMenu() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    web.canGoBack() -> web.goBack()
                    tabs.size > 1 -> closeTab()
                    else -> finish()
                }
            }
        })

        newTab(intent?.data?.toString() ?: home)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String) {
        val w = WebView(this)
        w.setBackgroundColor(Color.parseColor("#121214"))
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = store.dataSaver
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false)

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val host = r.url.host ?: return null
                if (host == homeHost) {
                    val p = r.url.path
                    return if (p.isNullOrEmpty() || p == "/") html(homeHtml()) else empty()
                }
                if (store.adblock && AdBlock.isBlocked(host)) { store.addBlocked(); return empty() }
                if (store.dataSaver && AdBlock.isHeavyMedia(r.url.path ?: "")) { store.addBlocked(); return empty() }
                return null
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: return false
                if (s == "http" || s == "https" || s == "about" || s == "data") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }

            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                if (v === web) { showUrl(u); progress.visibility = View.VISIBLE }
            }

            override fun onPageFinished(v: WebView, u: String) {
                if (v === web) progress.visibility = View.GONE
                if (u.startsWith("http") && Uri.parse(u).host != homeHost) store.addHistory(v.title ?: u, u)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === web) progress.progress = p
            }
        }
        tabs.add(w)
        show(tabs.size - 1)
        w.loadUrl(url)
    }

    private fun html(s: String) = WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(s.toByteArray()))
    private fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    private fun homeHtml(): String {
        val sites = listOf(
            Triple("Google", "https://www.google.com", "#4285F4"),
            Triple("YouTube", "https://m.youtube.com", "#FF0000"),
            Triple("Facebook", "https://m.facebook.com", "#1877F2"),
            Triple("Instagram", "https://www.instagram.com", "#E1306C"),
            Triple("WhatsApp", "https://web.whatsapp.com", "#25D366"),
            Triple("TikTok", "https://www.tiktok.com", "#222222"),
            Triple("Wikipedia", "https://sw.wikipedia.org", "#636466"),
            Triple("Mwananchi", "https://www.mwananchi.co.tz", "#E53935")
        )
        val tiles = sites.joinToString("") { (n, u, c) ->
            "<a class=t href='$u'><i style='background:$c'>${n[0]}</i><b>$n</b></a>"
        }
        val ds = if (store.dataSaver) "ON" else "OFF"
        val ab = if (store.adblock) "ON" else "OFF"
        return """<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'><title>Rahim Lux Go</title><style>
body{margin:0;min-height:100vh;background:linear-gradient(160deg,#22222c,#121214 60%);color:#fff;font-family:sans-serif;text-align:center;padding:28px 18px;box-sizing:border-box}
h1{margin:18px 0 4px;font-size:30px}h1 span{color:#FF1B2D}
p{margin:0 0 28px;color:#9a9aa5;font-size:14px}
.logo{width:68px;height:68px;border-radius:22px;background:#FF1B2D;margin:10px auto 0;display:flex;align-items:center;justify-content:center;font-size:32px}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:20px 8px;max-width:420px;margin:0 auto}
.t{text-decoration:none;color:#ddd;font-size:12px}
.t i{display:flex;width:56px;height:56px;border-radius:18px;margin:0 auto 8px;align-items:center;justify-content:center;font-style:normal;font-size:24px;font-weight:700;color:#fff}
.t b{font-weight:500}
.s{margin:34px auto 0;max-width:420px;background:#1e1e24;border-radius:18px;padding:16px;display:flex;justify-content:space-around}
.s div{font-size:12px;color:#9a9aa5}.s strong{display:block;font-size:22px;color:#fff;margin-bottom:2px}
</style></head><body>
<div class=logo>&#10148;</div>
<h1>Rahim Lux <span>Go</span></h1><p>Kivinjari cha haraka na salama</p>
<div class=g>$tiles</div>
<div class=s><div><strong>${store.blocked}</strong>Vilivyozuiwa</div><div><strong>$ds</strong>Data saver</div><div><strong>$ab</strong>Ad-block</div></div>
</body></html>"""
    }

    private fun pretty(u: String): String =
        if (u.isEmpty()) "" else (Uri.parse(u).host?.removePrefix("www.") ?: u)

    private fun showUrl(u: String) {
        fullUrl = if (Uri.parse(u).host == homeHost) "" else u
        if (!urlBar.hasFocus()) urlBar.setText(pretty(fullUrl))
    }

    private fun show(i: Int) {
        cur = i
        container.removeAllViews()
        container.addView(web, FrameLayout.LayoutParams(-1, -1))
        showUrl(web.url ?: "")
        tabsCount.text = tabs.size.toString()
    }

    private fun closeTab() {
        if (tabs.size == 1) { web.loadUrl(home); return }
        container.removeAllViews()
        tabs.removeAt(cur).destroy()
        show(minOf(cur, tabs.size - 1))
    }

    private fun load(input: String) {
        val t = input.trim()
        val url = when {
            t.isEmpty() -> return
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(" ") && t.contains(".") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
        urlBar.clearFocus()
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "sw-TZ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Sema unachotafuta…")
        }
        try { voice.launch(i) } catch (e: Exception) {
            toast("Voice search haipatikani kwenye simu hii")
        }
    }

    private fun showTabs() {
        val names = tabs.map { it.title?.take(40) ?: pretty(it.url ?: "").ifEmpty { "Tab mpya" } } + "＋ Tab mpya"
        AlertDialog.Builder(this).setTitle("Tabs")
            .setItems(names.toTypedArray()) { _, i ->
                if (i == tabs.size) newTab(home) else show(i)
            }.show()
    }

    private fun showMenu() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = layoutInflater.inflate(R.layout.sheet_menu, null)
        root.findViewById<TextView>(R.id.stats).text = "🛡 ${store.blocked} zimezuiwa"
        val grid = root.findViewById<GridLayout>(R.id.grid)

        fun cell(icon: String, label: String, on: Boolean? = null, action: () -> Unit) {
            val color = when (on) {
                true -> accent
                false -> Color.parseColor("#8A8A94")
                null -> Color.WHITE
            }
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            box.setPadding(0, 24, 0, 24)
            val ic = TextView(this)
            ic.text = icon; ic.textSize = 24f; ic.gravity = Gravity.CENTER
            val lb = TextView(this)
            lb.text = label; lb.textSize = 11f; lb.gravity = Gravity.CENTER; lb.setTextColor(color)
            box.addView(ic)
            box.addView(lb)
            box.setOnClickListener { d.dismiss(); action() }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            grid.addView(box, lp)
        }

        cell("➕", "Tab mpya") { newTab(home) }
        cell("✖️", "Funga tab") { closeTab() }
        cell("🔄", "Pakia upya") { web.reload() }
        cell("⭐", "Bookmark") {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) { store.addBookmark(web.title ?: u, u); toast("Imehifadhiwa ⭐") }
        }
        cell("📚", "Bookmarks") { pick("Bookmarks", store.bookmarks()) }
        cell("🕘", "History") { pick("History", store.history()) }
        cell("🛡️", "Ad-block", store.adblock) {
            store.adblock = !store.adblock
            web.reload()
            toast(if (store.adblock) "Ad-block imewashwa" else "Ad-block imezimwa")
        }
        cell("📉", "Data saver", store.dataSaver) {
            store.dataSaver = !store.dataSaver
            tabs.forEach { t -> t.settings.blockNetworkImage = store.dataSaver }
            web.reload()
            toast(if (store.dataSaver) "Data saver imewashwa" else "Data saver imezimwa")
        }
        cell("🔗", "Share") {
            if (fullUrl.isNotEmpty()) {
                val s = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, fullUrl) }
                startActivity(Intent.createChooser(s, "Tuma kupitia"))
            }
        }
        cell("🗑️", "Futa data") {
            store.clearHistory()
            tabs.forEach { t -> t.clearCache(true); t.clearHistory() }
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            toast("Data imefutwa")
        }

        d.setContentView(root)
        d.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun pick(title: String, items: List<Pair<String, String>>) {
        if (items.isEmpty()) { toast("Hakuna kitu bado"); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(items.map { it.first.take(40) + "\n" + it.second.take(50) }.toTypedArray()) { _, i ->
                web.loadUrl(items[i].second)
            }.show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
