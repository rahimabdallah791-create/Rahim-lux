package com.rahimlux.go

/** Orodha fupi ya ad/tracker domains. Ongeza zaidi hapa. */
object AdBlock {
    private val hosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "google-analytics.com", "adnxs.com",
        "taboola.com", "outbrain.com", "popads.net", "propellerads.com",
        "exoclick.com", "adsterra.com", "mgid.com", "criteo.com",
        "scorecardresearch.com", "hotjar.com", "ads.twitter.com",
        "analytics.tiktok.com"
    )
    private val media = listOf(".mp4", ".webm", ".m3u8", ".mov", ".avi")

    fun isBlocked(host: String) = hosts.any { host == it || host.endsWith(".$it") }
    fun isHeavyMedia(path: String) = media.any { path.endsWith(it, ignoreCase = true) }
}
