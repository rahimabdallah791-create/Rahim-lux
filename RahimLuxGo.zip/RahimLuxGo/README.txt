RAHIM LUX GO - Android browser (Kotlin + WebView)
Android Studio: Open folda hii > Run.
APK kwa GitHub Actions: tazama build.yml iliyotumwa kwenye chat.
Ad-block list: app/src/main/java/com/rahimlux/go/AdBlock.kt
