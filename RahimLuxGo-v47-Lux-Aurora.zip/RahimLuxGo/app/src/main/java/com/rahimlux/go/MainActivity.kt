package com.rahimlux.go

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import java.io.FileInputStream
import java.io.File
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.CheckBox
import android.webkit.PermissionRequest
import android.webkit.GeolocationPermissions
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val homeHost = "home.rahimlux.go"
    private val home = "https://$homeHost/"
    private val accent = Color.parseColor("#FFB300")
    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val betNames = setOf("Betway", "Betpawa", "SportyBet", "1win")

    private val brand = mapOf(
        "Google" to "#4285F4", "YouTube" to "#FF0000", "Facebook" to "#1877F2",
        "Instagram" to "#E1306C", "WhatsApp" to "#25D366", "TikTok" to "#222222",
        "Wikipedia" to "#636466", "Mwananchi" to "#E53935",
        "Betway" to "#00A826", "Betpawa" to "#1F8A4C", "SportyBet" to "#00A64F", "1win" to "#2D6BFF"
    )
    private val palette = listOf("#FF7043", "#26A69A", "#5C6BC0", "#AB47BC", "#EC407A", "#29B6F6", "#9CCC65", "#FFA726")

    private lateinit var store: Store
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var tabsCount: TextView
    private lateinit var suggestList: ListView
    private lateinit var dlBtn: TextView
    private lateinit var adBox: FrameLayout
    private lateinit var adView: AdView
    private lateinit var bottomBar: View
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var siteIcon: TextView
    private lateinit var findBar: View
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private data class News(val title: String, val link: String, val src: String, val img: String = "")
    private data class Sug(val text: String, val hist: Boolean)
    private data class Feed(val key: String, val en: String, val sw: String, val url: String, val src: String)
    private val feeds = listOf(
        Feed("top", "Top", "Kuu", "https://feeds.bbci.co.uk/news/rss.xml", "BBC News"),
        Feed("tz", "Tanzania", "Tanzania", "", "Google News"),
        Feed("sports", "Sport", "Michezo", "https://feeds.bbci.co.uk/sport/rss.xml", "BBC Sport"),
        Feed("biz", "Business", "Biashara", "https://feeds.bbci.co.uk/news/business/rss.xml", "BBC News"),
        Feed("ent", "Entertainment", "Burudani", "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml", "BBC News"),
        Feed("africa", "Africa", "Afrika", "https://feeds.bbci.co.uk/news/world/africa/rss.xml", "BBC News"),
        Feed("tech", "Tech", "Teknolojia", "https://feeds.bbci.co.uk/news/technology/rss.xml", "BBC News"),
        Feed("swahili", "Kiswahili", "Kiswahili", "https://feeds.bbci.co.uk/swahili/rss.xml", "BBC Swahili"),
        Feed("world", "World", "Dunia", "https://www.aljazeera.com/xml/rss/all.xml", "Al Jazeera")
    )
    private val cats = ConcurrentHashMap<String, List<News>>()
    private val chromeUa = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    @Volatile private var news = listOf<News>()
    private var newsAt = 0L
    private var lastNav = 0L
    private var langAtOpen = ""
    private var scoresErr = ""
    private var scoresBusy = false
    private var scoresNext = 0L
    private var scoresFails = 0
    private var scoresHasLive = false
    private var weatherBusy = false
    private var weatherNext = 0L
    private var weatherErr = ""

    /** Download ikikamilika/ikishindwa: weka kwenye Notification Center (Android yenyewe inaonyesha arifa ya mfumo). */
    private val dlReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id >= 0) Notif.recordDownload(applicationContext, id)
        }
    }

    /** UA ya Chrome halisi (bila "wv" na "Version/4.0") ili tovuti zisikatae WebView. */
    private val mobileUa: String by lazy {
        WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(" Version/4.0", "")
    }
    private val tabs = mutableListOf<Tab>()
    private val pageHosts = ConcurrentHashMap<WebView, String>()
    private var cur = 0
    private var fullUrl = ""
    private val web: WebView get() = webOf(tabs[cur])
    private var pendingDl: (() -> Unit)? = null
    private var adOk = false
    private var kbOpen = false
    private var programmatic = false
    private var suggestions = listOf<Sug>()
    private var suggestSeq = 0
    private var suggestJob: Runnable? = null
    private var videoUrl: String? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun t(en: String, sw: String) = if (store.lang == "sw") sw else en
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) load(said)
        }
    }

    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pendingDl?.invoke() else toast(t("Storage permission is needed to download", "Ruhusa ya kuhifadhi inahitajika ili kupakua"))
        pendingDl = null
    }

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    private val offlineLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data ?: return@registerForActivityResult
        val f = d.getStringExtra("file")
        val u = d.getStringExtra("url")
        if (f != null && OfflineRepo.isSafeName(f)) web.loadUrl(OfflineRepo.openUrl(homeHost, f))
        else if (u != null && (u.startsWith("https://") || u.startsWith("http://"))) web.loadUrl(u)
    }

    private val settingsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.data?.getBooleanExtra("cleared", false) == true) forEachLive { it.clearCache(true); it.clearHistory() }
        applyAll()
        if (r.data?.getBooleanExtra("bg", false) == true) showBackgroundDialog()
    }

    /** Mchaguzi wa picha wa Android (hauhitaji ruhusa yoyote). */
    private val bgPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            toast(t("Saving picture…", "Inahifadhi picha…"))
            Thread {
                val ok = Background.save(applicationContext, uri)
                runOnUiThread {
                    if (ok) {
                        store.bgVersion = System.currentTimeMillis()
                        if (tabs.isNotEmpty() && fullUrl.isEmpty()) web.reload()
                        toast(t("Background updated", "Picha ya nyuma imewekwa"))
                    } else toast(t("Could not use this picture", "Picha hii haikuweza kutumika"))
                }
            }.start()
        }
    }

    private fun showBackgroundDialog() {
        val has = Background.exists(this) && store.bgVersion > 0
        val labels = mutableListOf(t("Choose a picture", "Chagua picha"))
        if (has) {
            labels.add(t("Dim: ", "Giza: ") + store.bgDim + "%")
            labels.add(t("Remove picture", "Ondoa picha"))
        }
        AlertDialog.Builder(this).setTitle(t("Home background", "Picha ya nyuma ya Home"))
            .setItems(labels.toTypedArray()) { _, i ->
                when {
                    i == 0 -> try { bgPicker.launch("image/*") } catch (e: Exception) { toast(t("No gallery app found", "Hakuna app ya picha")) }
                    has && i == 1 -> {
                        val opts = listOf(15, 30, 45, 60, 75)
                        AlertDialog.Builder(this).setTitle(t("Dim the picture", "Weka giza kwenye picha"))
                            .setSingleChoiceItems(opts.map { "$it%" }.toTypedArray(), opts.indexOf(store.bgDim).coerceAtLeast(0)) { d, k ->
                                store.bgDim = opts[k]
                                d.dismiss()
                                if (tabs.isNotEmpty() && fullUrl.isEmpty()) web.reload()
                            }.show()
                    }
                    has && i == 2 -> {
                        Background.remove(this)
                        store.bgVersion = 0L
                        if (tabs.isNotEmpty() && fullUrl.isEmpty()) web.reload()
                        toast(t("Picture removed", "Picha imeondolewa"))
                    }
                }
            }.show()
    }

    private val poll = object : Runnable {
        override fun run() {
            if (tabs.isNotEmpty() && fullUrl.isEmpty() && System.currentTimeMillis() - newsAt > 15 * 60 * 1000) {
                newsAt = System.currentTimeMillis()
                loadNews()
            }
            if (tabs.isNotEmpty() && fullUrl.isEmpty() && !kbOpen && !scoresBusy &&
                scoresConfigured() && System.currentTimeMillis() >= scoresNext) loadScores()
            if (tabs.isNotEmpty() && fullUrl.isEmpty() && !kbOpen && !weatherBusy &&
                weatherConfigured() && System.currentTimeMillis() >= weatherNext) loadWeather()
            if (tabs.isNotEmpty() && fullUrl.isNotEmpty() && !kbOpen) {
                val js = "(function(){var v=document.querySelector('video');if(!v)return '';var s=v.currentSrc||v.src||'';if(!s){var e=v.querySelector('source');s=e?e.src:''}return s})()"
                web.evaluateJavascript(js) { res ->
                    val s = try { JSONTokener(res).nextValue() as? String } catch (e: Exception) { null }
                    if (!s.isNullOrEmpty() && s.startsWith("http") && !s.contains(".m3u8")) offerVideo(s)
                }
            }
            handler.postDelayed(this, 2500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        if (savedInstanceState == null && store.clearExit && store.exitPending) runExitClear()
        if (store.ssAuto) { StatusAutoSaveWorker.schedule(this, true); StatusAutoSaveWorker.runNow(this) }
        AdBlock.init(applicationContext)
        BlockLog.load(store.blockLogJson)
        initScores()
        weatherNext = store.weatherAtMs + 30 * 60 * 1000L
        Notif.ensureChannels(this, store)
        Push.refreshToken(this)
        Push.syncTopics(this)
        try {
            ContextCompat.registerReceiver(
                this, dlReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED
            )
        } catch (e: Exception) { }
        if (AdBlock.isStale()) Thread { AdBlock.update() }.start()

        urlBar = findViewById(R.id.url)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.container)
        tabsCount = findViewById(R.id.tabsCount)
        suggestList = findViewById(R.id.suggestList)
        dlBtn = findViewById(R.id.dlBtn)
        adBox = findViewById(R.id.adBox)
        bottomBar = findViewById(R.id.bottomBar)
        refresh = findViewById(R.id.refresh)
        siteIcon = findViewById(R.id.siteIcon)
        findBar = findViewById(R.id.findBar)
        findInput = findViewById(R.id.findInput)
        findCount = findViewById(R.id.findCount)

        refresh.setColorSchemeColors(accent)
        refresh.setProgressBackgroundColorSchemeColor(Color.parseColor("#171730"))
        refresh.setOnRefreshListener {
            if (fullUrl.isEmpty()) { newsAt = System.currentTimeMillis(); loadNews(true) } else web.reload()
            handler.postDelayed({ refresh.isRefreshing = false }, 1500)
        }
        refresh.setOnChildScrollUpCallback { _, _ -> web.canScrollVertically(-1) || customView != null }

        findInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString() ?: ""
                if (q.isEmpty()) { web.clearMatches(); findCount.text = "0/0" } else web.findAllAsync(q)
            }
        })
        findViewById<View>(R.id.findNext).setOnClickListener { web.findNext(true) }
        findViewById<View>(R.id.findPrev).setOnClickListener { web.findNext(false) }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }

        MobileAds.initialize(this) { }
        adView = AdView(this)
        adView.setAdSize(AdSize.LARGE_BANNER)
        adView.adUnitId = getString(R.string.admob_banner_id)
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() { adOk = true; updateAd() }
            override fun onAdFailedToLoad(e: LoadAdError) { adOk = false; updateAd() }
        }
        adBox.addView(adView, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        adView.loadAd(AdRequest.Builder().build())

        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {
            val vis = ViewCompat.getRootWindowInsets(window.decorView)
                ?.isVisible(WindowInsetsCompat.Type.ime()) ?: false
            if (vis != kbOpen) {
                kbOpen = vis
                bottomBar.visibility = if (vis) View.GONE else View.VISIBLE
                if (vis) dlBtn.visibility = View.GONE
                updateAd()
            }
        }

        urlBar.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                load(urlBar.text.toString()); true
            } else false
        }
        urlBar.setOnFocusChangeListener { _, f ->
            if (f) { setBar(fullUrl); urlBar.selectAll(); showSuggestions("", emptyList()) } else { setBar(pretty(fullUrl)); hideSuggestions() }
        }
        urlBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (programmatic || !urlBar.hasFocus()) return
                val q = s?.toString()?.trim() ?: ""
                if (q.startsWith("http") || (!q.contains(" ") && q.contains("."))) {
                    hideSuggestions(); return
                }
                if (q.length < 2) { showSuggestions(q, emptyList()); return }
                suggest(q)
            }
        })
        suggestList.setOnItemClickListener { _, _, i, _ ->
            val s = suggestions.getOrNull(i)?.text ?: return@setOnItemClickListener
            hideSuggestions()
            load(s)
        }
        suggestList.setOnItemLongClickListener { _, _, i, _ ->
            val s = suggestions.getOrNull(i)
            if (s != null && s.hist) {
                store.removeSearch(s.text)
                showSuggestions(urlBar.text.toString().trim(), emptyList())
                toast(t("Removed from search history", "Imeondolewa kwenye historia ya utafutaji"))
                true
            } else false
        }
        dlBtn.setOnClickListener {
            videoUrl?.let { download(it, web.settings.userAgentString, "", "video/mp4") }
            dlBtn.visibility = View.GONE
        }

        findViewById<View>(R.id.mic).setOnClickListener { startVoice() }
        findViewById<View>(R.id.back).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.fwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.homeBtn).setOnClickListener { web.loadUrl(home) }
        findViewById<View>(R.id.tabsBox).setOnClickListener { showTabs() }
        findViewById<View>(R.id.menuBtn).setOnClickListener { showMenu() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    findBar.visibility == View.VISIBLE -> closeFind()
                    suggestList.visibility == View.VISIBLE -> hideSuggestions()
                    web.canGoBack() -> web.goBack()
                    tabs.size > 1 -> closeTab()
                    else -> finish()
                }
            }
        })

        newsAt = System.currentTimeMillis()
        loadNewsCache()
        loadNews()
        restoreTabs()
        if (savedInstanceState == null) handleIntent(intent)
        if (tabs.isEmpty()) newTab(home)
    }

    // ---------------- Tabs ----------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String, incognito: Boolean = false, load: Boolean = true): WebView {
        val w = buildWebView(incognito)
        tabs.add(Tab(w, url, "", incognito))
        show(tabs.size - 1)
        if (load) w.loadUrl(url)
        return w
    }

    /** Inaunda WebView mpya. Inaitwa tu inapohitajika: tab mpya, au tab iliyolala inapofunguliwa. */
    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView(incognito: Boolean): WebView {
        val w = WebView(this)
        w.tag = if (incognito) "inc" else null
        w.setBackgroundColor(Color.parseColor("#07070F"))
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = store.dataSaver
        w.settings.setSupportMultipleWindows(true)
        w.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        w.setFindListener { a, n, _ -> if (w === web) findCount.text = if (n == 0) "0/0" else "${a + 1}/$n" }
        if (incognito) w.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        applyDark(w)
        applyDesktop(w)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.thirdCookies)
        w.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }
        w.setOnLongClickListener { v ->
            val wv = v as WebView
            val hit = wv.hitTestResult
            when (hit.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    val h = Handler(Looper.getMainLooper()) { m ->
                        val link = m.data.getString("url") ?: hit.extra
                        val img = m.data.getString("src")
                        showContextMenu(link, if (hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) img else null)
                        true
                    }
                    wv.requestFocusNodeHref(h.obtainMessage())
                    true
                }
                WebView.HitTestResult.IMAGE_TYPE -> { showContextMenu(null, hit.extra); true }
                else -> false // Keep Android WebView's normal text-selection behavior.
            }
        }

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val host = r.url.host ?: return null
                if (r.isForMainFrame) pageHosts[v] = host
                if (host == homeHost) {
                    val p = r.url.path
                    return when {
                        p.isNullOrEmpty() || p == "/" -> html(homeHtml(v.tag == "inc"))
                        p == "/logo.png" -> WebResourceResponse("image/png", null, resources.openRawResource(R.raw.logo))
                        p == "/bg.jpg" -> {
                            val f = Background.file(this@MainActivity)
                            if (f.exists()) WebResourceResponse("image/jpeg", null, FileInputStream(f)) else empty()
                        }
                        p == "/fav.css" -> WebResourceResponse("text/css", "utf-8", resources.openRawResource(R.raw.fav_team_css))
                        p == "/fav.js" -> WebResourceResponse("application/javascript", "utf-8", resources.openRawResource(R.raw.fav_team_js))
                        p == "/theme.css" -> WebResourceResponse("text/css", "utf-8", resources.openRawResource(R.raw.theme_css))
                        p == "/theme.js" -> WebResourceResponse("application/javascript", "utf-8", resources.openRawResource(R.raw.theme_js))
                        (p ?: "").startsWith("/offline/") -> {
                            val f = OfflineRepo.fileOf(this@MainActivity, (p ?: "").removePrefix("/offline/"))
                            if (f != null) WebResourceResponse(
                                "text/html", "utf-8", 200, "OK",
                                mapOf("Content-Security-Policy" to "default-src 'none'; style-src 'unsafe-inline'; img-src data:", "Cache-Control" to "no-store"),
                                FileInputStream(f)
                            ) else empty()
                        }
                        else -> empty()
                    }
                }
                val siteOff = store.isAdOff(pageHosts[v])
                if (!r.isForMainFrame && !siteOff && store.trackerBlock && Trackers.isTracker(host)) {
                    store.recordBlock(Blk.TRACKER); BlockLog.add(host); return blocked()
                }
                if (store.adblock && !siteOff && AdBlock.isBlocked(host)) {
                    store.recordBlock(Blk.AD); BlockLog.add(host); return blocked()
                }
                val path = r.url.path ?: ""
                if (store.dataSaver && AdBlock.isHeavyMedia(path)) { store.recordBlock(Blk.MEDIA); BlockLog.add("🎞 $host"); return blocked() }
                if (path.endsWith(".mp4", true) || path.endsWith(".webm", true)) {
                    val u = r.url.toString()
                    runOnUiThread { if (v === web) offerVideo(u) }
                }
                return null
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = (r.url.scheme ?: return false).lowercase()
                if (s == "rlg") {
                    // Kadi za Home tu (ukurasa wa Home) zinaweza kufungua ukurasa wa mechi
                    val pageHost = Uri.parse(v.url ?: "").host
                    if (pageHost == homeHost && r.url.host == "bg") { showBackgroundDialog(); return true }
                    if (pageHost == homeHost && r.url.host == "status") { startActivity(Intent(this@MainActivity, StatusSaverActivity::class.java)); return true }
                    val mid = r.url.lastPathSegment ?: ""
                    if (pageHost == homeHost && r.url.host == "match" && mid.isNotEmpty() && mid.length <= 12 && mid.all { it.isDigit() }) {
                        startActivity(Intent(this@MainActivity, MatchActivity::class.java).putExtra("id", mid))
                    }
                    return true
                }
                if (s == "http" || s == "https" || s == "about" || s == "data") return false
                // Usifungue faili za ndani wala javascript kupitia intents
                if (s == "file" || s == "content" || s == "javascript") return true
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }

            override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                runOnUiThread { recreate() }
                return true
            }

            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                if (v === web && u != readerModeUrl && readerModeUrl.isNotEmpty()) readerModeUrl = ""
                if (v === web) stopReadAloud()
                recordSearch(v.tag == "inc", u)
                tabOf(v)?.let { it.url = u }
                if (v === web) {
                    showUrl(u)
                    progress.visibility = View.VISIBLE
                    videoUrl = null
                    dlBtn.visibility = View.GONE
                }
            }

            override fun onPageFinished(v: WebView, u: String) {
                if (v === web) progress.visibility = View.GONE
                refresh.isRefreshing = false
                tabOf(v)?.let { it.url = u; it.title = v.title ?: it.title }
                if (v.tag != "inc" && u.startsWith("http") && Uri.parse(u).host != homeHost) {
                    store.addHistory(v.title ?: u, u)
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === web) progress.progress = p
            }

            override fun onReceivedTitle(v: WebView, title: String?) {
                tabOf(v)?.let { if (!title.isNullOrBlank()) it.title = title }
            }

            // Ruhusa za tovuti: mahali, kamera, kipaza sauti (maamuzi yanahifadhiwa kwenye SitePerms; angalia Privacy Dashboard)
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                val o = SitePerms.origin(origin)
                if (o == null) { callback.invoke(origin, false, false); return }
                decideSite(o, listOf(SitePerms.GEO), incognito) { allow ->
                    if (!allow) callback.invoke(origin, false, false)
                    else withAndroidPerms(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), true) { ok ->
                        callback.invoke(origin, ok, false)
                    }
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                handleWebPermission(request, incognito)
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                permDialog?.dismiss()
            }

            override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false
                newTab("about:blank", v.tag == "inc", false)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = web
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val i = tabs.indexOfFirst { it.wv === window }
                if (i >= 0 && tabs.size > 1) closeTabAt(i)
            }

            // Video ya skrini nzima (fullscreen)
            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                view.setBackgroundColor(Color.BLACK)
                (window.decorView as ViewGroup).addView(view, ViewGroup.LayoutParams(-1, -1))
                WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() { exitFullscreen() }

            // Kupakia faili (upload)
            override fun onShowFileChooser(
                webView: WebView, filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                return try { fileLauncher.launch(fileChooserParams.createIntent()); true }
                catch (e: Exception) { fileCb = null; false }
            }
        }
        return w
    }

    private fun applyDark(w: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, store.darkWeb)
        }
    }

    private fun applyDesktop(w: WebView) {
        w.settings.userAgentString = if (store.desktop) desktopUa else mobileUa
        w.settings.useWideViewPort = true
        w.settings.loadWithOverviewMode = true
        w.settings.setSupportZoom(true)
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
    }

    private fun show(i: Int) {
        val now = System.currentTimeMillis()
        if (cur in tabs.indices && cur != i) {
            tabs[cur].lastUsed = now
            tabs[cur].wv?.onPause()
        }
        cur = i
        val t = tabs[i]
        t.lastUsed = now
        val w = webOf(t)
        w.onResume()
        container.removeAllViews()
        container.addView(w, FrameLayout.LayoutParams(-1, -1))
        updateHint()
        val lazy = t.pending
        t.pending = null
        if (lazy != null) { w.loadUrl(lazy); showUrl(lazy) } else showUrl(w.url ?: "")
        tabsCount.text = tabs.size.toString()
        videoUrl = null
        dlBtn.visibility = View.GONE
        hideSuggestions()
        updateSecure()
        stopReadAloud()
        guardPrivate()
        trimTabs()
    }

    private fun closeTabAt(i: Int) { cur = i; closeTab() }

    private fun closeTab() {
        if (tabs.size == 1) { web.loadUrl(home); return }
        container.removeAllViews()
        val t = tabs.removeAt(cur)
        archiveClosed(t)
        destroyTab(t)
        show(minOf(cur, tabs.size - 1))
    }

    /** Tab zinarudishwa kama "zimelala": WebView inaundwa tu tab inapofunguliwa (tab ya sasa pekee ndiyo inaundwa mwanzoni). */
    private fun restoreTabs() {
        try {
            val o = JSONObject(store.tabsJson)
            val a = o.getJSONArray("u")
            if (a.length() == 0) return
            val titles = o.optJSONArray("t")
            val used = o.optJSONArray("l")
            val now = System.currentTimeMillis()
            for (k in 0 until a.length()) {
                val u = a.getString(k)
                val t = Tab(null, u, titles?.optString(k, "") ?: "", false)
                t.pending = u
                t.lastUsed = used?.optLong(k, now) ?: now
                tabs.add(t)
            }
            show(o.optInt("i", 0).coerceIn(0, tabs.size - 1))
        } catch (e: Exception) { }
    }

    private fun saveTabs() {
        if (tabs.isEmpty()) return
        tabs.getOrNull(cur)?.lastUsed = System.currentTimeMillis()
        val items = tabs.filter { !it.incognito }
            .mapNotNull { t -> t.currentUrl().takeIf { it.startsWith("http") && !isOfflineUrl(it) }?.let { t to it } }
            .take(30)
        val idx = items.indexOfFirst { it.first === tabs[cur] }.coerceAtLeast(0)
        val o = JSONObject().put("i", idx)
            .put("u", JSONArray(items.map { it.second }))
            .put("t", JSONArray(items.map { (it.first.wv?.title?.takeIf { x -> x.isNotBlank() } ?: it.first.title).take(120) }))
            .put("l", JSONArray(items.map { it.first.lastUsed }))
        store.tabsJson = o.toString()
    }

    private fun exitFullscreen() {
        val v = customView ?: return
        (window.decorView as ViewGroup).removeView(v)
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    private fun openFind() {
        findBar.visibility = View.VISIBLE
        findInput.setText("")
        findInput.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(findInput, 0)
    }

    private fun closeFind() {
        web.clearMatches()
        findBar.visibility = View.GONE
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(findInput.windowToken, 0)
    }

    // ---------------- v36: Translate, Save PDF, fingerprint lock, Clear data on exit ----------------
    private var privUnlockedAt = 0L
    private var bmUnlockedAt = 0L
    private var lockCover: View? = null
    private var promptBusy = false

    private fun fresh(at: Long) = System.currentTimeMillis() - at < 45_000

    private fun printPage() {
        try {
            val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
            val name = (web.title?.takeIf { it.isNotBlank() } ?: "Rahim Lux Go").replace(Regex("[^A-Za-z0-9 _.-]"), "_").take(40)
            pm.print(name, web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
            toast(t("Choose \"Save as PDF\" as the printer", "Chagua \"Save as PDF\" kama printer"))
        } catch (e: Exception) {
            toast(t("Cannot print this page", "Ukurasa huu hauwezi kuchapishwa"))
        }
    }

    private fun translatePage() {
        val u = web.url ?: ""
        if (!u.startsWith("http") || Uri.parse(u).host == homeHost) { toast(t("Open a website first", "Fungua tovuti kwanza")); return }
        val labels = ArrayList<String>()
        val codes = ArrayList<String>()
        if (PageTranslate.isTranslated(u)) { labels.add(t("Show original", "Onyesha asili")); codes.add("") }
        for ((c, n) in PageTranslate.langs) { labels.add(n); codes.add(c) }
        AlertDialog.Builder(this).setTitle("🌍 " + t("Translate this page to…", "Tafsiri ukurasa huu kwenda…"))
            .setItems(labels.toTypedArray()) { _, i ->
                val code = codes[i]
                val base = PageTranslate.original(u) ?: u
                val target = if (code.isEmpty()) PageTranslate.original(u) else PageTranslate.translate(base, code)
                if (target == null) toast(t("This page cannot be translated", "Ukurasa huu hauwezi kutafsiriwa")) else web.loadUrl(target)
            }.show()
    }

    private fun updateSecure() {
        val on = store.lockPriv && tabs.isNotEmpty() && web.tag == "inc"
        if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun removeCover() {
        lockCover?.let { (it.parent as? ViewGroup)?.removeView(it) }
        lockCover = null
    }

    private fun showCover() {
        if (lockCover != null) return
        val f = FrameLayout(this)
        f.setBackgroundColor(Color.parseColor("#07070F"))
        f.isClickable = true
        val tv = TextView(this)
        tv.text = "🔒\n" + t("Private tab locked", "Tab ya faragha imefungwa")
        tv.setTextColor(Color.WHITE); tv.textSize = 18f; tv.gravity = Gravity.CENTER
        f.addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        container.addView(f, FrameLayout.LayoutParams(-1, -1))
        lockCover = f
    }

    private fun leavePrivate() {
        removeCover()
        val idx = tabs.indexOfFirst { !it.incognito }
        if (idx >= 0) show(idx) else newTab(home)
    }

    /** Tab ya faragha inafunguliwa tu baada ya alama ya kidole / kufuli ya skrini (inabaki wazi sekunde 45 baada ya kufungua, na inajifunga app ikitoka mbele). */
    private fun guardPrivate() {
        if (tabs.isEmpty() || web.tag != "inc" || !store.lockPriv) { removeCover(); return }
        if (fresh(privUnlockedAt) || !AppLock.canAuth(this)) { removeCover(); return }
        showCover()
        setBar("")
        if (promptBusy) return
        promptBusy = true
        AppLock.prompt(this, t("Private tabs", "Tab za faragha"), t("Unlock to continue", "Fungua ili kuendelea"), t("Cancel", "Ghairi")) { ok ->
            promptBusy = false
            if (ok) {
                privUnlockedAt = System.currentTimeMillis()
                removeCover()
                if (tabs.isNotEmpty()) showUrl(web.url ?: "")
            } else leavePrivate()
        }
    }

    private fun withBookmarkLock(onOk: () -> Unit) {
        if (!store.lockBm || fresh(bmUnlockedAt) || !AppLock.canAuth(this)) { onOk(); return }
        AppLock.prompt(this, "Bookmarks", t("Unlock to view bookmarks", "Fungua ili kuona bookmarks"), t("Cancel", "Ghairi")) { ok ->
            if (ok) { bmUnlockedAt = System.currentTimeMillis(); onOk() }
        }
    }

    /** Futa data ukiondoka (kulingana na chaguo za Settings). Inaitwa app ikifungwa, au ikianza upya baada ya kufungwa kutoka Recents. */
    private fun runExitClear() {
        val m = store.clearWhat
        try {
            if ((m and 1) != 0) { store.clearHistory(); store.clearSearches() }
            if ((m and 2) != 0) {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
            }
            if ((m and 4) != 0) {
                if (tabs.any { it.wv != null }) forEachLive { it.clearCache(true); it.clearFormData() }
                else { val w = WebView(applicationContext); w.clearCache(true); w.clearFormData(); w.destroy() }
            }
            if ((m and 8) != 0) store.tabsJson = "{}"
        } catch (e: Exception) {
            // endelea; data iliyobaki itafutwa mara nyingine
        }
        store.exitPending = false
    }

    private fun unxml(s: String) = s.replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&#39;", "'").trim()

    private fun saveNewsCache() {
        val o = JSONObject()
        for ((k, l) in cats) {
            val a = JSONArray()
            l.forEach { a.put(JSONObject().put("t", it.title).put("l", it.link).put("s", it.src).put("i", it.img)) }
            o.put(k, a)
        }
        store.newsJson = o.toString()
    }

    private fun loadNewsCache() {
        try {
            val o = JSONObject(store.newsJson)
            o.keys().forEach { k ->
                val a = o.getJSONArray(k)
                cats[k] = (0 until a.length()).map {
                    val x = a.getJSONObject(it)
                    News(x.getString("t"), x.getString("l"), x.getString("s"), x.optString("i", ""))
                }
            }
        } catch (e: Exception) { }
    }

    /** Vichwa vya habari kutoka RSS yoyote, pamoja na picha (media:thumbnail / media:content / enclosure). */
    private fun parseFeed(xml: String, srcLabel: String, max: Int): List<News> {
        val dot = RegexOption.DOT_MATCHES_ALL
        val imgExt = Regex("""\.(jpe?g|png|webp)""", RegexOption.IGNORE_CASE)
        return Regex("<item>(.*?)</item>", dot).findAll(xml).take(max).mapNotNull { m ->
            val b = m.groupValues[1]
            val title = Regex("<title>(.*?)</title>", dot).find(b)?.groupValues?.get(1)?.let { unxml(it) } ?: return@mapNotNull null
            val link = Regex("<link>(.*?)</link>", dot).find(b)?.groupValues?.get(1)?.let { unxml(it) } ?: return@mapNotNull null
            val img = Regex("""<media:thumbnail[^>]*url=["']([^"']+)["']""").find(b)?.groupValues?.get(1)
                ?: Regex("""<media:content[^>]*url=["']([^"']+)["']""").findAll(b).map { it.groupValues[1] }.firstOrNull { imgExt.containsMatchIn(it) }
                ?: Regex("""<enclosure[^>]*url=["']([^"']+)["']""").findAll(b).map { it.groupValues[1] }.firstOrNull { imgExt.containsMatchIn(it) }
                ?: ""
            News(title, link.trim(), srcLabel, unxml(img).replace("http://", "https://"))
        }.toList()
    }

    /** Habari: Tanzania (Google News) + za kimataifa (BBC, Al Jazeera) zenye picha. */
    private fun loadNews(manual: Boolean = false) {
        Thread {
            val dot = RegexOption.DOT_MATCHES_ALL
            var ok = false
            try {
                val feed = if (store.lang == "sw") "https://news.google.com/rss?hl=sw&gl=TZ&ceid=TZ:sw"
                else "https://news.google.com/rss?hl=en-TZ&gl=TZ&ceid=TZ:en"
                val c = URL(feed).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 8000
                val xml = c.inputStream.bufferedReader().readText()
                c.disconnect()
                val items = Regex("<item>(.*?)</item>", dot).findAll(xml).take(8).mapNotNull { m ->
                    val b = m.groupValues[1]
                    val title = Regex("<title>(.*?)</title>", dot).find(b)?.groupValues?.get(1) ?: return@mapNotNull null
                    val link = Regex("<link>(.*?)</link>", dot).find(b)?.groupValues?.get(1) ?: return@mapNotNull null
                    val src = Regex("<source[^>]*>(.*?)</source>", dot).find(b)?.groupValues?.get(1) ?: ""
                    News(unxml(title).substringBeforeLast(" - "), unxml(link), unxml(src))
                }.toList()
                if (items.isNotEmpty()) { cats["tz"] = items; ok = true }
            } catch (e: Exception) { }

            val pool = Executors.newFixedThreadPool(4)
            for (f in feeds) {
                if (f.url.isEmpty()) continue
                try {
                    val c = URL(f.url).openConnection() as HttpURLConnection
                    c.connectTimeout = 6000
                    c.readTimeout = 8000
                    c.setRequestProperty("User-Agent", chromeUa)
                    val xml = c.inputStream.bufferedReader().readText()
                    c.disconnect()
                    val raw = parseFeed(xml, f.src, 6)
                    val futures = raw.map { n ->
                        if (n.img.isEmpty() && !store.dataSaver) pool.submit(Callable<String?> { ogImage(n.link) }) else null
                    }
                    val items = raw.mapIndexed { i, n ->
                        val got = try { futures[i]?.get(8, TimeUnit.SECONDS) } catch (e: Exception) { null }
                        if (got != null) n.copy(img = got) else n
                    }
                    if (items.isNotEmpty()) { cats[f.key] = items; ok = true }
                } catch (e: Exception) { }
            }
            pool.shutdown()
            if (ok) { store.newsUpdated = System.currentTimeMillis(); saveNewsCache() }
            runOnUiThread {
                if (manual) toast(if (ok) t("News updated", "Habari zimesasishwa")
                else t("Couldn't update news. Check your internet.", "Imeshindwa kusasisha habari. Angalia intaneti."))
                if (tabs.isNotEmpty() && fullUrl.isEmpty() && tabs[cur].pending == null) web.reload()
            }
        }.start()
    }

    /** og:image ya makala (picha ya habari) — inasoma mwanzo wa ukurasa tu. */
    private fun ogImage(pageUrl: String): String? {
        return try {
            val c = URL(pageUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 4000
            c.setRequestProperty("User-Agent", chromeUa)
            val buf = ByteArray(60000)
            var n = 0
            c.inputStream.use { ins ->
                while (n < buf.size) {
                    val r = ins.read(buf, n, buf.size - n)
                    if (r < 0) break
                    n += r
                }
            }
            c.disconnect()
            val head = String(buf, 0, n)
            val m = Regex("""<meta[^>]+(?:property|name)=["']og:image["'][^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(head)
                ?: Regex("""<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']og:image["']""", RegexOption.IGNORE_CASE).find(head)
            m?.groupValues?.get(1)?.let { unxml(URL(URL(pageUrl), it).toString()) }
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Kupokea viungo/maandishi kutoka apps nyingine ----------------

    /** Share, Open link, Search with Rahim Lux Go. Inafungua tab MPYA; tabs zilizopo haziguswi. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val ex = i.extras
        if (i.getStringExtra("rlg_dest") == null && ex != null && ex.containsKey("google.message_id")) {
            val d = HashMap<String, String>()
            for (k in ex.keySet()) {
                @Suppress("DEPRECATION") val v = ex.get(k)
                if (v is String) d[k] = v
            }
            d.remove("_direct")
            Notif.recordFromSystem(this, d)
            val (dest2, arg2) = Notif.destOf(d)
            if (dest2.isNotEmpty()) routeDest(dest2, arg2, null)
            return
        }
        val dest = i.getStringExtra("rlg_dest")
        if (dest != null) {
            routeDest(dest, i.getStringExtra("rlg_arg") ?: "", i.getStringExtra("rlg_nid"))
            return
        }
        val target: String? = when (i.action) {
            Intent.ACTION_VIEW -> {
                val d = i.dataString
                if (d == null) null
                else LinkParser.safeUrl(d) ?: run { toast(t("Unsupported link", "Kiungo hakitumiki")); null }
            }
            Intent.ACTION_SEND ->
                if (i.type?.startsWith("text/") == true) LinkParser.resolve(i.getCharSequenceExtra(Intent.EXTRA_TEXT)) { searchUrl(it) } else null
            Intent.ACTION_PROCESS_TEXT ->
                LinkParser.resolve(i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)) { searchUrl(it) }
            Intent.ACTION_WEB_SEARCH ->
                LinkParser.resolve(i.getStringExtra(SearchManager.QUERY)) { searchUrl(it) }
            else -> null
        }
        if (target == null) return
        exitFullscreen()
        if (tabs.isNotEmpty() && findBar.visibility == View.VISIBLE) closeFind()
        hideSuggestions()
        lastNav = System.currentTimeMillis()
        newTab(target)
    }

    /** Destination za arifa (match, notifications, downloads, settings, url). Zinakubali thamani zilizothibitishwa tu. */
    private fun routeDest(dest: String, arg: String, nid: String?) {
        if (nid != null) Notif.markRead(store, nid)
        lastNav = System.currentTimeMillis()
        when (dest) {
            "match" -> if (arg.isNotEmpty() && arg.length <= 12 && arg.all { it.isDigit() }) {
                startActivity(Intent(this, MatchActivity::class.java).putExtra("id", arg))
            }
            "notifications" -> startActivity(Intent(this, NotificationsActivity::class.java))
            "downloads" -> startActivity(Intent(this, DownloadsActivity::class.java))
            "settings" -> startActivity(Intent(this, NotificationSettingsActivity::class.java))
            "url" -> LinkParser.safeUrl(arg)?.let { newTab(it) }
        }
    }

    // ---------------- Hali ya hewa ----------------

    private fun weatherConfigured() = store.weatherOn && store.weatherUrl.isNotEmpty()

    /** Dakika 30 kati ya masasisho (seva ina cache pia). Ikifeli inajaribu tena baada ya dakika 5. */
    private fun loadWeather() {
        if (weatherBusy || !weatherConfigured()) return
        weatherBusy = true
        val base = store.weatherUrl
        val token = store.weatherToken
        val city = store.weatherCity
        Thread {
            val r = Weather.fetch(base, token, city)
            runOnUiThread {
                weatherBusy = false
                val now = System.currentTimeMillis()
                if (r.json != null) {
                    store.weatherJson = r.json
                    store.weatherAtMs = now
                    weatherErr = ""
                    weatherNext = now + 30 * 60 * 1000L
                } else {
                    weatherErr = r.error ?: "network"
                    weatherNext = now + 5 * 60 * 1000L
                }
                pushWeather()
            }
        }.start()
    }

    private fun pushWeather() {
        if (tabs.isEmpty() || fullUrl.isNotEmpty() || tabs[cur].pending != null) return
        val d = try { JSONObject(store.weatherJson) } catch (e: Exception) { JSONObject() }
        val p = JSONObject().put("d", d).put("at", store.weatherAtMs).put("err", weatherErr)
        web.evaluateJavascript("window.setWeather&&window.setWeather(" + p.toString().replace("<", "\\u003c") + ")", null)
    }

    // ---------------- Live scores ----------------

    private fun todayStr() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun scoresConfigured() = store.scoresOn && store.scoresUrl.isNotEmpty()

    private fun initScores() {
        val fresh = store.scoresDate == todayStr()
        scoresHasLive = fresh && Scores.hasLive(store.scoresJson)
        scoresNext = if (fresh) store.scoresAtMs + (if (scoresHasLive) 60_000L else 600_000L) else 0L
    }

    /** Inaita proxy mara moja (si kila sekunde): dakika 1 kukiwa na mechi live, dakika 10 vinginevyo; ikifeli inajaribu tena baadaye. */
    private fun loadScores() {
        if (scoresBusy || !scoresConfigured()) return
        scoresBusy = true
        val base = store.scoresUrl
        val token = store.scoresToken
        val date = todayStr()
        Thread {
            val r = Scores.fetch(base, token, date)
            runOnUiThread {
                scoresBusy = false
                val now = System.currentTimeMillis()
                if (r.matchesJson != null) {
                    store.scoresJson = r.matchesJson
                    store.scoresAtMs = now
                    store.scoresDate = date
                    store.scoresSrvMs = if (r.srvMs > 0) r.srvMs else now
                    store.scoresStale = r.stale || r.quota
                    scoresHasLive = r.hasLive
                    scoresErr = ""
                    scoresFails = 0
                    // Data ya zamani (quota ya API): usiulize mara kwa mara
                    scoresNext = now + (if (r.stale || r.quota) 300_000L else if (r.hasLive) 60_000L else 600_000L)
                } else {
                    scoresErr = r.error ?: "network"
                    scoresFails++
                    scoresNext = now + minOf(300_000L, 60_000L * (1L shl minOf(scoresFails - 1, 3)))
                }
                pushScores()
            }
        }.start()
    }

    /** Inasasisha sehemu ya scores ndani ya Home bila kupakia ukurasa upya. */
    private fun pushScores() {
        if (tabs.isEmpty() || fullUrl.isNotEmpty() || tabs[cur].pending != null) return
        val arr = try {
            if (store.scoresDate == todayStr()) JSONArray(store.scoresJson) else JSONArray()
        } catch (e: Exception) { JSONArray() }
        val p = JSONObject().put("m", arr).put("at", store.scoresAtMs).put("err", scoresErr)
            .put("f", JSONArray(store.follows().keys.toList()))
            .put("srv", store.scoresSrvMs).put("stale", store.scoresStale)
        web.evaluateJavascript("window.setScores&&window.setScores(" + p.toString().replace("<", "\\u003c") + ")", null)
    }

    // ---------------- Menyu ya long-press (kiungo / picha) ----------------

    private fun copyText(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", s))
        toast(t("Copied", "Imenakiliwa"))
    }

    private fun shareText(s: String) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, s) }
        startActivity(Intent.createChooser(i, t("Share via", "Tuma kupitia")))
    }

    private fun showContextMenu(link: String?, img: String?) {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        fun add(label: String, a: () -> Unit) { items.add(label to a) }
        if (link != null && link.startsWith("http")) {
            add(t("Open in new tab", "Fungua kwenye tab mpya")) { newTab(link) }
            add(t("Open in private tab", "Fungua kwenye tab ya faragha")) { newTab(link, true) }
            add(t("Copy link", "Nakili kiungo")) { copyText(link) }
            add(t("Share link", "Shiriki kiungo")) { shareText(link) }
        }
        if (img != null && img.startsWith("http")) {
            add(t("Download image", "Pakua picha")) { download(img, web.settings.userAgentString, "", "") }
            add(t("Open image in new tab", "Fungua picha kwenye tab mpya")) { newTab(img) }
            if (link == null) add(t("Copy image link", "Nakili kiungo cha picha")) { copyText(img) }
        }
        if (items.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle((link ?: img ?: "").take(60))
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }
            .show()
    }

    /** Mipangilio ikibadilishwa kwenye Settings, itumie kwenye tabs zote. */
    private fun applyAll() {
        weatherNext = 0L
        weatherErr = ""
        scoresNext = 0L
        scoresErr = ""
        forEachLive { w ->
            applyDark(w)
            applyDesktop(w)
            w.settings.blockNetworkImage = store.dataSaver
            CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.thirdCookies)
        }
        updateHint()
        if (store.lang != langAtOpen) { news = listOf(); cats.clear(); loadNews() }
        if (fullUrl.isEmpty()) web.reload()
    }

    private fun updateHint() {
        urlBar.hint = if (web.tag == "inc") t("🕶 Private tab", "🕶 Tab ya faragha")
        else t("Search or type address", "Tafuta au andika anwani")
    }

    // ---------------- URL bar, search, suggestions ----------------

    private fun setBar(s: String) { programmatic = true; urlBar.setText(s); programmatic = false }

    private fun pretty(u: String): String =
        if (u.isEmpty()) "" else (Uri.parse(u).host?.removePrefix("www.") ?: u)

    private fun isOfflineUrl(u: String): Boolean = try {
        val x = Uri.parse(u)
        x.host == homeHost && (x.path ?: "").startsWith("/offline/")
    } catch (e: Exception) { false }

    private var offlineShown = false

    private fun showUrl(u: String) {
        val off = isOfflineUrl(u)
        offlineShown = off
        fullUrl = if (off || Uri.parse(u).host == homeHost) "" else u
        if (!urlBar.hasFocus()) setBar(if (off) t("Offline page", "Ukurasa wa offline") else pretty(fullUrl))
        siteIcon.text = when {
            off -> "📥"
            fullUrl.isEmpty() -> "🔍"
            fullUrl.startsWith("https") -> "🔒"
            else -> "⚠️"
        }
        updateAd()
    }

    private fun updateAd() {
        adBox.visibility = if (fullUrl.isEmpty() && adOk && !kbOpen && !offlineShown) View.VISIBLE else View.GONE
    }

    private fun searchUrl(q: String): String {
        val e = Uri.encode(q)
        return when (store.engine) {
            "ddg" -> "https://duckduckgo.com/?q=$e"
            "bing" -> "https://www.bing.com/search?q=$e"
            "yahoo" -> "https://search.yahoo.com/search?p=$e"
            else -> "https://www.google.com/search?hl=" + (if (store.lang == "sw") "sw" else "en") + "&q=$e"
        }
    }

    private fun load(input: String) {
        val t = input.trim()
        val url = when {
            t.isEmpty() -> return
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(" ") && t.contains(".") -> "https://$t"
            else -> searchUrl(t)
        }
        hideSuggestions()
        lastNav = System.currentTimeMillis()
        web.loadUrl(url)
        urlBar.clearFocus()
    }

    private fun suggest(q: String) {
        suggestJob?.let { handler.removeCallbacks(it) }
        showSuggestions(q, emptyList())
        val seq = ++suggestSeq
        val r = Runnable {
            Thread {
                val list = try {
                    val lang = if (store.lang == "sw") "sw" else "en"
                    val enc = Uri.encode(q)
                    val endpoint = when (store.engine) {
                        "ddg" -> "https://duckduckgo.com/ac/?type=list&q=$enc"
                        "bing" -> "https://api.bing.com/osjson.aspx?query=$enc"
                        else -> "https://suggestqueries.google.com/complete/search?client=firefox&hl=$lang&q=$enc"
                    }
                    val c = URL(endpoint).openConnection() as HttpURLConnection
                    c.connectTimeout = 4000
                    c.readTimeout = 4000
                    val body = c.inputStream.bufferedReader().readText()
                    c.disconnect()
                    val a = JSONArray(body).getJSONArray(1)
                    (0 until a.length()).map { a.getString(it) }.take(8)
                } catch (e: Exception) {
                    emptyList<String>()
                }
                runOnUiThread { if (seq == suggestSeq) showSuggestions(q, list) }
            }.start()
        }
        suggestJob = r
        handler.postDelayed(r, 250)
    }

    /** Historia ya utafutaji (🕘) kwanza, kisha mapendekezo ya mtandaoni (🔍). */
    private fun showSuggestions(q: String, online: List<String>) {
        val ql = q.trim().lowercase()
        val hist = if (web.tag == "inc") listOf() else store.searches()
            .filter { ql.isEmpty() || it.lowercase().contains(ql) }
            .filter { it.lowercase() != ql }
            .take(if (ql.isEmpty()) 8 else 4)
        val seen = hist.map { it.lowercase() }.toMutableSet()
        val on = online.filter { seen.add(it.lowercase()) }
        val l = (hist.map { Sug(it, true) } + on.map { Sug(it, false) }).take(9)
        suggestions = l
        if (l.isEmpty() || !urlBar.hasFocus()) { suggestList.visibility = View.GONE; return }
        suggestList.adapter = ArrayAdapter(this, R.layout.item_suggest, l.map { (if (it.hist) "🕘  " else "🔍  ") + it.text })
        suggestList.visibility = View.VISIBLE
    }

    private fun recordSearch(incognito: Boolean, u: String) {
        if (incognito) return
        val uri = Uri.parse(u)
        val host = uri.host ?: return
        val path = uri.path ?: ""
        val q = when {
            host.contains("google.") && path == "/search" -> uri.getQueryParameter("q")
            host.endsWith("bing.com") && path == "/search" -> uri.getQueryParameter("q")
            host.endsWith("duckduckgo.com") && (path == "/" || path.isEmpty()) -> uri.getQueryParameter("q")
            host.endsWith("search.yahoo.com") && path == "/search" -> uri.getQueryParameter("p")
            else -> null
        }
        q?.trim()?.takeIf { it.length in 2..100 }?.let { store.addSearch(it) }
    }

    private fun hideSuggestions() {
        suggestSeq++
        suggestJob?.let { handler.removeCallbacks(it) }
        suggestList.visibility = View.GONE
    }

    private fun pickEngine() {
        val keys = listOf("google", "ddg", "bing", "yahoo")
        val names = listOf("Google", "DuckDuckGo", "Bing", "Yahoo")
        AlertDialog.Builder(this).setTitle(t("Search engine", "Injini ya kutafuta"))
            .setSingleChoiceItems(names.toTypedArray(), keys.indexOf(store.engine).coerceAtLeast(0)) { dlg, i ->
                store.engine = keys[i]
                dlg.dismiss()
                if (fullUrl.isEmpty()) web.reload()
                toast(t("Search engine: ", "Injini: ") + names[i])
            }.show()
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val vl = if (store.voiceLang == "sw") "sw-TZ" else "en-US"
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, vl)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, vl)
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (store.voiceLang == "sw") "Sema unachotafuta…" else "Say what you want to search")
        }
        try { voice.launch(i) } catch (e: Exception) {
            toast(t("Voice search is not available on this phone", "Voice search haipatikani kwenye simu hii"))
        }
    }

    // ---------------- Video / downloads ----------------

    private fun offerVideo(u: String) {
        videoUrl = u
        if (!kbOpen && fullUrl.isNotEmpty()) dlBtn.visibility = View.VISIBLE
    }

    private fun download(url: String, ua: String, cd: String, mime: String) {
        if (!url.startsWith("http")) { toast(t("This link can't be downloaded", "Kiungo hiki hakiwezi kupakuliwa")); return }
        val go: () -> Unit = {
            try {
                val name = URLUtil.guessFileName(url, cd, mime)
                val req = DownloadManager.Request(Uri.parse(url))
                if (mime.isNotEmpty()) req.setMimeType(mime)
                req.addRequestHeader("User-Agent", ua)
                web.url?.let { req.addRequestHeader("Referer", it) }
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                req.setNotificationVisibility(
                    if (store.nDownloads) DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    else DownloadManager.Request.VISIBILITY_HIDDEN
                )
                req.setTitle(name)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                toast(t("Downloading: ", "Inapakua: ") + name)
            } catch (e: Exception) {
                toast(t("Download failed", "Imeshindwa kupakua"))
            }
        }
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDl = go
            storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else go()
    }

    // ---------------- Home page ----------------

    private fun html(s: String) = WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(s.toByteArray()))
    /** Jibu la 404 kwa maombi yaliyozuiwa: players za video hazikwami zikisubiri tangazo. */
    private fun blocked() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", mapOf<String, String>(), ByteArrayInputStream(ByteArray(0))
    )

    private fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;")

    private fun floaters(): String {
        val sym = listOf("✦", "◆", "➤", "★", "⚡", "👑", "🌐", "✧", "▶", "●", "✦", "◆", "★", "✧")
        return sym.mapIndexed { i, s ->
            val left = (i * 83 + 7) % 94
            val size = 14 + (i * 7) % 22
            val dur = 14 + (i * 5) % 12
            val delay = -((i * 3) % 14)
            "<span style='left:$left%;font-size:${size}px;animation-duration:${dur}s;animation-delay:${delay}s'>$s</span>"
        }.joinToString("")
    }

    private fun homeHtml(inc: Boolean): String {
        val acc = if (inc) "#8E5CFF" else "#FFB300"
        val glow = if (inc) "rgba(142,92,255,.45)" else "rgba(255,179,0,.45)"
        val accGrad = if (inc) "linear-gradient(135deg,#C4A6FF,#8E5CFF 60%,#6D3DF0)" else "linear-gradient(135deg,#FFE082,#FFB300 55%,#FF8F00)"
        val accSoft = if (inc) "rgba(142,92,255,.26)" else "rgba(255,179,0,.26)"
        val ring = if (inc) "linear-gradient(120deg,#C4A6FF,#8E5CFF 50%,#E879F9)" else "linear-gradient(120deg,#8B5CF6,#22D3EE 55%,#FFB300)"
        val b3 = if (inc) "rgba(142,92,255,.16)" else "rgba(255,179,0,.13)"

        fun tile(i: Int, n: String, u: String): String {
            val c = brand[n] ?: palette[Math.abs(n.hashCode()) % palette.size]
            val host = (Uri.parse(u).host ?: "").removePrefix("www.").removePrefix("web.").removePrefix("m.")
            return "<a class=t style='animation-delay:${i * 45}ms' href='${esc(u)}'><i style='background:$c'><span>${esc(n.take(1).uppercase())}</span>" +
                "<img src='https://www.google.com/s2/favicons?domain=${esc(host)}&amp;sz=128' onload=\"this.style.background='#fff'\" onerror='this.remove()'></i>" +
                "<b>${esc(n)}</b></a>"
        }

        val all = store.sites()
        val fav = all.filter { it.first !in betNames }
        val bets = all.filter { it.first in betNames }
        val favHtml = fav.mapIndexed { i, s -> tile(i, s.first, s.second) }.joinToString("")
        val betHtml = bets.mapIndexed { i, s -> tile(i + fav.size, s.first, s.second) }.joinToString("")
        val favSection = if (fav.isEmpty()) "" else "<h2>${t("Favorites", "Vipendwa")}</h2><div class=g>$favHtml</div>"
        val betSection = if (bets.isEmpty()) "" else "<h2>${t("Sports &amp; betting · 18+", "Michezo na kubeti · 18+")}</h2><div class=g>$betHtml</div>"

        val groups = feeds.map { f -> Triple(f.key, t(f.en, f.sw), cats[f.key] ?: listOf()) }
        val firstKey = (groups.firstOrNull { it.third.isNotEmpty() } ?: groups.first()).first
        val newsSection = run {
            val chips = groups.joinToString("") { g ->
                "<button type=button class='chip${if (g.first == firstKey) " on" else ""}' onclick=\"sh('${g.first}',this)\">${esc(g.second)}</button>"
            }
            val lists = groups.joinToString("") { g ->
                val items = if (g.third.isEmpty()) {
                    "<div class=empty>${t("Loading news… (needs internet)", "Inapakia habari… (inahitaji intaneti)")}</div>"
                } else g.third.mapIndexed { j, n ->
                    val letter = esc(n.src.take(1).uppercase().ifEmpty { "N" })
                    val orig = n.img
                    val shown = if (j == 0 && orig.contains("ichef.bbci.co.uk")) orig.replace("/standard/240/", "/standard/624/") else orig
                    val img = if (orig.isNotEmpty())
                        "<img loading=lazy src='${esc(shown)}' data-o='${esc(orig)}' onerror=\"if(this.dataset.o&&this.src!=this.dataset.o){this.src=this.dataset.o}else{this.remove()}\">"
                    else ""
                    "<a class='n${if (j == 0) " big" else ""}' href='${esc(n.link)}'><div class=ph><em>$letter</em>$img</div>" +
                        "<div class=tx><b>${esc(n.title)}</b><span>${esc(n.src)}</span></div></a>"
                }.joinToString("")
                "<div class=nl id='n_${g.first}' style='display:${if (g.first == firstKey) "block" else "none"}'>$items</div>"
            }
            val upd = if (store.newsUpdated > 0)
                " · " + t("updated ", "imesasishwa ") + java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(store.newsUpdated))
            else ""
            "<h2>${t("News", "Habari")}$upd</h2><div class=chips>$chips</div>$lists"
        }

        val lang = if (store.lang == "sw") "sw" else "en"
        val (sAction, sName, sHidden, sLabel) = when (store.engine) {
            "ddg" -> listOf("https://duckduckgo.com/", "q", "", "DuckDuckGo")
            "bing" -> listOf("https://www.bing.com/search", "q", "", "Bing")
            "yahoo" -> listOf("https://search.yahoo.com/search", "p", "", "Yahoo")
            else -> listOf("https://www.google.com/search", "q", "<input type=hidden name=hl value=$lang>", "Google")
        }
        val placeholder = t("Search with $sLabel", "Tafuta kwa $sLabel")

        val on = "ON"
        val off = "OFF"
        val ds = if (store.dataSaver) on else off
        val ab = if (store.adblock) on else off
        val logo = if (inc) "<div class=lg>&#128374;</div>" else "<img class=lg src='/logo.png'>"
        val tag = if (inc) t("Private tab: history is not saved", "Tab ya faragha: historia haihifadhiwi")
        else t("Fast, secure and smart browser", "Kivinjari cha haraka na salama")
        val lBlocked = t("Blocked", "Vilivyozuiwa")
        val gm = t("Good morning", "Habari za asubuhi")
        val ga = t("Good afternoon", "Habari za mchana")
        val ge = t("Good evening", "Habari za jioni")

        // HALI YA HEWA (OpenWeather kupitia seva yako)
        val wxOn = store.weatherOn && store.weatherUrl.isNotEmpty()
        val wxSection = if (!wxOn) "" else
            "<h2>${t("Weather", "Hali ya hewa")}<span id=wxu></span></h2><div id=wx class=wx></div>"
        val wxData = try { JSONObject(store.weatherJson) } catch (e: Exception) { JSONObject() }
        val wxInit = JSONObject().put("d", wxData).put("at", store.weatherAtMs).put("err", weatherErr)
            .put("cfg", wxOn).put("sw", store.lang == "sw")
            .put("i", JSONObject()
                .put("feels", t("Feels like", "Inahisi"))
                .put("today", t("Today", "Leo"))
                .put("upd", t("updated ", "imesasishwa "))
                .put("old", t("old data", "data ya zamani"))
                .put("load", t("Loading weather…", "Inapakia hali ya hewa…"))
                .put("fail", t("Couldn't load the weather. Check your internet.", "Imeshindwa kupakia hali ya hewa. Angalia intaneti."))
                .put("setup", t("Weather is not set up on the server yet.", "Hali ya hewa haijawekwa kwenye seva bado."))
                .put("key", t("The weather key is invalid or not active yet (new keys can take up to 2 hours).", "Ufunguo wa hali ya hewa si sahihi au bado haujaamka (mpya huchukua hadi saa 2)."))
                .put("city", t("City not found. Change it in Settings > Weather.", "Mji haujapatikana. Ubadilishe kwenye Settings > Weather.")))
            .toString().replace("<", "\\u003c")

        // LIVE SCORES (taarifa za mpira tu) — inaonekana ikiwa proxy imewekwa
        val scoresSection = if (!store.scoresOn || store.scoresUrl.isEmpty()) "" else
            "<h2>LIVE SCORES<span id=lsu></span></h2><div class=stabs>" +
                "<button type=button class='stab on' data-t=live onclick=\"lsTab('live')\"></button>" +
                "<button type=button class=stab data-t=up onclick=\"lsTab('up')\"></button>" +
                "<button type=button class=stab data-t=fin onclick=\"lsTab('fin')\"></button></div>" +
                "<div id=ls class=ls></div>"
        val scArr = try {
            if (store.scoresDate == todayStr()) JSONArray(store.scoresJson) else JSONArray()
        } catch (e: Exception) { JSONArray() }
        val scInit = JSONObject()
            .put("m", scArr).put("at", store.scoresAtMs).put("err", scoresErr).put("cfg", scoresSection.isNotEmpty())
            .put("f", JSONArray(store.follows().keys.toList()))
            .put("srv", store.scoresSrvMs).put("stale", store.scoresStale)
            .put("tab", "live")
            .put("i", JSONObject()
                .put("live", "LIVE")
                .put("up", t("UPCOMING", "ZINAZOKUJA"))
                .put("fin", t("FINISHED", "ZIMEMALIZIKA"))
                .put("noLive", t("No matches are being played right now.", "Hakuna mechi zinazoendelea kwa sasa."))
                .put("noUp", t("No upcoming matches today.", "Hakuna mechi zinazokuja leo."))
                .put("noFin", t("No finished matches yet.", "Hakuna mechi zilizomalizika bado."))
                .put("fail", t("Couldn't load scores. Check your internet.", "Imeshindwa kupakia scores. Angalia intaneti."))
                .put("upd", t("updated ", "imesasishwa "))
                .put("off", t("offline", "nje ya mtandao"))
                .put("late", t("delayed data", "data ya zamani")))
            .toString().replace("<", "\\u003c")

        // MSIMAMO WA LIGI (EPL na NBC Premier League zipo kila mara, kisha La Liga, Serie A, Bundesliga, Ligue 1...)
        val stdOn = store.standingsOn && store.standingsUrl.isNotEmpty()
        val stdSection = if (!stdOn) "" else
            "<h2>${t("League tables", "Msimamo wa ligi")}</h2><div id=stc class=stc></div><div id=std class=std></div>"
        val stdLeagues = JSONArray()
        listOf(
            "epl" to "EPL", "nbc" to "NBC", "laliga" to "La Liga", "seriea" to "Serie A", "bundesliga" to "Bundesliga",
            "ligue1" to "Ligue 1", "ucl" to "UCL", "eredivisie" to "Eredivisie", "primeira" to "Primeira", "championship" to "Championship"
        ).forEach { stdLeagues.put(JSONObject().put("k", it.first).put("s", it.second)) }
        val stdInit = JSONObject().put("base", store.standingsUrl.trim().trimEnd('/')).put("token", store.standingsToken)
            .put("cfg", stdOn).put("sel", "epl").put("leagues", stdLeagues)
            .put("i", JSONObject()
                .put("team", t("Team", "Timu"))
                .put("upd", t("updated ", "imesasishwa "))
                .put("old", t("old data", "data ya zamani"))
                .put("load", t("Loading table…", "Inapakia msimamo…"))
                .put("fail", t("Couldn't load the table. Check your internet.", "Imeshindwa kupakia msimamo. Angalia intaneti."))
                .put("plan", t("This league's table isn't available on the server's football plan for the current season.", "Msimamo wa ligi hii haupatikani kwenye mpango wa mpira wa seva kwa msimu huu."))
                .put("quota", t("The daily football API limit was reached. Try again later.", "Kikomo cha siku cha API ya mpira kimefikiwa. Jaribu tena baadaye."))
                .put("setup", t("League tables are not set up on the server yet.", "Msimamo wa ligi haujawekwa kwenye seva bado."))
                .put("unavailable", t("This league's table is not available right now. Choose another league or try again later.", "Msimamo wa ligi hii haupatikani kwa sasa. Chagua ligi nyingine au jaribu tena baadaye."))
                .put("network", t("Couldn't reach the standings server. Check your connection and server URL.", "Imeshindwa kufikia seva ya msimamo. Angalia intaneti na anwani ya seva."))
                .put("zUcl", "Champions League").put("zUel", "Europa League").put("zUecl", "Conference / CAF")
                .put("zPromo", t("Promotion", "Kupanda")).put("zRel", t("Relegation", "Kushuka")))
            .toString().replace("<", "\\u003c")

        // TIMU PENDWA (Favorite Team): kadi ya glassmorphism + kipaumbele kwenye Live Scores na Msimamo
        val ssSection = "<a class=ssc href='rlg://status'><span>\uD83D\uDCBE</span><div><b>WhatsApp Status Saver</b><small>" +
            t("View and save the statuses you watched", "Tazama na uhifadhi status ulizoziona") + "</small></div></a>"
        val favHead = if (store.favOn) "<link rel=stylesheet href='/fav.css'>" else ""
        val favBody = if (store.favOn) "<script src='/fav.js'></script>" else ""
        val myTeamSection = if (store.favOn) "<div id=myteam class=myteam></div>" else ""

        // THEME SWITCHER (Gold Lux / Neon Cyan / Emerald Green / Light Mode). Tab ya faragha inabaki zambarau.
        val themeHead = if (inc) "" else "<script>try{var tt=localStorage.getItem('rlg-theme');if(['aurora','gold','cyan','emerald','light'].indexOf(tt)>=0)document.documentElement.setAttribute('data-theme',tt)}catch(e){}</script><link rel=stylesheet href='/theme.css'>"
        val themeSection = if (inc) "" else "<h2>${t("Theme", "Mandhari")}</h2><div id=theme-switcher></div>"
        val themeBody = if (inc) "" else "<script src='/theme.js'></script>"
        val hasBg = store.bgVersion > 0 && Background.exists(applicationContext)
        val htmlAttrs = if (hasBg) " class=has-bg style='--bgdim:" + String.format(Locale.US, "%.2f", store.bgDim / 100.0) + "'" else ""
        val bgCss = if (!hasBg) "" else "<style>" +
            "html.has-bg body::before{content:'';position:fixed;left:0;top:0;right:0;bottom:0;z-index:-2;background:url('/bg.jpg?v=" + store.bgVersion + "') center/cover no-repeat}" +
            "html.has-bg body::after{content:'';position:fixed;left:0;top:0;right:0;bottom:0;z-index:-1;background:rgba(var(--veil-rgb,0,0,0),var(--bgdim,.45))}" +
            "html.has-bg .t,html.has-bg .n,html.has-bg .mc,html.has-bg .wx,html.has-bg .s,html.has-bg .wxc,html.has-bg .std,html.has-bg .ssc{background:var(--glass,rgba(12,12,14,.55))!important;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px)}" +
            "html.has-bg h1,html.has-bg h2,html.has-bg p,html.has-bg .hi{text-shadow:0 1px 4px rgba(0,0,0,.55)}</style>"
        val bgLink = "<div style='margin:14px 0 0'><a href='rlg://bg' style='color:inherit;opacity:.75;font-size:12px;text-decoration:none'>\uD83D\uDDBC " + t("Change background", "Badilisha picha ya nyuma") + "</a></div>"

        return """<!doctype html><html lang='$lang'$htmlAttrs><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><meta name=color-scheme content=dark><title>Rahim Lux Go</title><style>
:root{--bg:#07070F;--bg2:#0E0E26;--b1:rgba(124,58,237,.40);--b2:rgba(34,211,238,.22);--b3:$b3;
--surface:rgba(255,255,255,.06);--surface-strong:rgba(20,20,46,.92);--border:rgba(255,255,255,.11);
--text:#F5F3FF;--text-soft:#DDD6FE;--muted:#B7B5D8;--muted-2:#8F8DB5;
--accent:$acc;--accent-2:#FF8F00;--accent-grad:$accGrad;--on-accent:#1A1200;--accent-soft:$accSoft;--glow:$glow;
--glass:rgba(14,14,34,.62);--veil-rgb:0,0,0;--field:rgba(11,11,28,.92);
--ring:$ring;
--card:linear-gradient(150deg,rgba(255,255,255,.11),rgba(255,255,255,.035));
--shadow:0 12px 34px rgba(0,0,0,.40);--wx1:rgba(124,58,237,.42);--wx2:rgba(34,211,238,.16);
--h1a:#FFFFFF;--h1b:#DDD6FE}
html{background:var(--bg)}
body{margin:0;min-height:100vh;background:transparent;color:var(--text);font-family:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",sans-serif;text-align:center;box-sizing:border-box;-webkit-font-smoothing:antialiased}
.c{position:relative;z-index:1;padding:26px 16px 44px}
.f{position:fixed;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;z-index:0}
.f::before{content:'';position:absolute;left:0;top:0;right:0;bottom:0;background:radial-gradient(75% 42% at 6% -6%,var(--b1),transparent 72%),radial-gradient(65% 38% at 104% 6%,var(--b2),transparent 72%),radial-gradient(90% 46% at 50% 112%,var(--b3),transparent 72%),linear-gradient(180deg,var(--bg2) 0%,var(--bg) 58%)}
.f::after{content:'';position:absolute;left:-30%;top:-10%;width:90%;height:60%;background:radial-gradient(closest-side,var(--b2),transparent);opacity:.5;animation:drift 22s ease-in-out infinite alternate;will-change:transform}
html.has-bg .f::before,html.has-bg .f::after{display:none}
@keyframes drift{to{transform:translate3d(45%,18%,0) scale(1.15)}}
.f span{position:absolute;bottom:-60px;color:var(--accent);opacity:0;animation-name:up;animation-timing-function:linear;animation-iteration-count:infinite}
@keyframes up{0%{transform:translateY(0) rotate(0deg);opacity:0}12%{opacity:.22}85%{opacity:.18}100%{transform:translateY(-115vh) rotate(300deg);opacity:0}}
@keyframes in{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.35;transform:scale(.7)}}
.lg{width:96px;height:96px;border-radius:28px;margin:4px auto 0;display:flex;align-items:center;justify-content:center;font-size:42px;background:var(--accent-grad);box-shadow:0 0 0 1px rgba(255,255,255,.14),0 16px 44px rgba(124,58,237,.45),0 0 70px var(--glow);animation:float 5.5s ease-in-out infinite}
img.lg{display:block;background:none;object-fit:cover}
h1{margin:16px 0 4px;font-size:32px;font-weight:800;letter-spacing:-.6px;line-height:1.1;background:linear-gradient(90deg,var(--h1a) 30%,var(--h1b));-webkit-background-clip:text;background-clip:text;color:transparent}
h1 span{background:var(--accent-grad);-webkit-background-clip:text;background-clip:text;color:transparent}
.hi{display:inline-block;margin:2px 0 0;padding:5px 14px;border-radius:999px;background:var(--surface);border:1px solid var(--border);color:var(--text-soft);font-size:12.5px;font-weight:600;letter-spacing:.02em}
.hi:empty{display:none}
p{margin:8px 0 20px;color:var(--muted);font-size:13px}
.sb{display:flex;align-items:center;max-width:420px;margin:0 auto 6px;border:1.5px solid transparent;border-radius:32px;padding:5px 6px 5px 20px;background:linear-gradient(var(--field),var(--field)) padding-box,var(--ring) border-box;box-shadow:0 12px 34px rgba(124,58,237,.30),0 0 0 5px rgba(255,255,255,.03)}
.sb input{flex:1;min-width:0;background:transparent;border:0;outline:0;color:var(--text);font-size:16px;padding:12px 0}
.sb input::placeholder{color:var(--muted-2)}
.sb button{width:44px;height:44px;border-radius:22px;border:0;background:var(--accent-grad);color:var(--on-accent);font-size:18px;box-shadow:0 6px 18px var(--glow)}
.sb button:active{transform:scale(.93)}
h2{font-size:11px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);text-align:left;max-width:420px;margin:26px auto 12px;padding-left:4px}
h2::before{content:'';display:inline-block;vertical-align:middle;width:18px;height:3px;border-radius:3px;margin-right:9px;background:var(--accent-grad);box-shadow:0 0 10px var(--glow)}
h2 span{color:var(--muted-2);font-weight:600}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;max-width:420px;margin:0 auto}
.t{display:block;text-decoration:none;color:var(--text);font-size:11px;padding:13px 2px 10px;border-radius:22px;background:var(--card);border:1px solid var(--border);box-shadow:0 8px 20px rgba(0,0,0,.28);animation:in .5s both}
.t:active{transform:scale(.95)}
.t i{display:block;position:relative;overflow:hidden;width:54px;height:54px;border-radius:18px;margin:0 auto 9px;line-height:54px;font-style:normal;font-size:22px;font-weight:700;color:#fff;box-shadow:0 8px 16px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.28)}
.t i img{position:absolute;left:0;top:0;width:100%;height:100%;box-sizing:border-box;padding:10px;object-fit:contain}
.t b{font-weight:600;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 3px}
.chips{display:flex;gap:8px;max-width:420px;margin:-4px auto 8px;overflow-x:auto;padding:8px 8px 14px}
.chip{flex:none;white-space:nowrap;border:1px solid var(--border);background:var(--surface);color:var(--text);border-radius:999px;padding:8px 15px;font-size:12px;font-weight:600}
.chip.on{background:var(--accent-grad);color:var(--on-accent);border-color:transparent;font-weight:800;box-shadow:0 6px 16px var(--glow)}
.nl{max-width:420px;margin:0 auto}
.wx{position:relative;overflow:hidden;max-width:420px;margin:0 auto;text-align:left;background:linear-gradient(145deg,var(--wx1),var(--wx2) 62%,var(--surface));border:1px solid var(--border);border-radius:26px;padding:16px 14px 10px;box-shadow:var(--shadow)}
.wx::before{content:'';position:absolute;right:-40px;top:-50px;width:180px;height:180px;border-radius:50%;background:radial-gradient(closest-side,rgba(255,255,255,.18),transparent);pointer-events:none}
.wx>*{position:relative}
.wxt{display:flex;align-items:center;gap:12px}
.wxi{font-size:46px;line-height:1;filter:drop-shadow(0 6px 10px rgba(0,0,0,.35))}
.wxm{display:flex;flex-direction:column;min-width:0}
.wxm b{font-size:36px;line-height:1;font-weight:800;color:var(--text)}
.wxm span{font-size:12px;color:var(--muted);margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:130px}
.wxd{flex:1;text-align:right;font-size:12px;color:var(--muted)}
.wxn{font-size:14px;color:var(--text);font-weight:700;margin-bottom:3px}
.wxs{line-height:1.5}
.wxh{display:flex;gap:6px;margin-top:14px;overflow-x:auto}
.wxc{flex:1 0 48px;display:flex;flex-direction:column;align-items:center;gap:2px;background:rgba(255,255,255,.07);border:1px solid var(--border);border-radius:14px;padding:7px 2px;font-size:11px;color:var(--muted)}
.wxc em{font-style:normal;font-size:18px}.wxc b{color:var(--text);font-size:13px}.wxc i{font-style:normal;font-size:9px;color:#7DD3FC}
.wxdays{margin-top:10px;border-top:1px solid var(--border);padding-top:6px}
.wxr{display:flex;align-items:center;gap:10px;padding:4px 2px;font-size:12px;color:var(--muted)}
.wxr span{width:34px}.wxr em{font-style:normal;font-size:16px;width:24px}.wxr b{margin-left:auto;color:var(--text);font-weight:700}
.wxe{color:var(--muted-2);font-size:13px;padding:10px 4px;text-align:center}
.ssc{position:relative;overflow:hidden;display:flex;align-items:center;gap:14px;max-width:420px;margin:16px auto 0;padding:14px 16px;border-radius:22px;text-decoration:none;color:var(--text);text-align:left;background:var(--card);border:1px solid var(--border);box-shadow:var(--shadow)}
.ssc::before{content:'';position:absolute;left:0;top:0;right:0;bottom:0;background:radial-gradient(80% 160% at 0% 0%,var(--b1),transparent 70%);opacity:.7;pointer-events:none}
.ssc span{position:relative;flex:none;width:46px;height:46px;border-radius:15px;display:flex;align-items:center;justify-content:center;font-size:24px;background:var(--accent-grad);box-shadow:0 8px 18px var(--glow)}
.ssc div{position:relative}
.ssc b{display:block;font-size:14px}
.ssc small{display:block;font-size:11px;color:var(--muted);margin-top:2px}
.stc{display:flex;gap:8px;max-width:420px;margin:-4px auto 4px;overflow-x:auto;padding:8px 8px 14px}
.sc2{flex:none;white-space:nowrap;border:1px solid var(--border);background:var(--surface);color:var(--text);border-radius:999px;padding:7px 13px;font-size:11px;font-weight:600}
.sc2.on{background:var(--accent-grad);color:var(--on-accent);border-color:transparent;font-weight:800;box-shadow:0 6px 16px var(--glow)}
.std{max-width:420px;margin:0 auto;text-align:left;background:var(--card);border:1px solid var(--border);border-radius:24px;padding:10px 8px 12px;box-shadow:var(--shadow)}
.stm{font-size:11px;color:var(--muted);padding:4px 6px 8px}
.stg{font-size:11px;color:var(--accent);font-weight:700;padding:8px 6px 2px}
.str{display:grid;grid-template-columns:22px 1fr 24px 24px 24px 24px 32px 30px;align-items:center;gap:2px;padding:6px;font-size:12px;color:var(--text);border-left:3px solid transparent;border-radius:8px}
.str:nth-child(odd){background:rgba(255,255,255,.04)}
.str span{text-align:center}.str .stt{text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:4px}.str .stp{font-weight:800}
.sth{font-size:10px;color:var(--muted-2);text-transform:uppercase}
.z-ucl{border-left-color:#34D399}.z-uel{border-left-color:#FB923C}.z-uecl{border-left-color:#22D3EE}.z-promo{border-left-color:#A3E635}.z-rel{border-left-color:#FB7185}
.stl{display:flex;flex-wrap:wrap;gap:10px;padding:8px 6px 0;font-size:10px;color:var(--muted)}
.zc-ucl{color:#34D399}.zc-uel{color:#FB923C}.zc-uecl{color:#22D3EE}.zc-promo{color:#A3E635}.zc-rel{color:#FB7185}
.ste{color:var(--muted-2);font-size:13px;padding:14px 6px;text-align:center}
.stabs{display:flex;gap:8px;max-width:420px;margin:0 auto 10px}
.stab{flex:none;white-space:nowrap;border:1px solid var(--border);background:var(--surface);color:var(--text);border-radius:999px;padding:7px 13px;font-size:11px;font-weight:600}
.stab.on{background:var(--accent-grad);color:var(--on-accent);border-color:transparent;font-weight:800;box-shadow:0 6px 16px var(--glow)}
.ls{display:flex;gap:10px;overflow-x:auto;max-width:420px;margin:0 auto;padding:10px 8px 14px}
.mc{flex:0 0 156px;text-align:left;background:var(--card);border:1px solid var(--border);border-radius:20px;padding:11px 13px;box-shadow:0 8px 20px rgba(0,0,0,.28)}
.ml{font-size:10px;font-weight:600;color:var(--muted-2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:6px}
.mr{display:flex;justify-content:space-between;gap:8px;font-size:13px;line-height:1.6;color:var(--text)}
.mr .mt{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.mr b{color:var(--text)}
.mb{margin-top:7px;font-size:11px;color:var(--muted)}
.mb.live{color:#FF6B6B;font-weight:800}
.lsempty{color:var(--muted-2);font-size:13px;padding:14px 4px;text-align:center;width:100%}
.empty{color:var(--muted-2);font-size:13px;padding:18px 4px;text-align:center}
.n{display:flex;align-items:center;gap:12px;text-align:left;text-decoration:none;color:var(--text);background:var(--card);border:1px solid var(--border);border-radius:20px;padding:10px;margin:0 0 10px;box-shadow:0 8px 20px rgba(0,0,0,.26)}
.n .ph{position:relative;overflow:hidden;flex:0 0 84px;height:84px;border-radius:14px;background:linear-gradient(135deg,var(--b1),var(--b2))}
.n .ph em{position:absolute;left:0;right:0;top:50%;margin-top:-16px;font-style:normal;font-size:24px;font-weight:800;line-height:32px;color:rgba(255,255,255,.55);text-align:center}
.n .ph img{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:cover}
.n .tx{flex:1;min-width:0}
.n b{display:block;font-size:14px;font-weight:650;line-height:1.38;color:var(--text)}
.n span{display:block;margin-top:6px;font-size:11px;font-weight:600;color:var(--accent)}
.n.big{display:block;padding:0 0 12px;overflow:hidden}
.n.big .ph{width:100%;height:178px;border-radius:20px 20px 0 0}
.n.big .ph::after{content:'';position:absolute;left:0;right:0;bottom:0;height:55%;background:linear-gradient(transparent,rgba(7,7,15,.6))}
.n.big .tx{padding:11px 15px 0}
.s{margin:28px auto 0;max-width:420px;background:var(--card);border:1px solid var(--border);border-radius:24px;padding:16px 8px;display:flex;justify-content:space-around;box-shadow:var(--shadow)}
.s div{flex:1;font-size:11px;color:var(--muted)}.s div+div{border-left:1px solid var(--border)}
.s strong{display:block;font-size:22px;font-weight:800;margin-bottom:3px;background:var(--accent-grad);-webkit-background-clip:text;background-clip:text;color:transparent}
</style>$bgCss$themeHead$favHead</head><body>
<div class=f>${floaters()}</div>
<div class=c>
$logo
<h1>Rahim Lux <span>Go</span></h1>
<div class=hi id=hi></div>
<p>$tag</p>
<form class=sb action='$sAction' method=get>$sHidden<input name='$sName' placeholder='$placeholder' autocomplete=off><button type=submit>&#128269;</button></form>
$favSection
$ssSection
$wxSection
$myTeamSection
$scoresSection
$stdSection
$betSection
$newsSection
<div class=s><div><strong>${store.blocked}</strong>$lBlocked</div><div><strong>$ds</strong>Data saver</div><div><strong>$ab</strong>Ad-block</div></div>
$themeSection
$bgLink
</div>
<script>var h=new Date().getHours();document.getElementById('hi').textContent=h<12?'$gm':h<18?'$ga':'$ge';function sh(k,b){var l=document.querySelectorAll('.nl');for(var i=0;i<l.length;i++){l[i].style.display=l[i].id=='n_'+k?'block':'none'}var c=document.querySelectorAll('.chip');for(var j=0;j<c.length;j++){c[j].classList.remove('on')}b.classList.add('on')}</script>
$favBody
<script>var SC=$scInit;</script>
<script>${ScoresJs.CODE}</script>
<script>var WX=$wxInit;</script>
<script>${WeatherJs.CODE}</script>
<script>var STD=$stdInit;</script>
<script>${StandingsJs.CODE}</script>
$themeBody
</body></html>"""
    }

    // ---------------- Tab switcher ----------------

    private fun sheetWindow(d: Dialog) {
        d.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }

    // ---------------- v46: Smart Tab Manager ----------------
    private fun webOf(t: Tab): WebView {
        t.wv?.let { return it }
        val w = buildWebView(t.incognito)
        t.wv = w
        return w
    }

    private fun tabOf(v: WebView): Tab? = tabs.firstOrNull { it.wv === v }

    private fun forEachLive(f: (WebView) -> Unit) { for (t in tabs.toList()) t.wv?.let(f) }

    private val janitor = object : Runnable {
        override fun run() { trimTabs(); handler.postDelayed(this, 60_000) }
    }

    private fun archiveClosed(t: Tab) {
        if (t.incognito) return
        val u = t.currentUrl()
        if (!u.startsWith("http") || isOfflineUrl(u) || Uri.parse(u).host == homeHost) return
        TabArchive.pushClosed(store, u, t.wv?.title?.takeIf { it.isNotBlank() } ?: t.title)
    }

    private fun destroyTab(t: Tab) {
        val w = t.wv ?: return
        pageHosts.remove(w)
        try {
            if (t.incognito) { w.clearCache(true); w.clearHistory() }
            w.stopLoading()
            w.destroy()
        } catch (_: Exception) { }
        t.wv = null
    }

    /** Inalaza tab ya nyuma: inaachilia WebView na kumbukumbu yake; ukurasa unapakiwa tena ukiufungua. */
    private fun sleepTab(t: Tab) {
        val w = t.wv ?: return
        if (tabs.getOrNull(cur) === t) return
        val u = w.url ?: ""
        if (u.startsWith("http")) { t.url = u; t.pending = u } else t.pending = t.url.ifEmpty { home }
        w.title?.takeIf { it.isNotBlank() }?.let { t.title = it }
        pageHosts.remove(w)
        try { w.stopLoading(); w.onPause(); w.destroy() } catch (_: Exception) { }
        t.wv = null
    }

    /** Inalaza tab za nyuma kulingana na Settings > Smart tab saver (Off / Balanced / Aggressive). */
    private fun trimTabs() {
        if (tabs.size < 2 || store.tabSleep == 0) return
        val aggressive = store.tabSleep == 2
        val cap = if (aggressive) 1 else 3
        val idle = if (aggressive) 3 * 60_000L else 15 * 60_000L
        val now = System.currentTimeMillis()
        val cands = tabs.mapIndexed { i, t ->
            TabPolicy.Cand(i, t.lastUsed, t.wv != null, t.wv?.let { w -> w.progress in 1..99 } == true)
        }
        for (i in TabPolicy.toSleep(cands, cur, now, cap, idle, 20_000L)) sleepTab(tabs[i])
    }

    private fun closeTabs(list: List<Tab>) {
        val victims = list.filter { it in tabs }
        if (victims.isEmpty()) return
        val curTab = tabs.getOrNull(cur)
        val closingCurrent = victims.any { it === curTab }
        if (closingCurrent) container.removeAllViews()
        for (v in victims) { archiveClosed(v); tabs.remove(v); destroyTab(v) }
        if (tabs.isEmpty()) { newTab(home); return }
        cur = if (closingCurrent) minOf(cur, tabs.size - 1) else tabs.indexOf(curTab).coerceAtLeast(0)
        show(cur)
    }

    private fun addSleepingTab(url: String, title: String): Tab {
        val t = Tab(null, url, title, false)
        t.pending = url
        tabs.add(t)
        return t
    }

    private fun ago(ts: Long): String {
        val m = (System.currentTimeMillis() - ts) / 60_000
        return when {
            m < 1 -> t("now", "sasa hivi")
            m < 60 -> t("$m min ago", "dakika $m zilizopita")
            m < 60 * 24 -> t("${m / 60} h ago", "saa ${m / 60} zilizopita")
            else -> t("${m / (60 * 24)} d ago", "siku ${m / (60 * 24)} zilizopita")
        }
    }

    private fun tabCard(d: Dialog, tab: Tab, isCur: Boolean): View {
        val u = tab.currentUrl()
        val off = isOfflineUrl(u)
        val isHome = !off && (u.isEmpty() || Uri.parse(u).host == homeHost)
        val inc = tab.incognito
        val hide = inc && store.lockPriv && !fresh(privUnlockedAt)
        val ttl = tab.wv?.title?.takeIf { it.isNotBlank() } ?: tab.title
        val name = if (hide) t("Private tab", "Tab ya faragha") else if (isHome) "Home" else (ttl.takeIf { it.isNotBlank() }?.take(40) ?: pretty(u))
        val where = if (isHome) t("Start page", "Ukurasa wa mwanzo") else if (off) t("Offline page", "Ukurasa wa offline") else pretty(u)
        val sub = if (hide) "🔒" else where + " · " + ago(tab.lastUsed) + (if (tab.wv == null) " · 💤" else "")

        val card = LinearLayout(this)
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(12), dp(6), dp(12))
        card.background = resources.getDrawable(if (isCur) R.drawable.bg_card_cur else R.drawable.bg_card, theme)
        if (tab.wv == null) card.alpha = 0.8f

        val badge = TextView(this)
        badge.text = if (inc) "🕶" else if (isHome) "🏠" else pretty(u).take(1).uppercase().ifEmpty { "•" }
        badge.gravity = Gravity.CENTER; badge.textSize = 16f; badge.setTextColor(Color.WHITE)
        badge.background = resources.getDrawable(R.drawable.bg_icon, theme)
        card.addView(badge, LinearLayout.LayoutParams(dp(40), dp(40)))

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        val tt = TextView(this)
        tt.text = name; tt.setTextColor(Color.WHITE); tt.textSize = 14f; tt.setTypeface(null, Typeface.BOLD)
        tt.maxLines = 1; tt.ellipsize = TextUtils.TruncateAt.END
        val ss = TextView(this)
        ss.text = sub; ss.setTextColor(Color.parseColor("#9C9ABF")); ss.textSize = 12f
        ss.maxLines = 1; ss.ellipsize = TextUtils.TruncateAt.END
        info.addView(tt); info.addView(ss)
        val ilp = LinearLayout.LayoutParams(0, -2, 1f)
        ilp.marginStart = dp(12)
        card.addView(info, ilp)

        val x = TextView(this)
        x.text = "✕"; x.setTextColor(Color.parseColor("#B7B5D6")); x.textSize = 16f
        x.setPadding(dp(12), dp(8), dp(12), dp(8))
        x.setOnClickListener { closeTabs(listOf(tab)); d.dismiss(); showTabs() }
        card.addView(x)
        card.setOnClickListener { d.dismiss(); val i = tabs.indexOf(tab); if (i >= 0) show(i) }
        return card
    }

    private fun showTabs() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = resources.getDrawable(R.drawable.bg_sheet, theme)
        root.setPadding(dp(16), dp(16), dp(16), dp(16))

        val liveCount = tabs.count { it.wv != null }
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "Tabs (${tabs.size})"
        title.setTextColor(Color.WHITE); title.textSize = 18f; title.setTypeface(null, Typeface.BOLD)
        val sub = TextView(this)
        sub.text = t("$liveCount active · ${tabs.size - liveCount} sleeping", "$liveCount zinatumika · ${tabs.size - liveCount} zimelala")
        sub.setTextColor(Color.parseColor("#9C9ABF")); sub.textSize = 12f
        titleBox.addView(title); titleBox.addView(sub)
        head.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        val add = TextView(this)
        add.text = t("＋ New", "＋ Mpya")
        add.setTextColor(Color.BLACK); add.textSize = 13f; add.setTypeface(null, Typeface.BOLD)
        add.background = resources.getDrawable(R.drawable.bg_dl, theme)
        add.setPadding(dp(14), dp(8), dp(14), dp(8))
        add.setOnClickListener { d.dismiss(); newTab(home) }
        head.addView(add)
        root.addView(head)

        val actions = LinearLayout(this)
        actions.setPadding(0, dp(10), 0, dp(2))
        fun chip(label: String, click: () -> Unit) {
            val c = TextView(this)
            c.text = label; c.textSize = 12f; c.setTextColor(Color.WHITE)
            c.setPadding(dp(12), dp(7), dp(12), dp(7))
            val bg = android.graphics.drawable.GradientDrawable()
            bg.cornerRadius = dp(16).toFloat(); bg.setColor(Color.parseColor("#22FFFFFF"))
            c.background = bg
            c.setOnClickListener { click() }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.rightMargin = dp(8)
            actions.addView(c, lp)
        }
        chip(t("🧹 Clean up", "🧹 Safisha")) { d.dismiss(); cleanUpDialog() }
        chip(t("💾 Sessions", "💾 Vipindi")) { d.dismiss(); sessionsDialog() }
        chip(t("↩ Closed", "↩ Zilizofungwa")) { d.dismiss(); closedDialog() }
        root.addView(actions)

        val now = System.currentTimeMillis()
        val curTab = tabs[cur]
        val groups = tabs.sortedByDescending { it.lastUsed }.groupBy { TabGroups.of(now, it.lastUsed, it.incognito, it === curTab) }
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val order = listOf(
            TabGroups.NOW to t("Now", "Sasa"), TabGroups.RECENT to t("Recent", "Hivi karibuni"),
            TabGroups.EARLIER to t("Earlier", "Zamani"), TabGroups.PRIVATE to t("Private", "Faragha")
        )
        for ((g, label) in order) {
            val items = groups[g] ?: continue
            val lab = TextView(this)
            lab.text = (label + " · " + items.size).uppercase()
            lab.setTextColor(Color.parseColor("#FFB300")); lab.textSize = 11f; lab.setTypeface(null, Typeface.BOLD)
            lab.setPadding(dp(4), dp(14), 0, 0)
            list.addView(lab)
            for (tab in items) {
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.topMargin = dp(8)
                list.addView(tabCard(d, tab, tab === curTab), lp)
            }
        }
        scroll.addView(list)
        val slp = LinearLayout.LayoutParams(-1, -2)
        slp.topMargin = dp(6)
        root.addView(scroll, slp)

        d.setContentView(root)
        sheetWindow(d)
        d.show()
    }

    private class Opt(val label: String, val list: List<Tab>)

    private fun cleanUpDialog() {
        val now = System.currentTimeMillis()
        val curTab = tabs[cur]
        val old = tabs.filter { it !== curTab && now - it.lastUsed >= 60 * 60_000L }
        val seen = HashSet<String>()
        val dups = ArrayList<Tab>()
        for (tab in tabs.sortedWith(compareByDescending<Tab> { it === curTab }.thenByDescending { it.lastUsed })) {
            val k = TabPolicy.dupKey(tab.currentUrl(), homeHost) ?: continue
            if (!seen.add(k)) dups.add(tab)
        }
        val opts = listOf(
            Opt(t("Unused for 1 hour or more", "Zisizotumika saa 1 au zaidi") + " (${old.size})", old),
            Opt(t("Duplicate tabs", "Tab zinazorudiwa") + " (${dups.size})", dups),
            Opt(t("All except this tab", "Zote isipokuwa hii") + " (${tabs.size - 1})", tabs.filter { it !== curTab }),
            Opt(t("Private tabs", "Tab za faragha") + " (${tabs.count { it.incognito }})", tabs.filter { it.incognito }),
            Opt(t("All tabs", "Tab zote") + " (${tabs.size})", tabs.toList())
        )
        AlertDialog.Builder(this).setTitle(t("Clean up tabs", "Safisha tab"))
            .setItems(opts.map { it.label }.toTypedArray()) { _, i ->
                val o = opts[i]
                if (o.list.isEmpty()) { toast(t("Nothing to close", "Hakuna cha kufunga")); return@setItems }
                AlertDialog.Builder(this)
                    .setTitle(t("Close ${o.list.size} tabs?", "Funga tab ${o.list.size}?"))
                    .setMessage(t("You can reopen them from Closed (private tabs are not saved).", "Unaweza kuzifungua tena kupitia Zilizofungwa (tab za faragha hazihifadhiwi)."))
                    .setPositiveButton(t("Close", "Funga")) { _, _ ->
                        val n = o.list.size
                        closeTabs(o.list)
                        toast(t("Closed $n tabs", "Tab $n zimefungwa"))
                    }
                    .setNegativeButton(t("Cancel", "Ghairi"), null).show()
            }
            .setNegativeButton(t("Close", "Funga"), null).show()
    }

    private fun sessionsDialog() {
        val sessions = TabArchive.sessions(store)
        val labels = ArrayList<String>()
        labels.add(t("＋ Save current tabs as a session", "＋ Hifadhi tab za sasa kama kipindi"))
        for (s in sessions) labels.add(s.name + " · " + s.items.size + " " + t("tabs", "tab"))
        AlertDialog.Builder(this).setTitle(t("Saved sessions", "Vipindi vilivyohifadhiwa"))
            .setItems(labels.toTypedArray()) { _, i -> if (i == 0) saveSessionPrompt() else sessionActions(sessions[i - 1]) }
            .setNegativeButton(t("Close", "Funga"), null).show()
    }

    private fun saveSessionPrompt() {
        val items = tabs.filter { !it.incognito }.mapNotNull { tab ->
            val u = tab.currentUrl()
            if (!u.startsWith("http") || isOfflineUrl(u) || Uri.parse(u).host == homeHost) null
            else TabArchive.Item(u, tab.wv?.title?.takeIf { x -> x.isNotBlank() } ?: tab.title, tab.lastUsed)
        }
        if (items.isEmpty()) { toast(t("No pages to save", "Hakuna kurasa za kuhifadhi")); return }
        val input = EditText(this)
        input.setText(SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date()))
        input.setSelectAllOnFocus(true)
        AlertDialog.Builder(this).setTitle(t("Session name", "Jina la kipindi")).setView(input)
            .setPositiveButton("OK") { _, _ ->
                TabArchive.saveSession(store, input.text.toString().trim().ifBlank { "Session" }, items)
                toast(t("Session saved (${items.size} tabs)", "Kipindi kimehifadhiwa (tab ${items.size})"))
            }
            .setNegativeButton(t("Cancel", "Ghairi"), null).show()
    }

    private fun sessionActions(s: TabArchive.Session) {
        AlertDialog.Builder(this).setTitle(s.name)
            .setItems(arrayOf(t("Open all tabs", "Fungua tab zote"), t("Delete session", "Futa kipindi"))) { _, i ->
                if (i == 0) {
                    if (s.items.isEmpty()) return@setItems
                    val added = s.items.map { addSleepingTab(it.url, it.title) }
                    show(tabs.indexOf(added.first()))
                    toast(t("Opened ${added.size} tabs (each loads when you open it)", "Tab ${added.size} zimefunguliwa (kila moja inapakia ukiifungua)"))
                } else {
                    TabArchive.deleteSession(store, s.ts)
                    toast(t("Session deleted", "Kipindi kimefutwa"))
                }
            }.show()
    }

    private fun closedDialog() {
        val list = TabArchive.closed(store)
        if (list.isEmpty()) { toast(t("No recently closed tabs", "Hakuna tab zilizofungwa hivi karibuni")); return }
        val labels = list.map { (it.title.ifBlank { pretty(it.url) }).take(45) + " · " + pretty(it.url) }.toMutableList()
        labels.add(t("Clear this list", "Futa orodha hii"))
        AlertDialog.Builder(this).setTitle(t("Recently closed", "Zilizofungwa hivi karibuni"))
            .setItems(labels.toTypedArray()) { _, i ->
                if (i == list.size) { TabArchive.clearClosed(store); toast(t("List cleared", "Orodha imefutwa")) }
                else {
                    val item = list[i]
                    TabArchive.removeClosed(store, item.url, item.ts)
                    val tab = addSleepingTab(item.url, item.title)
                    show(tabs.indexOf(tab))
                }
            }
            .setNegativeButton(t("Close", "Funga"), null).show()
    }

    // ---------------- v46: ruhusa za tovuti (mahali, kamera, kipaza sauti) ----------------
    private var permDialog: AlertDialog? = null
    private var permPending: ((Map<String, Boolean>) -> Unit)? = null
    private val rtPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val cb = permPending
        permPending = null
        cb?.invoke(res)
    }

    /** Inaomba ruhusa za Android (runtime). any = ruhusa moja inatosha (mahali: FINE au COARSE). */
    private fun withAndroidPerms(list: Array<String>, any: Boolean, done: (Boolean) -> Unit) {
        val missing = list.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        val okNow = if (any) missing.size < list.size else missing.isEmpty()
        if (okNow) { done(true); return }
        permPending = { res ->
            val granted = list.filter { res[it] == true || checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
            done(if (any) granted.isNotEmpty() else granted.size == list.size)
        }
        try { rtPerm.launch(missing.toTypedArray()) } catch (e: Exception) { permPending = null; done(false) }
    }

    /** Inaamua kwa uamuzi uliohifadhiwa, chaguo-msingi, au kwa kumuuliza mtumiaji. Tab za faragha hazihifadhi maamuzi. */
    private fun decideSite(origin: String, kinds: List<Int>, incognito: Boolean, result: (Boolean) -> Unit) {
        val states = kinds.map { SitePerms.effective(store, origin, it) }
        if (states.any { it == SitePerms.BLOCK }) { result(false); return }
        if (states.all { it == SitePerms.ALLOW }) { result(true); return }
        if (permDialog?.isShowing == true) { result(false); return }
        var answered = false
        fun answer(v: Boolean) { if (!answered) { answered = true; result(v) } }
        val sw = store.lang == "sw"
        val what = kinds.joinToString(" + ") { SitePerms.icon(it) + " " + SitePerms.label(it, sw) }
        val remember = CheckBox(this)
        remember.text = t("Remember for this site", "Kumbuka kwa tovuti hii")
        val box = LinearLayout(this)
        box.setPadding(dp(24), dp(8), dp(24), 0)
        if (!incognito) box.addView(remember)
        permDialog = AlertDialog.Builder(this)
            .setTitle(SitePerms.host(origin))
            .setMessage(t("wants to use: ", "inaomba kutumia: ") + what)
            .setView(box)
            .setPositiveButton(t("Allow", "Ruhusu")) { _, _ ->
                if (!incognito && remember.isChecked) kinds.forEach { SitePerms.set(store, origin, it, SitePerms.ALLOW) }
                answer(true)
            }
            .setNegativeButton(t("Block", "Zuia")) { _, _ ->
                if (!incognito && remember.isChecked) kinds.forEach { SitePerms.set(store, origin, it, SitePerms.BLOCK) }
                answer(false)
            }
            .setOnCancelListener { answer(false) }
            .show()
    }

    private fun handleWebPermission(request: PermissionRequest, incognito: Boolean) {
        val o = SitePerms.origin(request.origin.toString())
        val kinds = ArrayList<Int>()
        val grant = ArrayList<String>()
        val android = ArrayList<String>()
        for (r in request.resources) {
            when (r) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> { kinds.add(SitePerms.CAM); grant.add(r); android.add(Manifest.permission.CAMERA) }
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> { kinds.add(SitePerms.MIC); grant.add(r); android.add(Manifest.permission.RECORD_AUDIO) }
            }
        }
        if (o == null || kinds.isEmpty()) { try { request.deny() } catch (_: Exception) { }; return }
        decideSite(o, kinds, incognito) { allow ->
            try {
                if (!allow) request.deny()
                else withAndroidPerms(android.toTypedArray(), false) { ok ->
                    try { if (ok) request.grant(grant.toTypedArray()) else request.deny() } catch (_: Exception) { }
                }
            } catch (_: Exception) { }
        }
    }

    // ---------------- Menu ----------------

    private fun manageSites() {
        val s = store.sites()
        if (s.isEmpty()) { toast(t("Home has no sites", "Home haina tovuti")); return }
        val checked = BooleanArray(s.size)
        AlertDialog.Builder(this).setTitle(t("Select sites to remove", "Chagua tovuti za kuondoa"))
            .setMultiChoiceItems(s.map { it.first }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(t("Remove", "Ondoa")) { _, _ ->
                s.indices.filter { checked[it] }.forEach { store.removeSite(s[it].second) }
                toast(t("Removed", "Imeondolewa"))
                if (fullUrl.isEmpty()) web.reload()
            }
            .setNegativeButton(t("Cancel", "Ghairi"), null)
            .show()
    }


    // V37: reader mode, save a clean text copy offline, and estimated data-saved counter.
    private fun showDataSaved() {
        val blocked = store.blocked
        // Approximation only: blocked resources vary in size; this is not carrier-measured traffic.
        val estimatedBytes = blocked.toLong() * 35L * 1024L
        val mb = estimatedBytes / (1024.0 * 1024.0)
        AlertDialog.Builder(this)
            .setTitle(t("Data saved", "Bando lililookolewa"))
            .setMessage(
                t("Estimated saved: %.2f MB\nBlocked requests: %d\n\nThis is an estimate based on blocked requests, not an exact measurement from your mobile operator.",
                  "Makadirio ya bando lililookolewa: %.2f MB\nMaombi yaliyozuiwa: %d\n\nHaya ni makadirio kutokana na maombi yaliyozuiwa, si kipimo halisi cha mtandao wako.")
                    .format(mb, blocked)
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun toggleReaderMode() {
        val url = web.url ?: ""
        if (url.isBlank() || !url.startsWith("http", true) || Uri.parse(url).host == homeHost) {
            toast(t("Open a news or article page first", "Fungua ukurasa wa habari kwanza")); return
        }
        // Re-loading the URL exits reader mode; otherwise extract the article text and simplify the page.
        if (readerModeUrl == url) {
            readerModeUrl = ""
            web.loadUrl(url)
            return
        }
        readerModeUrl = url
        val js = """
            (function(){
              try {
                var old=document.getElementById('__rlg_reader'); if(old){old.remove();}
                var candidates=['article','main','[role=main]','[itemprop=articleBody]'];
                var best=null, score=0;
                candidates.forEach(function(sel){try{document.querySelectorAll(sel).forEach(function(el){var t=(el.innerText||'').trim();if(t.length>score){score=t.length;best=el;}})}catch(e){}});
                if(!best || score<180) best=document.body;
                var title=(document.querySelector('meta[property="og:title"]')||{}).content||document.title||'Reader';
                var text=(best.innerText||best.textContent||'').replace(/\n{3,}/g,'\n\n').trim();
                if(!text) return 'empty';
                document.documentElement.innerHTML='';
                var head=document.createElement('head'); var meta=document.createElement('meta');meta.charset='utf-8';head.appendChild(meta);
                var vp=document.createElement('meta');vp.name='viewport';vp.content='width=device-width,initial-scale=1';head.appendChild(vp);
                var style=document.createElement('style');style.textContent='body{max-width:720px;margin:0 auto;padding:24px 20px 60px;background:#faf7f0;color:#222;font:18px/1.8 Georgia,serif}h1{font: bold 30px/1.25 sans-serif;margin:0 0 24px}#content{white-space:pre-wrap;overflow-wrap:anywhere} .tag{font:12px sans-serif;color:#777;margin-bottom:18px}';head.appendChild(style);
                var body=document.createElement('body');var label=document.createElement('div');label.className='tag';label.textContent='RAHIM LUX GO · READER MODE';body.appendChild(label);
                var h=document.createElement('h1');h.textContent=title;body.appendChild(h);
                var article=document.createElement('div');article.id='content';article.textContent=text;body.appendChild(article);
                document.documentElement.appendChild(head);document.documentElement.appendChild(body);
                return 'ok';
              }catch(e){return 'error'}
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { result ->
            if (result == "\"empty\"" || result == "\"error\"" || result == "null") {
                readerModeUrl = ""
                toast(t("Could not extract article text on this page", "Imeshindikana kutoa maandishi ya habari hii"))
            } else toast(t("Reader mode on · tap Reader again to exit", "Reader mode imewashwa · bonyeza tena kutoka"))
        }
    }

    private var readerModeUrl: String = ""
    private var readAloudTts: TextToSpeech? = null
    private var readAloudReady = false

    /** Read Aloud: TTS ya Android. Maandishi marefu yanagawanywa vipande (Android inakataa zaidi ya ~4000 kwa mara moja). Bonyeza tena kusimamisha. */
    private fun readAloudPage() {
        val tts = readAloudTts
        if (tts != null && readAloudReady && tts.isSpeaking) { stopReadAloud(); toast(t("Stopped", "Imesimamishwa")); return }
        if (tabs.isEmpty()) return
        val js = "(document.querySelector('article,main,[role=main],[itemprop=articleBody]')||document.body).innerText||''"
        web.evaluateJavascript(js) { raw ->
            val text = try { org.json.JSONTokener(raw ?: "\"\"").nextValue() as? String ?: "" } catch (_: Exception) { "" }
            val clean = text.replace(Regex("\\s+"), " ").trim().take(20000)
            if (clean.length < 20) { toast(t("No readable text on this page", "Hakuna maandishi ya kusoma kwenye ukurasa huu")); return@evaluateJavascript }
            startSpeaking(clean)
        }
    }

    private fun startSpeaking(clean: String) {
        val go: (TextToSpeech) -> Unit = { engine ->
            val want = if (store.lang == "sw") Locale("sw", "TZ") else Locale.US
            val r = engine.setLanguage(want)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                AlertDialog.Builder(this)
                    .setTitle(t("Voice not installed", "Sauti haijasakinishwa"))
                    .setMessage(t(
                        "The voice for this language is not installed. Install it in Android's Text-to-speech settings, or read with the default voice.",
                        "Sauti ya lugha hii haijasakinishwa. Isakinishe kwenye mipangilio ya Text-to-speech ya Android, au soma kwa sauti chaguo-msingi."))
                    .setPositiveButton(t("Open settings", "Fungua mipangilio")) { _, _ ->
                        try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                        catch (_: Exception) { toast(t("Open Settings > Text-to-speech", "Fungua Settings > Text-to-speech")) }
                    }
                    .setNeutralButton(t("Read anyway", "Soma hivyo hivyo")) { _, _ -> engine.setLanguage(Locale.getDefault()); speakChunks(engine, clean) }
                    .setNegativeButton(t("Cancel", "Ghairi"), null)
                    .show()
            } else speakChunks(engine, clean)
        }
        val existing = readAloudTts
        if (existing != null) { if (readAloudReady) go(existing); return } // bado inaanza: subiri
        readAloudTts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                readAloudReady = true
                readAloudTts?.let { go(it) }
            } else {
                toast(t("Text-to-speech is unavailable", "Huduma ya kusoma kwa sauti haipatikani"))
                try { readAloudTts?.shutdown() } catch (_: Exception) { }
                readAloudTts = null
                readAloudReady = false
            }
        }
    }

    private fun speakChunks(tts: TextToSpeech, text: String) {
        val max = (minOf(TextToSpeech.getMaxSpeechInputLength(), 4000) - 200).coerceAtLeast(500)
        val chunks = ArrayList<String>()
        var rest = text
        while (rest.length > max) {
            var cut = rest.lastIndexOf(". ", max)
            if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
            if (cut <= 0) cut = max - 1
            chunks.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1).trim()
        }
        if (rest.isNotEmpty()) chunks.add(rest)
        var ok = true
        chunks.forEachIndexed { i, c ->
            val r = tts.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "rlg_read_aloud_$i")
            if (r != TextToSpeech.SUCCESS) ok = false
        }
        toast(
            if (ok) t("Reading… tap Read aloud again to stop", "Inasoma… bonyeza Soma kwa sauti tena kusimamisha")
            else t("Could not start Read Aloud", "Imeshindikana kuanza kusoma kwa sauti")
        )
    }

    private fun stopReadAloud() { try { if (readAloudReady) readAloudTts?.stop() } catch (_: Exception) { } }

    /** Inahifadhi nakala ya maandishi (aya zinabaki) kwenye simu. Haipatikani kwenye tab za faragha. */
    private fun savePageOffline() {
        val url = web.url ?: ""
        if (web.tag == "inc") {
            toast(t("Saving offline is not available in private tabs", "Kuhifadhi offline hakupatikani kwenye tab za faragha")); return
        }
        if (url.isBlank() || !url.startsWith("http", true) || Uri.parse(url).host == homeHost) {
            toast(t("Open a website or news article first", "Fungua tovuti au habari kwanza")); return
        }
        val title = (web.title ?: "").ifBlank { url }
        val js = """
            (function(){
              try {
                var title=${org.json.JSONObject.quote(title)};
                var url=${org.json.JSONObject.quote(url)};
                var root=document.querySelector('article')||document.querySelector('main')||document.body;
                var text=((root&&root.innerText)||'').replace(/\r/g,'').trim();
                if(text.length<40){text=(document.body.innerText||'').replace(/\r/g,'').trim();}
                if(text.length<40) return '';
                text=text.replace(/\n{3,}/g,'\n\n');
                if(text.length>300000) text=text.slice(0,300000);
                var esc=function(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')};
                var paras=text.split(/\n{2,}/).map(function(p){return '<p>'+esc(p).replace(/\n/g,'<br>')+'</p>'}).join('');
                var html='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(title)+'</title><style>body{max-width:720px;margin:0 auto;padding:24px 20px 60px;background:#faf7f0;color:#222;font:18px/1.8 Georgia,serif}h1{font:bold 28px/1.25 sans-serif}p{overflow-wrap:anywhere;margin:0 0 1em}small{font:12px sans-serif;color:#777}</style></head><body><small>RAHIM LUX GO · SAVED OFFLINE</small><h1>'+esc(title)+'</h1><p><small>Original: '+esc(url)+'</small></p>'+paras+'</body></html>';
                return btoa(unescape(encodeURIComponent(html)));
              } catch(e) { return ''; }
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { raw ->
            val encoded = try { org.json.JSONTokener(raw ?: "null").nextValue() as? String ?: "" } catch (_: Exception) { "" }
            if (encoded.length < 200) {
                toast(t("This page has no readable text to save", "Ukurasa huu hauna maandishi ya kuhifadhi")); return@evaluateJavascript
            }
            Thread {
                val saved = try {
                    val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                    val base = title.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_').take(45).ifBlank { "page" }
                    val name = System.currentTimeMillis().toString() + "_" + base + ".html"
                    File(OfflineRepo.dir(this), name).writeBytes(bytes)
                    OfflineRepo.add(this, store, name, title, url)
                    true
                } catch (e: Exception) { false }
                runOnUiThread {
                    if (saved) {
                        AlertDialog.Builder(this)
                            .setTitle(t("Page saved offline", "Ukurasa umehifadhiwa offline"))
                            .setMessage(t(
                                "A text copy was saved on this phone. Open it from Menu > Offline pages.",
                                "Nakala ya maandishi imehifadhiwa kwenye simu hii. Ifungue kupitia Menu > Kurasa za offline."))
                            .setPositiveButton("OK", null).show()
                    } else toast(t("Could not save this page", "Imeshindikana kuhifadhi ukurasa"))
                }
            }.start()
        }
    }

    private fun showOfflinePages() {
        withBookmarkLock { offlineLauncher.launch(Intent(this, OfflinePagesActivity::class.java)) }
    }

    private fun showMenu() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = layoutInflater.inflate(R.layout.sheet_menu, null)
        val statsView = root.findViewById<TextView>(R.id.stats)
        statsView.text = "🛡 ${store.blocked} " + t("blocked", "zimezuiwa") + " ›"
        statsView.setOnClickListener { d.dismiss(); showBlocked() }
        val grid = root.findViewById<GridLayout>(R.id.grid)

        fun cell(icon: String, label: String, on: Boolean? = null, action: () -> Unit) {
            val color = when (on) {
                true -> accent
                false -> Color.parseColor("#9C9ABF")
                null -> Color.WHITE
            }
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(0, dp(10), 0, dp(10))
            val ic = TextView(this)
            ic.text = icon; ic.textSize = 22f; ic.gravity = Gravity.CENTER
            ic.background = resources.getDrawable(if (on == true) R.drawable.bg_icon_on else R.drawable.bg_icon, theme)
            val iclp = LinearLayout.LayoutParams(dp(50), dp(50))
            iclp.gravity = Gravity.CENTER_HORIZONTAL
            box.addView(ic, iclp)
            val lb = TextView(this)
            lb.text = label; lb.textSize = 11f; lb.gravity = Gravity.CENTER; lb.setTextColor(color)
            lb.setPadding(0, dp(6), 0, 0)
            box.addView(lb)
            box.setOnClickListener { d.dismiss(); action() }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            grid.addView(box, lp)
        }

        val curHost = web.url?.let { Uri.parse(it).host }
        val onSite = curHost != null && (curHost != homeHost || isOfflineUrl(web.url ?: ""))

        cell("➕", t("New tab", "Tab mpya")) { newTab(home) }
        cell("🕶", t("Private", "Faragha")) { newTab(home, true) }
        cell("✖️", t("Close tab", "Funga tab")) { closeTab() }
        cell("🔄", t("Reload", "Pakia upya")) { web.reload() }
        cell("🔍", t("Find in page", "Tafuta ukurasani")) {
            if (onSite) openFind() else toast(t("Open a website first", "Fungua tovuti kwanza"))
        }
        cell("🌍", t("Translate", "Tafsiri")) {
            if (onSite) translatePage() else toast(t("Open a website first", "Fungua tovuti kwanza"))
        }
        cell("🖨️", t("Save PDF", "Hifadhi PDF")) {
            if (onSite) printPage() else toast(t("Open a website first", "Fungua tovuti kwanza"))
        }
        cell("📖", t("Reader mode", "Hali ya kusoma")) { toggleReaderMode() }
        cell("🔊", t("Read aloud", "Soma kwa sauti")) { readAloudPage() }
        cell("💾", t("Save offline", "Hifadhi offline")) { savePageOffline() }
        cell("🛡", t("Privacy", "Faragha")) { settingsLauncher.launch(Intent(this, PrivacyDashboardActivity::class.java)) }
        cell("📂", t("Offline pages", "Kurasa za offline")) { showOfflinePages() }

        cell("⭐", "Bookmark") {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) {
                store.addBookmark(web.title ?: u, u); toast(t("Saved ⭐", "Imehifadhiwa ⭐"))
            }
        }
        cell("📚", "Bookmarks") { withBookmarkLock { pick("Bookmarks", store.bookmarks()) } }
        cell("🕘", "History") { pick("History", store.history()) }
        cell("⬇️", t("Downloads", "Vipakuliwa")) { startActivity(Intent(this, DownloadsActivity::class.java)) }

        cell("🛡️", "Ad-block", store.adblock) {
            store.adblock = !store.adblock
            web.reload()
            toast(if (store.adblock) t("Ad-block on", "Ad-block imewashwa") else t("Ad-block off", "Ad-block imezimwa"))
        }
        cell("🎯", t("This site", "Tovuti hii"), if (onSite) !store.isAdOff(curHost) else null) {
            if (!onSite || curHost == null) toast(t("Open a website first", "Fungua tovuti kwanza"))
            else {
                val off = store.toggleAdOff(curHost)
                web.reload()
                val site = curHost.removePrefix("www.")
                toast(if (off) t("Ad-block off for $site", "Ad-block imezimwa kwa $site") else t("Ad-block on for $site", "Ad-block imewashwa kwa $site"))
            }
        }
        cell("📉", "Data saver", store.dataSaver) {
            store.dataSaver = !store.dataSaver
            forEachLive { w -> w.settings.blockNetworkImage = store.dataSaver }
            web.reload()
            toast(if (store.dataSaver) t("Data saver on", "Data saver imewashwa") else t("Data saver off", "Data saver imezimwa"))
        }
        cell("🌙", "Dark web", store.darkWeb) {
            store.darkWeb = !store.darkWeb
            forEachLive { w -> applyDark(w) }
            web.reload()
            toast(if (store.darkWeb) t("Dark mode on", "Dark mode imewashwa") else t("Dark mode off", "Dark mode imezimwa"))
        }

        cell("🖥️", "Desktop site", store.desktop) {
            store.desktop = !store.desktop
            forEachLive { w -> applyDesktop(w) }
            web.reload()
            toast(if (store.desktop) t("Desktop site on", "Desktop site imewashwa") else t("Desktop site off", "Desktop site imezimwa"))
        }
        cell("🍪", "3rd-party cookies", store.thirdCookies) {
            store.thirdCookies = !store.thirdCookies
            forEachLive { w -> CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.thirdCookies) }
            web.reload()
            toast(if (store.thirdCookies) t("3rd-party cookies on (logins work better)", "Cookies za third-party zimewashwa")
            else t("3rd-party cookies off (more private)", "Cookies za third-party zimezimwa"))
        }
        cell("🎤", t("Voice: ", "Sauti: ") + (if (store.voiceLang == "sw") "Swahili" else "English")) {
            store.voiceLang = if (store.voiceLang == "sw") "en" else "sw"
            toast(if (store.voiceLang == "sw") t("Voice search: Swahili", "Voice search: Kiswahili") else t("Voice search: English", "Voice search: Kiingereza"))
        }
        cell("🔎", t("Search engine", "Injini ya kutafuta")) { pickEngine() }
        cell("🌐", "English / Swahili") {
            store.lang = if (store.lang == "sw") "en" else "sw"
            news = listOf()
            cats.clear()
            loadNews()
            updateHint()
            if (fullUrl.isEmpty()) web.reload()
            toast(if (store.lang == "sw") "Lugha: Kiswahili" else "Language: English")
        }

        cell("🏠", t("Add to Home", "Ongeza Home")) {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) {
                store.addSite((web.title ?: pretty(u)).take(14), u)
                toast(t("Added to Home", "Imeongezwa kwenye Home"))
            } else toast(t("Open a website first", "Fungua tovuti kwanza"))
        }
        cell("✏️", t("Edit Home", "Dhibiti Home")) { manageSites() }
        cell("🔁", t("Update list", "Sasisha list")) {
            toast(t("Updating ad list…", "Inasasisha ad-list…"))
            Thread {
                val n = AdBlock.update()
                runOnUiThread {
                    toast(if (n > 0) t("Ad list updated: $n domains", "Ad-list imesasishwa: $n domains")
                    else t("Update failed, try again", "Imeshindwa, jaribu tena"))
                }
            }.start()
        }
        cell("🚫", t("Blocked", "Zilizozuiwa")) { showBlocked() }

        cell("🔗", "Share") {
            if (fullUrl.isNotEmpty()) {
                val s = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, fullUrl) }
                startActivity(Intent.createChooser(s, t("Share via", "Tuma kupitia")))
            }
        }
        cell("🗑️", t("Clear data", "Futa data")) {
            store.clearHistory()
            store.clearSearches()
            forEachLive { w -> w.clearCache(true); w.clearHistory() }
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            toast(t("Data cleared", "Data imefutwa"))
        }

        val unread = Notif.unread(store)
        cell("🔔", t("Notifications", "Arifa") + if (unread > 0) " ($unread)" else "", if (unread > 0) true else null) {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }
        cell("💾", "Status Saver") {
            startActivity(Intent(this, StatusSaverActivity::class.java))
        }
        cell("⚙️", t("Settings", "Mipangilio")) {
            langAtOpen = store.lang
            settingsLauncher.launch(Intent(this, SettingsActivity::class.java))
        }

        d.setContentView(root)
        sheetWindow(d)
        d.show()
    }

    private fun showBlocked() {
        val l = BlockLog.top()
        if (l.isEmpty()) { toast(t("Nothing blocked yet", "Hakuna kilichozuiwa bado")); return }
        AlertDialog.Builder(this).setTitle("🚫 " + t("Blocked", "Zilizozuiwa") + " (${store.blocked})")
            .setItems(l.map { "${it.first}  ×${it.second}" }.toTypedArray(), null)
            .setPositiveButton(t("Close", "Funga"), null)
            .setNeutralButton(t("Clear list", "Futa orodha")) { _, _ ->
                store.resetPrivacyStats()
                toast(t("Cleared", "Imefutwa"))
            }.show()
    }

    private fun pick(title: String, items: List<Pair<String, String>>) {
        if (items.isEmpty()) { toast(t("Nothing here yet", "Hakuna kitu bado")); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(items.map { it.first.take(40) + "\n" + it.second.take(50) }.toTypedArray()) { _, i ->
                web.loadUrl(items[i].second)
            }.show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- Lifecycle ----------------

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        handler.removeCallbacks(janitor)
        adView.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (store.webClearPending) {
            store.webClearPending = false
            forEachLive { it.clearCache(true); it.clearHistory() }
        }
        handler.removeCallbacks(janitor)
        handler.postDelayed(janitor, 60_000)
        updateSecure()
        if (tabs.isNotEmpty() && web.tag == "inc") guardPrivate()
        adView.resume()
        Push.syncTopics(this)
        handler.postDelayed(poll, 2500)
        if (System.currentTimeMillis() - newsAt > 30 * 60 * 1000) { newsAt = System.currentTimeMillis(); loadNews() }
        if (tabs.isNotEmpty() && fullUrl.isEmpty() && tabs[cur].pending == null &&
            System.currentTimeMillis() - lastNav > 4000) web.loadUrl(home)
    }

    override fun onStart() {
        super.onStart()
        store.exitPending = false
    }

    override fun onStop() {
        privUnlockedAt = 0L
        bmUnlockedAt = 0L
        if (store.clearExit) store.exitPending = true
        store.blockLogJson = BlockLog.toJson()
        tabs.getOrNull(cur)?.lastUsed = System.currentTimeMillis()
        trimTabs()
        saveTabs()
        super.onStop()
    }

    override fun onDestroy() {
        stopReadAloud()
        try { readAloudTts?.shutdown() } catch (_: Exception) { }
        readAloudTts = null
        readAloudReady = false
        try { unregisterReceiver(dlReceiver) } catch (e: Exception) { }
        exitFullscreen()
        adView.destroy()
        if (isFinishing && store.clearExit) runExitClear()
        tabs.forEach { it.wv?.destroy() }
        super.onDestroy()
    }
}
