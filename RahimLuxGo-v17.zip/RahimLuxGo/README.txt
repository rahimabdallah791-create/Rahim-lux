RAHIM LUX GO v17 - Android browser (Kotlin + WebView)
Mpya v17: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
