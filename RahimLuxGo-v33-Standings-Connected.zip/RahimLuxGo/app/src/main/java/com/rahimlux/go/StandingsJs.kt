package com.rahimlux.go

/** JavaScript ya "Msimamo wa ligi" kwenye Home. Data inaingia kupitia textContent (si innerHTML). */
object StandingsJs {
    const val CODE = """
function stEl(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined&&x!==null)e.textContent=x;return e}
function stRead(k){try{return JSON.parse(localStorage.getItem('rlg-std-'+k)||'null')}catch(e){return null}}
function stWrite(k,b){try{localStorage.setItem('rlg-std-'+k,JSON.stringify({t:Date.now(),b:b}))}catch(e){}}
function stHm(ts){var d=new Date(ts);var h=d.getHours(),m=d.getMinutes();return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
function stSelect(k){STD.sel=k;try{localStorage.setItem('rlg-std-sel',k)}catch(e){}stRender();stLoad(k)}
function stLoad(k){
 var c=stRead(k);if(c&&Date.now()-c.t<1800000)return;
 if(!STD.base||STD.busy[k])return;STD.busy[k]=1;
 var h={};if(STD.token)h['X-App-Token']=STD.token;
 fetch(STD.base+'/standings?league='+encodeURIComponent(k),{headers:h})
  .then(function(r){return r.text().then(function(t){var j=null;try{j=JSON.parse(t)}catch(e){};return {status:r.status,body:j}})})
  .then(function(x){STD.busy[k]=0;var j=x.body;
    if(x.status>=200&&x.status<300&&j&&j.ok&&Array.isArray(j.groups)){
      stWrite(k,j);STD.err[k]='';
    }else{
      var code=(j&&String(j.error||j.code||'').toLowerCase())||'';
      if(x.status===404||code.indexOf('league')>=0&&(code.indexOf('not_found')>=0||code.indexOf('unsupported')>=0||code.indexOf('unavailable')>=0))STD.err[k]='league_unavailable';
      else if(code==='plan_limit'||code==='quota_exhausted'||code==='not_configured')STD.err[k]=code;
      else if(x.status===429)STD.err[k]='quota_exhausted';
      else STD.err[k]='fail';
    }
    if(STD.sel===k)stRender()})
  .catch(function(){STD.busy[k]=0;STD.err[k]='network';if(STD.sel===k)stRender()})}
function stRender(){
 var chips=document.getElementById('stc'),box=document.getElementById('std');if(!chips||!box||!STD.cfg)return;
 chips.innerHTML='';
 STD.leagues.forEach(function(l){var bt=stEl('button','sc2'+(l.k===STD.sel?' on':''),l.s);bt.type='button';bt.onclick=function(){stSelect(l.k)};chips.appendChild(bt)});
 box.innerHTML='';
 var c=stRead(STD.sel),err=STD.err[STD.sel]||'';
 if(!c){box.appendChild(stEl('div','ste',err==='league_unavailable'?STD.i.unavailable:err==='plan_limit'?STD.i.plan:err==='quota_exhausted'?STD.i.quota:err==='not_configured'?STD.i.setup:err==='network'?STD.i.network:err?STD.i.fail:STD.i.load));return}
 var b=c.b;
 var nm=b.name||b.leagueName||b.league||STD.sel;var co=b.country||b.provider||'';var meta=nm+(co?' \u00b7 '+co:'')+(b.season?' \u00b7 '+b.season:'')+' \u00b7 '+STD.i.upd+stHm(Date.parse(b.updated)||c.t);
 if(b.stale||err||Date.now()-c.t>86400000)meta+=' \u00b7 \u26a0 '+STD.i.old;
 box.appendChild(stEl('div','stm',meta));
 var zones={};
 (b.groups||[]).forEach(function(g){
  if(g.name)box.appendChild(stEl('div','stg',g.name));
  var hd=stEl('div','str sth');['#',STD.i.team,'P','W','D','L','GD','Pts'].forEach(function(x,i){hd.appendChild(stEl('span',i===1?'stt':'',x))});box.appendChild(hd);
  (g.rows||g.table||[]).forEach(function(r){
   var pos=r.pos!=null?r.pos:r.rank;var played=r.p!=null?r.p:r.played;var win=r.w!=null?r.w:r.win;var draw=r.d!=null?r.d:r.draw;var lose=r.l!=null?r.l:r.lose;var gd=r.gd!=null?r.gd:r.goalsDiff;var pts=r.pts!=null?r.pts:r.points;var team=r.team||r.name||'';
   var row=stEl('div','str'+(r.zone?' z-'+r.zone:''));
   if(r.zone)zones[r.zone]=1;
   [pos,team,played,win,draw,lose,(Number(gd)>0?'+':'')+((gd==null)?'':gd),pts].forEach(function(x,i){row.appendChild(stEl('span',i===1?'stt':(i===7?'stp':''),x==null?'—':x))});
   box.appendChild(row)})});
 var zl=[['ucl',STD.i.zUcl],['uel',STD.i.zUel],['uecl',STD.i.zUecl],['promo',STD.i.zPromo],['rel',STD.i.zRel]].filter(function(z){return zones[z[0]]});
 if(zl.length){var lg=stEl('div','stl');zl.forEach(function(z){lg.appendChild(stEl('span','zc-'+z[0],'\u25cf '+z[1]))});box.appendChild(lg)}
}
try{var sv=localStorage.getItem('rlg-std-sel');if(sv&&STD.leagues.some(function(l){return l.k===sv}))STD.sel=sv}catch(e){}
STD.err={};STD.busy={};
stRender();
stLoad(STD.sel);if(STD.sel!=='epl')stLoad('epl');if(STD.sel!=='nbc')stLoad('nbc');
"""
}
