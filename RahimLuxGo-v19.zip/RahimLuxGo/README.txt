RAHIM LUX GO v19 - Android browser (Kotlin + WebView)
Mpya v19: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
