RAHIM LUX GO v15 - Android browser (Kotlin + WebView)
Mpya v15: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
