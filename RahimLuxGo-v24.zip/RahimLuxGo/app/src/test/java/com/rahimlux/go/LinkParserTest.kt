package com.rahimlux.go

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LinkParserTest {
    private val search = { q: String -> "SEARCH:$q" }

    @Test fun plainUrl() = assertEquals("https://example.com/a?b=1", LinkParser.resolve("https://example.com/a?b=1", search))
    @Test fun urlInsideText() = assertEquals("https://www.bbc.com/news/x", LinkParser.resolve("Angalia hii https://www.bbc.com/news/x.", search))
    @Test fun wwwPrefix() = assertEquals("https://www.example.com", LinkParser.resolve("www.example.com", search))
    @Test fun bareDomain() = assertEquals("https://example.com", LinkParser.resolve("example.com", search))
    @Test fun plainTextIsSearch() = assertEquals("SEARCH:habari za leo", LinkParser.resolve("habari   za leo", search))
    @Test fun emptyIsNull() = assertNull(LinkParser.resolve("   ", search))
    @Test fun numberIsSearch() = assertEquals("SEARCH:3.14", LinkParser.resolve("3.14", search))
    @Test fun trailingPunctuation() = assertEquals("https://a.com/p", LinkParser.safeUrl("https://a.com/p)."))
    @Test fun balancedParen() = assertEquals("https://en.wikipedia.org/wiki/Go_(game)", LinkParser.safeUrl("https://en.wikipedia.org/wiki/Go_(game)"))
    @Test fun rejectJavascript() = assertNull(LinkParser.safeUrl("javascript:alert(1)"))
    @Test fun rejectFile() = assertNull(LinkParser.safeUrl("file:///sdcard/x.html"))
    @Test fun rejectContent() = assertNull(LinkParser.safeUrl("content://x/y"))
    @Test fun rejectIntent() = assertNull(LinkParser.safeUrl("intent://scan/#Intent;scheme=zxing;end"))
    @Test fun rejectCredentials() = assertNull(LinkParser.safeUrl("https://google.com@evil.com"))
    @Test fun rejectSpaces() = assertNull(LinkParser.safeUrl("https://exa mple.com"))
    @Test fun rejectBadPort() = assertNull(LinkParser.safeUrl("https://example.com:99x/"))
    @Test fun allowPortAndIp() = assertEquals("http://192.168.1.1:8080/a", LinkParser.safeUrl("http://192.168.1.1:8080/a"))
    @Test fun scriptInTextOpensNothingDangerous() = assertEquals("SEARCH:<script>alert(1)</script>", LinkParser.resolve("<script>alert(1)</script>", search))
}
