package com.rahimlux.go

import android.app.DownloadManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Skrini ya Downloads ndani ya app: progress, kufungua na kufuta faili. */
class DownloadsActivity : AppCompatActivity() {
    private data class Row(
        val id: Long, val title: String, val status: Int, val soFar: Long,
        val total: Long, val mime: String, val modified: Long
    )

    private lateinit var store: Store
    private lateinit var list: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var lastSig = ""
    private val gold = Color.parseColor("#FFB300")

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private fun t(en: String, sw: String) = if (store.lang == "sw") sw else en
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0B0D"))

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(6), dp(10), dp(8), dp(10))
        val back = TextView(this)
        back.text = "←"; back.textSize = 24f; back.setTextColor(Color.WHITE)
        back.setPadding(dp(14), dp(6), dp(14), dp(6))
        back.setOnClickListener { finish() }
        val title = TextView(this)
        title.text = t("Downloads", "Vipakuliwa")
        title.textSize = 20f; title.setTextColor(Color.WHITE); title.setTypeface(null, Typeface.BOLD)
        head.addView(back)
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val files = TextView(this)
        files.text = "📂"; files.textSize = 20f
        files.setPadding(dp(14), dp(6), dp(14), dp(6))
        files.setOnClickListener {
            try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
            catch (e: Exception) { toast(t("Open Files > Downloads", "Fungua Files > Downloads")) }
        }
        head.addView(files)
        root.addView(head)

        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(16), dp(4), dp(16), dp(24))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        lastSig = ""
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun query(): List<Row> {
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val rows = mutableListOf<Row>()
        try {
            dm.query(DownloadManager.Query()).use { c ->
                val iId = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                val iTitle = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
                val iStatus = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                val iSoFar = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val iTotal = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val iMime = c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)
                val iMod = c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)
                while (c.moveToNext()) {
                    rows.add(
                        Row(
                            c.getLong(iId), c.getString(iTitle) ?: "", c.getInt(iStatus),
                            c.getLong(iSoFar), c.getLong(iTotal), c.getString(iMime) ?: "", c.getLong(iMod)
                        )
                    )
                }
            }
        } catch (e: Exception) { }
        return rows.sortedByDescending { it.modified }.take(100)
    }

    private fun refresh() {
        val rows = query()
        val sig = store.lang + rows.joinToString("|") { "${it.id}:${it.status}:${it.soFar}" }
        if (sig == lastSig) return
        lastSig = sig
        list.removeAllViews()

        if (rows.isEmpty()) {
            val e = TextView(this)
            e.text = t("No downloads yet.\nVideos and files you download will appear here.", "Hakuna vipakuliwa bado.\nVideo na faili utakazopakua zitaonekana hapa.")
            e.setTextColor(Color.parseColor("#8A8A94")); e.textSize = 14f; e.gravity = Gravity.CENTER
            e.setPadding(0, dp(80), 0, 0)
            list.addView(e, LinearLayout.LayoutParams(-1, -2))
            return
        }
        rows.forEach { addRow(it) }
    }

    private fun icon(mime: String): String = when {
        mime.startsWith("video") -> "🎬"
        mime.startsWith("image") -> "🖼️"
        mime.startsWith("audio") -> "🎵"
        mime == "application/pdf" -> "📕"
        mime.contains("android.package-archive") -> "📦"
        else -> "📄"
    }

    private fun addRow(r: Row) {
        val card = LinearLayout(this)
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(12), dp(6), dp(12))
        card.background = resources.getDrawable(R.drawable.bg_card, theme)

        val badge = TextView(this)
        badge.text = icon(r.mime); badge.textSize = 18f; badge.gravity = Gravity.CENTER
        badge.background = resources.getDrawable(R.drawable.bg_icon, theme)
        card.addView(badge, LinearLayout.LayoutParams(dp(44), dp(44)))

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        val name = TextView(this)
        name.text = r.title.ifEmpty { "file" }
        name.setTextColor(Color.WHITE); name.textSize = 14f; name.setTypeface(null, Typeface.BOLD)
        name.maxLines = 1; name.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        info.addView(name)

        val size = Formatter.formatShortFileSize(this, if (r.status == DownloadManager.STATUS_SUCCESSFUL) maxOf(r.total, r.soFar) else r.soFar)
        val totalTxt = if (r.total > 0) Formatter.formatShortFileSize(this, r.total) else "?"
        val sub = TextView(this)
        sub.textSize = 12f
        sub.setTextColor(Color.parseColor("#8A8A94"))
        sub.text = when (r.status) {
            DownloadManager.STATUS_SUCCESSFUL -> t("Completed · ", "Imekamilika · ") + size
            DownloadManager.STATUS_RUNNING -> {
                val pct = if (r.total > 0) (r.soFar * 100 / r.total).toInt() else -1
                (if (pct >= 0) "$pct% · " else "") + size + " / " + totalTxt
            }
            DownloadManager.STATUS_PAUSED -> t("Paused · ", "Imesimama · ") + size + " / " + totalTxt
            DownloadManager.STATUS_PENDING -> t("Waiting…", "Inasubiri…")
            else -> t("Failed — tap ✕ to remove", "Imeshindwa — bonyeza ✕ kuiondoa")
        }
        if (r.status == DownloadManager.STATUS_FAILED) sub.setTextColor(Color.parseColor("#FF6B6B"))
        info.addView(sub)

        if (r.status == DownloadManager.STATUS_RUNNING || r.status == DownloadManager.STATUS_PENDING) {
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            pb.max = 100
            if (r.total > 0) pb.progress = (r.soFar * 100 / r.total).toInt() else pb.isIndeterminate = true
            pb.progressTintList = ColorStateList.valueOf(gold)
            pb.indeterminateTintList = ColorStateList.valueOf(gold)
            val plp = LinearLayout.LayoutParams(-1, dp(4))
            plp.topMargin = dp(8)
            info.addView(pb, plp)
        }
        val ilp = LinearLayout.LayoutParams(0, -2, 1f)
        ilp.marginStart = dp(12)
        card.addView(info, ilp)

        val x = TextView(this)
        x.text = "✕"; x.textSize = 16f; x.setTextColor(Color.parseColor("#B0B0B8"))
        x.setPadding(dp(14), dp(8), dp(14), dp(8))
        x.setOnClickListener { confirmDelete(r) }
        card.addView(x)

        card.setOnClickListener { if (r.status == DownloadManager.STATUS_SUCCESSFUL) open(r) }

        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(10)
        list.addView(card, lp)
    }

    private fun open(r: Row) {
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        try {
            val uri = dm.getUriForDownloadedFile(r.id) ?: throw IllegalStateException()
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, r.mime.ifEmpty { "*/*" })
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast(t("No app can open this file", "Hakuna app ya kufungua faili hili"))
        }
    }

    private fun confirmDelete(r: Row) {
        val running = r.status == DownloadManager.STATUS_RUNNING || r.status == DownloadManager.STATUS_PENDING
        AlertDialog.Builder(this)
            .setTitle(if (running) t("Cancel download?", "Ghairi upakuaji?") else t("Delete this file?", "Futa faili hili?"))
            .setMessage(r.title)
            .setPositiveButton(if (running) t("Cancel download", "Ghairi") else t("Delete", "Futa")) { _, _ ->
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).remove(r.id)
                lastSig = ""
                refresh()
            }
            .setNegativeButton(t("Keep", "Acha"), null)
            .show()
    }
}
