package com.rahimlux.go

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Bookmarks, history, Home sites, tabs na settings — zinahifadhiwa kwenye simu. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("rahimluxgo", Context.MODE_PRIVATE)

    private val betting = listOf(
        "Betway" to "https://www.betway.co.tz",
        "Betpawa" to "https://www.betpawa.co.tz",
        "SportyBet" to "https://www.sportybet.com",
        "1win" to "https://1win.com"
    )

    private val defaultSites = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://m.youtube.com",
        "Facebook" to "https://m.facebook.com",
        "Instagram" to "https://www.instagram.com",
        "WhatsApp" to "https://web.whatsapp.com",
        "TikTok" to "https://www.tiktok.com",
        "Wikipedia" to "https://en.wikipedia.org",
        "Mwananchi" to "https://www.mwananchi.co.tz"
    ) + betting

    @Volatile private var adOff: Set<String> = readSet("adoff")

    init {
        if (p.getInt("sv", 1) < 2) {
            if (p.contains("sites")) {
                val cur = read("sites")
                write("sites", cur + betting.filter { b -> cur.none { it.second == b.second } })
            }
            p.edit().putInt("sv", 2).apply()
        }
    }

    var lang: String
        get() = p.getString("lang", "en") ?: "en"
        set(v) = p.edit().putString("lang", v).apply()

    /** "google" | "ddg" | "bing" | "yahoo" */
    var engine: String
        get() = p.getString("eng", "google") ?: "google"
        set(v) = p.edit().putString("eng", v).apply()

    /** Lugha ya voice search: "sw" (default) au "en" */
    var voiceLang: String
        get() = p.getString("vlang", "sw") ?: "sw"
        set(v) = p.edit().putString("vlang", v).apply()

    var desktop: Boolean
        get() = p.getBoolean("desk", false)
        set(v) = p.edit().putBoolean("desk", v).apply()

    var thirdCookies: Boolean
        get() = p.getBoolean("tc", true)
        set(v) = p.edit().putBoolean("tc", v).apply()

    var dataSaver: Boolean
        get() = p.getBoolean("ds", false)
        set(v) = p.edit().putBoolean("ds", v).apply()

    var adblock: Boolean
        get() = p.getBoolean("ab", true)
        set(v) = p.edit().putBoolean("ab", v).apply()

    var darkWeb: Boolean
        get() = p.getBoolean("dw", false)
        set(v) = p.edit().putBoolean("dw", v).apply()

    var blockLogJson: String
        get() = p.getString("blog", "{}") ?: "{}"
        set(v) = p.edit().putString("blog", v).apply()

    // ---- Live scores (data ya mpira tu; ufunguo wa API uko kwenye proxy, si kwenye app) ----
    var scoresOn: Boolean
        get() = p.getBoolean("scon", true)
        set(v) = p.edit().putBoolean("scon", v).apply()

    /** Anwani ya proxy ya scores (https://...). Chaguo-msingi inatoka BuildConfig (env var SCORES_BASE_URL). */
    var scoresUrl: String
        get() = if (p.contains("surl")) (p.getString("surl", "") ?: "") else BuildConfig.SCORES_BASE_URL
        set(v) = p.edit().putString("surl", v).apply()

    var scoresToken: String
        get() = if (p.contains("stok")) (p.getString("stok", "") ?: "") else BuildConfig.SCORES_APP_TOKEN
        set(v) = p.edit().putString("stok", v).apply()

    var scoresJson: String
        get() = p.getString("sjson", "[]") ?: "[]"
        set(v) = p.edit().putString("sjson", v).apply()

    var scoresAtMs: Long
        get() = p.getLong("sat", 0L)
        set(v) = p.edit().putLong("sat", v).apply()

    var scoresDate: String
        get() = p.getString("sdate", "") ?: ""
        set(v) = p.edit().putString("sdate", v).apply()

    // ---------------- Notifications ----------------
    /** Kuu: arifa zote. Chaguo-msingi ZIMEZIMWA hadi mtumiaji awashe (opt-in). */
    var nAll: Boolean
        get() = p.getBoolean("n_all", false)
        set(v) = p.edit().putBoolean("n_all", v).apply()
    var nFootball: Boolean
        get() = p.getBoolean("n_fb", true)
        set(v) = p.edit().putBoolean("n_fb", v).apply()
    var nGoals: Boolean
        get() = p.getBoolean("n_goal", true)
        set(v) = p.edit().putBoolean("n_goal", v).apply()
    var nNews: Boolean
        get() = p.getBoolean("n_news", true)
        set(v) = p.edit().putBoolean("n_news", v).apply()
    var nNewsBreaking: Boolean
        get() = p.getBoolean("n_nb", true)
        set(v) = p.edit().putBoolean("n_nb", v).apply()
    var nNewsTz: Boolean
        get() = p.getBoolean("n_nt", true)
        set(v) = p.edit().putBoolean("n_nt", v).apply()
    var nNewsSports: Boolean
        get() = p.getBoolean("n_ns", false)
        set(v) = p.edit().putBoolean("n_ns", v).apply()
    var nNewsFootball: Boolean
        get() = p.getBoolean("n_nf", false)
        set(v) = p.edit().putBoolean("n_nf", v).apply()
    var nNewsTech: Boolean
        get() = p.getBoolean("n_nx", false)
        set(v) = p.edit().putBoolean("n_nx", v).apply()
    var nDownloads: Boolean
        get() = p.getBoolean("n_dl", true)
        set(v) = p.edit().putBoolean("n_dl", v).apply()
    var nAnnounce: Boolean
        get() = p.getBoolean("n_ann", true)
        set(v) = p.edit().putBoolean("n_ann", v).apply()
    var nSecurity: Boolean
        get() = p.getBoolean("n_sec", true)
        set(v) = p.edit().putBoolean("n_sec", v).apply()
    var notifAsked: Int
        get() = p.getInt("n_asked", 0)
        set(v) = p.edit().putInt("n_asked", v).apply()
    var fcmToken: String
        get() = p.getString("fcm_tok", "") ?: ""
        set(v) = p.edit().putString("fcm_tok", v).apply()
    var nHistJson: String
        get() = p.getString("n_hist", "[]") ?: "[]"
        set(v) = p.edit().putString("n_hist", v).apply()
    var nSeenJson: String
        get() = p.getString("n_seen", "[]") ?: "[]"
        set(v) = p.edit().putString("n_seen", v).apply()
    var fcmTopics: Set<String>
        get() {
            val a = JSONArray(p.getString("fcm_topics", "[]"))
            return (0 until a.length()).map { a.getString(it) }.toSet()
        }
        set(v) = p.edit().putString("fcm_topics", JSONArray(v.toList()).toString()).apply()

    class Follow(val label: String, val ko: Long, val events: Set<String>)

    /** Mechi unazozifuata (zinazoisha baada ya saa 36 zinaondolewa zenyewe). */
    fun follows(): Map<String, Follow> {
        val out = LinkedHashMap<String, Follow>()
        try {
            val o = JSONObject(p.getString("n_follow", "{}") ?: "{}")
            val now = System.currentTimeMillis()
            for (id in o.keys()) {
                val f = o.getJSONObject(id)
                val ko = f.optLong("k", 0L)
                if (ko != 0L && now - ko > 36L * 3600 * 1000) continue
                val ev = f.optJSONArray("e")
                val set = (0 until (ev?.length() ?: 0)).map { ev!!.getString(it) }.toSet()
                out[id] = Follow(f.optString("l"), ko, set)
            }
        } catch (e: Exception) { }
        return out
    }

    fun getFollow(id: String): Follow? = follows()[id]

    private fun saveFollows(m: Map<String, Follow>) {
        val o = JSONObject()
        for ((id, f) in m) o.put(id, JSONObject().put("l", f.label).put("k", f.ko).put("e", JSONArray(f.events.toList())))
        p.edit().putString("n_follow", o.toString()).apply()
    }

    fun follow(id: String, label: String, ko: Long, events: Set<String>) {
        val m = LinkedHashMap(follows())
        m[id] = Follow(label, ko, events)
        saveFollows(m)
    }

    fun unfollow(id: String) {
        val m = LinkedHashMap(follows())
        m.remove(id)
        saveFollows(m)
    }

    var newsUpdated: Long
        get() = p.getLong("newsu", 0L)
        set(v) = p.edit().putLong("newsu", v).apply()

    var newsJson: String
        get() = p.getString("news", "{}") ?: "{}"
        set(v) = p.edit().putString("news", v).apply()

    var tabsJson: String
        get() = p.getString("tabs", "{}") ?: "{}"
        set(v) = p.edit().putString("tabs", v).apply()

    fun resetBlocked() = p.edit().putInt("blocked", 0).apply()

    val blocked: Int get() = p.getInt("blocked", 0)

    @Synchronized
    fun addBlocked() = p.edit().putInt("blocked", blocked + 1).apply()

    /** Ad-block imezimwa kwa tovuti hii? (thread-safe, inatumika kwenye background thread) */
    fun isAdOff(host: String?): Boolean = host != null && adOff.contains(host.removePrefix("www."))

    /** Rudisha true ikiwa sasa ad-block IMEZIMWA kwa tovuti hii. */
    fun toggleAdOff(host: String): Boolean {
        val h = host.removePrefix("www.")
        val nowOff = h !in adOff
        adOff = if (nowOff) adOff + h else adOff - h
        p.edit().putString("adoff", JSONArray(adOff.toList()).toString()).apply()
        return nowOff
    }

    fun searches(): List<String> {
        val a = JSONArray(p.getString("srch", "[]"))
        return (0 until a.length()).map { a.getString(it) }
    }

    fun addSearch(q: String) {
        val l = listOf(q) + searches().filter { !it.equals(q, ignoreCase = true) }
        p.edit().putString("srch", JSONArray(l.take(100)).toString()).apply()
    }

    fun removeSearch(q: String) {
        val l = searches().filter { !it.equals(q, ignoreCase = true) }
        p.edit().putString("srch", JSONArray(l).toString()).apply()
    }

    fun clearSearches() = p.edit().remove("srch").apply()

    fun bookmarks() = read("bm")
    fun history() = read("hi")
    fun sites(): List<Pair<String, String>> = if (p.contains("sites")) read("sites") else defaultSites

    fun addBookmark(title: String, url: String) =
        write("bm", listOf(title to url) + read("bm").filter { it.second != url })

    fun addHistory(title: String, url: String) =
        write("hi", (listOf(title to url) + read("hi").filter { it.second != url }).take(200))

    fun addSite(name: String, url: String) =
        write("sites", sites().filter { it.second != url } + (name to url))

    fun removeSite(url: String) = write("sites", sites().filter { it.second != url })

    fun clearHistory() = p.edit().remove("hi").apply()

    private fun readSet(k: String): Set<String> {
        val a = JSONArray(p.getString(k, "[]"))
        return (0 until a.length()).map { a.getString(it) }.toSet()
    }

    private fun read(k: String): List<Pair<String, String>> {
        val a = JSONArray(p.getString(k, "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            o.getString("t") to o.getString("u")
        }
    }

    private fun write(k: String, l: List<Pair<String, String>>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.first).put("u", it.second)) }
        p.edit().putString(k, a.toString()).apply()
    }
}
