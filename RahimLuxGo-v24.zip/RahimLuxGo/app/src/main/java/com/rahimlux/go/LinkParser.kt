package com.rahimlux.go

/**
 * Inasoma maandishi/viungo vinavyoingia kutoka apps nyingine (Share, Open link, Search).
 * Safi (pure Kotlin) ili ijaribiwe kwa unit test. Inafungua http/https PEKEE.
 */
object LinkParser {
    private val urlRegex = Regex("""(?i)\b(?:https?://|www\.)[^\s<>"'`]+""")
    private val domainLike = Regex("""^[\p{L}\p{N}_.-]+\.\p{L}{2,}(:\d{1,5})?([/?#].*)?$""")
    private val spaces = Regex("""\s+""")
    private const val MAX_TEXT = 2000
    private const val MAX_URL = 4096

    /** Rudisha URL salama (http/https), au null kama si salama/haieleweki. */
    fun safeUrl(raw: String?): String? {
        if (raw == null) return null
        var s = trimTrailing(raw.trim())
        if (s.isEmpty() || s.length > MAX_URL) return null
        if (s.startsWith("www.", ignoreCase = true)) s = "https://$s"
        if (s.any { it.isISOControl() || it.isWhitespace() }) return null
        val lower = s.lowercase()
        val rest = when {
            lower.startsWith("https://") -> s.substring(8)
            lower.startsWith("http://") -> s.substring(7)
            else -> return null
        }
        val cut = rest.indexOfFirst { it == '/' || it == '?' || it == '#' }
        val authority = if (cut < 0) rest else rest.substring(0, cut)
        if (authority.isEmpty() || authority.contains('@') || authority.contains('\\')) return null

        val host: String
        val port: String
        if (authority.startsWith("[")) {
            val close = authority.indexOf(']')
            if (close < 2) return null
            host = authority.substring(1, close)
            port = authority.substring(close + 1).removePrefix(":")
            if (!host.all { it.isLetterOrDigit() || it == ':' || it == '.' }) return null
        } else {
            host = authority.substringBefore(':')
            port = if (authority.contains(':')) authority.substringAfter(':') else ""
            if (!host.all { it.isLetterOrDigit() || it == '-' || it == '.' || it == '_' }) return null
            if (host.startsWith(".") || host.endsWith(".") || host.contains("..")) return null
        }
        if (host.isEmpty() || host.length > 253) return null
        if (port.isNotEmpty() && (port.length > 5 || !port.all { it.isDigit() })) return null
        return s
    }

    /**
     * Maandishi → anwani ya kufungua:
     *  1) kama yana URL, rudisha URL hiyo;
     *  2) kama ni jina la tovuti peke yake (example.com), rudisha https://example.com;
     *  3) vinginevyo ni search query → [search] itengeneze URL ya utafutaji.
     */
    fun resolve(text: CharSequence?, search: (String) -> String): String? {
        val t = text?.toString()?.trim()?.take(MAX_TEXT) ?: return null
        if (t.isEmpty()) return null
        urlRegex.find(t)?.let { m -> safeUrl(m.value)?.let { return it } }
        if (!t.contains(' ') && !t.contains('\n') && domainLike.matches(t)) {
            safeUrl("https://$t")?.let { return it }
        }
        return search(spaces.replace(t, " ").take(300))
    }

    fun trimTrailing(input: String): String {
        var s = input
        while (s.isNotEmpty()) {
            val drop = when (s.last()) {
                '.', ',', ';', ':', '!', '?', '"', '\'', '>' -> true
                ')' -> s.count { it == ')' } > s.count { it == '(' }
                ']' -> s.count { it == ']' } > s.count { it == '[' }
                '}' -> s.count { it == '}' } > s.count { it == '{' }
                else -> false
            }
            if (!drop) break
            s = s.dropLast(1)
        }
        return s
    }
}
