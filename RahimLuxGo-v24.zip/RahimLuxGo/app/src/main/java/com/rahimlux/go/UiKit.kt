package com.rahimlux.go

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Vipande vya UI vinavyolingana na SettingsActivity (kadi, safu, switch). */
class UiKit(private val act: AppCompatActivity, private val store: Store) {
    val gold = Color.parseColor("#FFB300")
    fun t(en: String, sw: String) = if (store.lang == "sw") sw else en
    fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    fun header(title: String, actions: List<Pair<String, () -> Unit>> = emptyList()): LinearLayout {
        val head = LinearLayout(act)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(6), dp(10), dp(8), dp(10))
        val back = TextView(act)
        back.text = "←"; back.textSize = 24f; back.setTextColor(Color.WHITE)
        back.setPadding(dp(14), dp(6), dp(14), dp(6))
        back.setOnClickListener { act.finish() }
        val tt = TextView(act)
        tt.text = title; tt.textSize = 20f; tt.setTextColor(Color.WHITE); tt.setTypeface(null, Typeface.BOLD)
        tt.maxLines = 1
        head.addView(back)
        head.addView(tt, LinearLayout.LayoutParams(0, -2, 1f))
        for ((label, fn) in actions) {
            val a = TextView(act)
            a.text = label; a.textSize = 14f; a.setTextColor(gold)
            a.setPadding(dp(10), dp(8), dp(10), dp(8))
            a.setOnClickListener { fn() }
            head.addView(a)
        }
        return head
    }

    fun section(list: LinearLayout, title: String) {
        val tv = TextView(act)
        tv.text = title.uppercase()
        tv.setTextColor(gold); tv.textSize = 12f; tv.setTypeface(null, Typeface.BOLD); tv.letterSpacing = 0.1f
        tv.setPadding(dp(4), dp(22), 0, dp(8))
        list.addView(tv)
    }

    fun card(): LinearLayout {
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.background = act.resources.getDrawable(R.drawable.bg_card, act.theme)
        return c
    }

    fun addCard(list: LinearLayout, c: LinearLayout) {
        if (c.childCount > 0) c.removeViewAt(c.childCount - 1)
        list.addView(c)
    }

    fun arrow(): View {
        val a = TextView(act)
        a.text = "›"; a.textSize = 22f; a.setTextColor(gold)
        return a
    }

    fun row(parent: LinearLayout, title: String, sub: String?, trailing: View?, onClick: (() -> Unit)?) {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(14), dp(16), dp(14))
        val tx = LinearLayout(act)
        tx.orientation = LinearLayout.VERTICAL
        val tt = TextView(act)
        tt.text = title; tt.textSize = 15f; tt.setTextColor(Color.WHITE)
        tx.addView(tt)
        if (sub != null) {
            val ss = TextView(act)
            ss.text = sub; ss.textSize = 12f; ss.setTextColor(Color.parseColor("#8A8A94"))
            tx.addView(ss)
        }
        r.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) r.addView(trailing)
        if (onClick != null) r.setOnClickListener { onClick() }
        parent.addView(r)
        val d = View(act)
        d.setBackgroundColor(Color.parseColor("#14FFFFFF"))
        parent.addView(d, LinearLayout.LayoutParams(-1, 1))
    }

    /** Switch ya kawaida: set() inaitwa mtumiaji akibadilisha. Rudisha SwitchCompat ili uweze kuirudisha nyuma. */
    fun switchRow(parent: LinearLayout, title: String, sub: String?, checked: Boolean, set: (Boolean) -> Unit): SwitchCompat {
        val sw = SwitchCompat(act)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, c -> set(c) }
        row(parent, title, sub, sw) { sw.toggle() }
        return sw
    }
}
