package com.rahimlux.go

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Live scores: inasoma data kutoka PROXY yako (ufunguo wa API haumo ndani ya app). Taarifa za michezo tu. */
object Scores {
    class Result(val matchesJson: String?, val hasLive: Boolean, val error: String?)

    private val LIVE = setOf("1H", "2H", "HT", "ET", "BT", "P", "LIVE", "INT")

    fun hasLive(json: String): Boolean = try {
        val a = JSONArray(json)
        (0 until a.length()).any { a.getJSONObject(it).optString("st") in LIVE }
    } catch (e: Exception) { false }

    private fun clean(s: String?, max: Int): String =
        (s ?: "").filter { !it.isISOControl() }.trim().take(max)

    private fun num(m: JSONObject, k: String): Any = if (m.isNull(k)) JSONObject.NULL else m.optInt(k)

    /** Tumia kwenye background thread. Inarudisha data iliyosafishwa (au kosa). */
    fun fetch(base: String, token: String, date: String): Result {
        var c: HttpURLConnection? = null
        return try {
            val url = base.trim().trimEnd('/') + "/scores?date=" + date
            if (!url.startsWith("https://")) return Result(null, false, "bad_url")
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/json")
            if (token.isNotEmpty()) c.setRequestProperty("X-App-Token", token)
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (body.length > 2_000_000) return Result(null, false, "too_large")
            val o = JSONObject(body)
            if (!o.optBoolean("ok", false)) return Result(null, false, o.optString("error", "bad_response"))
            val src = o.optJSONArray("matches") ?: return Result(null, false, "bad_response")
            val out = JSONArray()
            for (i in 0 until minOf(src.length(), 500)) {
                val m = src.optJSONObject(i) ?: continue
                val h = clean(m.optString("h"), 40)
                val a = clean(m.optString("a"), 40)
                if (h.isEmpty() || a.isEmpty()) continue
                val x = JSONObject()
                x.put("id", m.optLong("id"))
                x.put("lg", clean(m.optString("lg"), 50))
                x.put("co", clean(m.optString("co"), 30))
                x.put("h", h)
                x.put("a", a)
                x.put("hg", num(m, "hg"))
                x.put("ag", num(m, "ag"))
                x.put("st", clean(m.optString("st"), 6).uppercase())
                x.put("min", num(m, "min"))
                x.put("ko", clean(m.optString("ko"), 40))
                out.put(x)
            }
            val text = out.toString()
            Result(text, hasLive(text), null)
        } catch (e: Exception) {
            Result(null, false, "network")
        } finally {
            c?.disconnect()
        }
    }
}
