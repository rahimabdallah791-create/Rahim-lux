package com.rahimlux.go

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Notification Center: All / Unread / Read, mark as read, delete, clear all. */
class NotificationsActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var list: LinearLayout
    private lateinit var chips: LinearLayout
    private var filter = "all"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)
        Notif.ensureChannels(this, store)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0B0D"))
        root.addView(
            ui.header(
                ui.t("Notifications", "Arifa"),
                listOf(
                    "✓" to { Notif.markAllRead(store); render() },
                    "🗑" to { confirmClear() },
                    "⚙️" to { startActivity(Intent(this, NotificationSettingsActivity::class.java)) }
                )
            )
        )
        chips = LinearLayout(this)
        chips.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(6))
        root.addView(chips)

        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(24))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) render()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle(ui.t("Clear all notifications?", "Futa arifa zote?"))
            .setPositiveButton(ui.t("Clear all", "Futa zote")) { _, _ -> Notif.clearAll(store); render() }
            .setNegativeButton(ui.t("Cancel", "Ghairi"), null)
            .show()
    }

    private fun chip(key: String, label: String) {
        val c = TextView(this)
        val on = filter == key
        c.text = label; c.textSize = 12f
        c.setTextColor(if (on) Color.BLACK else Color.parseColor("#DDDDDD"))
        c.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        val bg = GradientDrawable()
        bg.cornerRadius = ui.dp(16).toFloat()
        bg.setColor(if (on) ui.gold else Color.parseColor("#1F1F24"))
        c.background = bg
        c.setPadding(ui.dp(14), ui.dp(7), ui.dp(14), ui.dp(7))
        c.setOnClickListener { filter = key; render() }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.marginEnd = ui.dp(8)
        chips.addView(c, lp)
    }

    private fun render() {
        val all = Notif.history(store)
        val unread = all.count { !it.read }
        chips.removeAllViews()
        chip("all", ui.t("All", "Zote") + " " + all.size)
        chip("unread", ui.t("Unread", "Hazijasomwa") + " " + unread)
        chip("read", ui.t("Read", "Zilizosomwa") + " " + (all.size - unread))

        val items = when (filter) {
            "unread" -> all.filter { !it.read }
            "read" -> all.filter { it.read }
            else -> all
        }
        list.removeAllViews()
        if (items.isEmpty()) {
            val e = TextView(this)
            e.text = if (store.nAll) ui.t("No notifications here.", "Hakuna arifa hapa.")
            else ui.t("Notifications are off.\nTap ⚙️ to turn them on.", "Arifa zimezimwa.\nBonyeza ⚙️ kuziwasha.")
            e.setTextColor(Color.parseColor("#8A8A94")); e.textSize = 14f; e.gravity = Gravity.CENTER
            e.setPadding(0, ui.dp(80), 0, 0)
            list.addView(e, LinearLayout.LayoutParams(-1, -2))
            return
        }
        items.forEach { addCard(it) }
    }

    private fun emoji(type: String) = when (type) {
        "football" -> "⚽"
        "news" -> "📰"
        "announcement" -> "📣"
        "download" -> "⬇️"
        "security" -> "🔒"
        else -> "🔔"
    }

    private fun addCard(n: Notif.Item) {
        val card = LinearLayout(this)
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(ui.dp(12), ui.dp(12), ui.dp(6), ui.dp(12))
        card.background = resources.getDrawable(R.drawable.bg_card, theme)

        val dot = View(this)
        val dbg = GradientDrawable()
        dbg.shape = GradientDrawable.OVAL
        dbg.setColor(if (n.read) Color.TRANSPARENT else ui.gold)
        dot.background = dbg
        card.addView(dot, LinearLayout.LayoutParams(ui.dp(9), ui.dp(9)).apply { marginEnd = ui.dp(10) })

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        val tt = TextView(this)
        tt.text = n.title; tt.textSize = 14f
        tt.setTextColor(if (n.read) Color.parseColor("#B8B8C0") else Color.WHITE)
        tt.setTypeface(null, if (n.read) Typeface.NORMAL else Typeface.BOLD)
        tt.maxLines = 2; tt.ellipsize = TextUtils.TruncateAt.END
        info.addView(tt)
        if (n.body.isNotEmpty()) {
            val bb = TextView(this)
            bb.text = n.body; bb.textSize = 12f; bb.setTextColor(Color.parseColor("#8A8A94"))
            bb.maxLines = 2; bb.ellipsize = TextUtils.TruncateAt.END
            info.addView(bb)
        }
        val meta = TextView(this)
        meta.text = emoji(n.type) + "  " +
            DateUtils.getRelativeTimeSpanString(n.ts, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)
        meta.textSize = 11f; meta.setTextColor(Color.parseColor("#6E6E78"))
        meta.setPadding(0, ui.dp(4), 0, 0)
        info.addView(meta)
        card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))

        val x = TextView(this)
        x.text = "✕"; x.textSize = 16f; x.setTextColor(Color.parseColor("#B0B0B8"))
        x.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8))
        x.setOnClickListener { Notif.delete(store, n.id); render() }
        card.addView(x)

        card.setOnClickListener {
            Notif.markRead(store, n.id)
            if (n.dest.isEmpty() || n.dest == "notifications") render() else startActivity(Notif.openIntent(this, n))
        }
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(10) })
    }
}
