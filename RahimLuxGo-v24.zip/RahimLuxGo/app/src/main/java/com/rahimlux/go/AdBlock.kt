package com.rahimlux.go

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Orodha ya ad/tracker domains: ya ndani + orodha kubwa inayopakuliwa mtandaoni. */
object AdBlock {
    private const val LIST_URL =
        "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext"

    private val builtin = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "adnxs.com", "taboola.com", "outbrain.com", "popads.net",
        "propellerads.com", "exoclick.com", "adsterra.com", "mgid.com", "criteo.com", "criteo.net",
        "scorecardresearch.com", "hotjar.com", "ads.twitter.com", "analytics.tiktok.com",
        "amazon-adsystem.com", "adsrvr.org", "rubiconproject.com", "pubmatic.com", "openx.net",
        "casalemedia.com", "advertising.com", "adform.net", "smartadserver.com", "moatads.com",
        "quantserve.com", "chartbeat.net", "bat.bing.com", "ads.linkedin.com", "ads.pinterest.com",
        "adcolony.com", "applovin.com", "vungle.com", "inmobi.com", "mopub.com", "chartboost.com",
        "startapp.com", "revcontent.com", "zedo.com", "yieldmo.com", "teads.tv", "33across.com",
        "sharethrough.com", "undertone.com", "bidswitch.net", "contextweb.com", "lijit.com",
        "indexww.com", "tapad.com", "bluekai.com", "krxd.net", "demdex.net", "everesttech.net",
        "mathtag.com", "rlcdn.com", "agkn.com", "adroll.com", "mixpanel.com", "segment.io",
        "amplitude.com", "fullstory.com", "mouseflow.com", "crazyegg.com", "optimizely.com",
        "an.yandex.ru", "mc.yandex.ru", "juicyads.com", "trafficjunky.net", "clickadu.com",
        "hilltopads.net", "onclickads.net", "adcash.com", "bidvertiser.com", "media.net",
        "infolinks.com", "popcash.net", "ads.youtube.com"
    )

    @Volatile private var extra: Set<String> = emptySet()
    private var file: File? = null

    fun init(ctx: Context) {
        val f = File(ctx.filesDir, "adlist.txt")
        file = f
        if (f.exists()) extra = f.readLines().filter { it.isNotBlank() }.toHashSet()
    }

    val count: Int get() = builtin.size + extra.size

    fun isStale(): Boolean {
        val f = file ?: return false
        return !f.exists() || System.currentTimeMillis() - f.lastModified() > 7L * 24 * 3600 * 1000
    }

    /** Pakua orodha mpya. Rudisha idadi ya domains, au -1 ikifeli. Tumia background thread. */
    fun update(): Int {
        return try {
            val c = URL(LIST_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 20000
            val re = Regex("^[a-z0-9][a-z0-9.-]*\\.[a-z]{2,}$")
            val domains = c.inputStream.bufferedReader().readLines()
                .map { it.trim().lowercase() }
                .filter { re.matches(it) }
                .toHashSet()
            c.disconnect()
            if (domains.size < 100) return -1
            file?.writeText(domains.joinToString("\n"))
            extra = domains
            domains.size
        } catch (e: Exception) {
            -1
        }
    }

    fun isBlocked(host: String): Boolean {
        var h = host.lowercase()
        while (true) {
            if (h in builtin || h in extra) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    private val media = listOf(".mp4", ".webm", ".m3u8", ".mov", ".avi")
    fun isHeavyMedia(path: String) = media.any { path.endsWith(it, ignoreCase = true) }
}
