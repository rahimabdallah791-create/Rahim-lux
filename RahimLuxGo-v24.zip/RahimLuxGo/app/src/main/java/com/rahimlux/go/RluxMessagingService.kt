package com.rahimlux.go

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Inapokea push (app wazi, background au imefungwa). Seva inatuma DATA messages,
 * kwa hiyo app yenyewe ndiyo inaamua kuonyesha (kulingana na mipangilio ya mtumiaji) na kuzuia duplicate.
 */
class RluxMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        try {
            Store(this).fcmToken = token
            Push.register(this, token)
            Push.syncTopics(this)
        } catch (e: Exception) { }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        try {
            val d = HashMap<String, String>(message.data)
            if (d.isEmpty()) {
                // Ujumbe wa "notification" (mfano kutoka Firebase console)
                val n = message.notification ?: return
                d["type"] = "announcement"
                d["title"] = n.title ?: ""
                d["body"] = n.body ?: ""
            }
            if (d["id"].isNullOrEmpty()) d["id"] = message.messageId ?: System.currentTimeMillis().toString()
            Notif.handleIncoming(applicationContext, d)
        } catch (e: Exception) {
            // Usiangushe app kwa ujumbe mbovu
        }
    }
}
