package com.rahimlux.go

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ukurasa wa mechi (deep link ya arifa za mpira) + Follow Match na chaguo za arifa. Taarifa tu, hakuna odds. */
class MatchActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var body: LinearLayout
    private var id = ""
    private val perm = PermHelper(this)
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false

    private val tick = object : Runnable {
        override fun run() {
            fetch()
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)
        id = intent.getStringExtra("id") ?: ""
        if (id.isEmpty() || id.length > 12 || !id.all { it.isDigit() }) { finish(); return }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0B0D"))
        root.addView(ui.header(ui.t("Match", "Mechi")))
        val scroll = ScrollView(this)
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(28))
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (id.isNotEmpty() && ::body.isInitialized) {
            render()
            handler.post(tick)
        }
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun find(): JSONObject? = try {
        val a = JSONArray(store.scoresJson)
        var found: JSONObject? = null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optLong("id").toString() == id) { found = o; break }
        }
        found
    } catch (e: Exception) { null }

    private fun koMillis(ko: String): Long = try {
        java.time.OffsetDateTime.parse(ko).toInstant().toEpochMilli()
    } catch (e: Exception) { 0L }

    private fun koText(ko: String): String = try {
        java.time.format.DateTimeFormatter.ofPattern("EEE d MMM, HH:mm")
            .format(java.time.OffsetDateTime.parse(ko).atZoneSameInstant(java.time.ZoneId.systemDefault()))
    } catch (e: Exception) { "" }

    private fun fetch() {
        if (busy || store.scoresUrl.isEmpty()) return
        busy = true
        val base = store.scoresUrl
        val token = store.scoresToken
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        Thread {
            val r = Scores.fetch(base, token, date)
            runOnUiThread {
                busy = false
                if (r.matchesJson != null) {
                    store.scoresJson = r.matchesJson
                    store.scoresAtMs = System.currentTimeMillis()
                    store.scoresDate = date
                    render()
                }
            }
        }.start()
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false, gravity: Int = Gravity.START): TextView {
        val t = TextView(this)
        t.text = s; t.textSize = size; t.setTextColor(color); t.gravity = gravity
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun render() {
        body.removeAllViews()
        val m = find()
        if (m == null) {
            body.addView(
                text(
                    ui.t("Match not found yet.\nOpen Live scores on Home, or wait a moment while it loads.", "Mechi haijapatikana bado.\nFungua Live scores kwenye Home, au subiri kidogo."),
                    14f, Color.parseColor("#8A8A94"), gravity = Gravity.CENTER
                ).also { it.setPadding(0, ui.dp(60), 0, 0) }
            )
            return
        }
        val h = m.optString("h")
        val a = m.optString("a")
        val st = m.optString("st")
        val ko = m.optString("ko")
        val minV = if (m.isNull("min")) null else m.optInt("min")
        val hg = if (m.isNull("hg")) "-" else m.optInt("hg").toString()
        val ag = if (m.isNull("ag")) "-" else m.optInt("ag").toString()

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(ui.dp(18), ui.dp(18), ui.dp(18), ui.dp(18))
        card.background = resources.getDrawable(R.drawable.bg_card, theme)
        card.addView(text(listOf(m.optString("lg"), m.optString("co")).filter { it.isNotEmpty() }.joinToString(" · "), 12f, Color.parseColor("#8d8775")))
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, ui.dp(14), 0, ui.dp(10))
        row.addView(text(h, 16f, Color.WHITE, true, Gravity.CENTER), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text("$hg – $ag", 28f, ui.gold, true, Gravity.CENTER))
        row.addView(text(a, 16f, Color.WHITE, true, Gravity.CENTER), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row)
        val status = when {
            st in setOf("1H", "2H", "ET", "BT", "P", "LIVE", "INT") -> "● LIVE" + (if (minV != null) " $minV'" else "")
            st == "HT" -> "HT"
            st in setOf("FT", "AET", "PEN") -> "FT"
            st == "NS" || st == "TBD" -> koText(ko)
            else -> st
        }
        val live = status.startsWith("●")
        card.addView(text(status, 14f, if (live) Color.parseColor("#FF5252") else Color.parseColor("#A8A290"), true, Gravity.CENTER))
        if (!live && st != "NS" && st != "TBD" && koText(ko).isNotEmpty()) {
            card.addView(text(koText(ko), 12f, Color.parseColor("#6E6E78"), false, Gravity.CENTER))
        }
        body.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(8) })

        // ---- Follow
        val f = store.getFollow(id)
        val btn = text(
            if (f != null) "★ " + ui.t("Following", "Unafuata") else "☆ " + ui.t("Follow match", "Fuata mechi"),
            15f, if (f != null) Color.BLACK else ui.gold, true, Gravity.CENTER
        )
        val bg = GradientDrawable()
        bg.cornerRadius = ui.dp(26).toFloat()
        if (f != null) bg.setColor(ui.gold) else { bg.setColor(Color.TRANSPARENT); bg.setStroke(ui.dp(2), ui.gold) }
        btn.background = bg
        btn.setPadding(0, ui.dp(14), 0, ui.dp(14))
        btn.setOnClickListener { toggleFollow("$h vs $a", koMillis(ko)) }
        body.addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(16) })

        if (!Push.configured(this)) {
            body.addView(
                text(
                    ui.t("Push alerts need Firebase on this build. Your choice is saved and will work once it is set up.",
                        "Arifa za push zinahitaji Firebase kwenye build hii. Chaguo lako limehifadhiwa na litafanya kazi ukiisha kuiweka."),
                    11f, Color.parseColor("#8A8A94")
                ).also { it.setPadding(ui.dp(4), ui.dp(8), ui.dp(4), 0) }
            )
        }

        if (f != null) {
            ui.section(body, ui.t("Notify me about", "Nijulishe kuhusu"))
            val c = ui.card()
            val opts = listOf(
                "goal" to ui.t("Goals", "Magoli"), "start" to ui.t("Match start", "Mechi kuanza"),
                "ht" to ui.t("Half-time", "Mapumziko"), "ft" to ui.t("Full-time", "Mwisho wa mechi"),
                "et" to ui.t("Extra time", "Muda wa ziada"), "pen" to ui.t("Penalties", "Penalti")
            )
            for ((key, label) in opts) {
                ui.switchRow(c, label, null, key in f.events) { on ->
                    val cur = store.getFollow(id)
                    if (cur != null) {
                        val ev = cur.events.toMutableSet()
                        if (on) ev.add(key) else ev.remove(key)
                        store.follow(id, cur.label, cur.ko, ev)
                        Push.syncTopics(this)
                    }
                }
            }
            ui.addCard(body, c)
            body.addView(
                text(
                    ui.t("You will always be told if the match is postponed or cancelled.", "Utajulishwa kila mara mechi ikiahirishwa au kufutwa."),
                    11f, Color.parseColor("#8A8A94")
                ).also { it.setPadding(ui.dp(4), ui.dp(8), ui.dp(4), 0) }
            )
        }
    }

    private fun toggleFollow(label: String, ko: Long) {
        if (store.getFollow(id) != null) {
            store.unfollow(id)
            Push.syncTopics(this)
            render()
            return
        }
        perm.ensure { ok ->
            if (ok) {
                store.nAll = true
                store.nFootball = true
                store.follow(id, label, ko, setOf("goal", "start", "ht", "ft"))
                Notif.ensureChannels(this, store)
                Push.refreshToken(this)
                Push.syncTopics(this)
            } else {
                toast(ui.t("Allow notifications to follow matches", "Ruhusu arifa ili ufuate mechi"))
            }
            render()
        }
    }
}
