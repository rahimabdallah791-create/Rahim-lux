package com.rahimlux.go

import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** Orodha ya domains zilizozuiwa na mara ngapi kila moja. */
object BlockLog {
    private val map = ConcurrentHashMap<String, Int>()

    fun add(key: String) { map.merge(key, 1) { a, b -> a + b } }

    fun top(n: Int = 100): List<Pair<String, Int>> =
        map.entries.map { it.key to it.value }.sortedByDescending { it.second }.take(n)

    fun clear() = map.clear()

    fun toJson(): String {
        val o = JSONObject()
        top(300).forEach { o.put(it.first, it.second) }
        return o.toString()
    }

    fun load(s: String) {
        try {
            val o = JSONObject(s)
            o.keys().forEach { map[it] = o.getInt(it) }
        } catch (e: Exception) { }
    }
}
