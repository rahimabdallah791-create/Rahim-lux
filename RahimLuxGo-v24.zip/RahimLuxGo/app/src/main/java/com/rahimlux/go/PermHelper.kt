package com.rahimlux.go

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat

/**
 * Ruhusa ya arifa (Android 13+). Inaomba kwa wakati unaofaa (si kila mara):
 * ikikataliwa mara ya pili, inaelekeza kwenye App Notification Settings badala ya kuonyesha popup tena.
 * Tengeneza kama field ya Activity (inajiandikisha mapema).
 */
class PermHelper(private val act: AppCompatActivity) {
    private var cb: ((Boolean) -> Unit)? = null

    private val launcher = act.registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) {
            val s = Store(act)
            s.notifAsked = s.notifAsked + 1
        }
        cb?.invoke(ok && granted())
        cb = null
    }

    fun granted(): Boolean = NotificationManagerCompat.from(act).areNotificationsEnabled()

    fun ensure(onResult: (Boolean) -> Unit) {
        if (granted()) { onResult(true); return }
        val store = Store(act)
        if (Build.VERSION.SDK_INT < 33) { openSettingsDialog(store); onResult(false); return }
        val perm = Manifest.permission.POST_NOTIFICATIONS
        val asked = store.notifAsked
        if (asked >= 2 || (asked >= 1 && !act.shouldShowRequestPermissionRationale(perm))) {
            openSettingsDialog(store)
            onResult(false)
            return
        }
        cb = onResult
        try { launcher.launch(perm) } catch (e: Exception) { cb = null; onResult(false) }
    }

    private fun t(s: Store, en: String, sw: String) = if (s.lang == "sw") sw else en

    private fun openSettingsDialog(s: Store) {
        AlertDialog.Builder(act)
            .setTitle(t(s, "Notifications are off", "Arifa zimezimwa"))
            .setMessage(
                t(
                    s, "Allow notifications for Rahim Lux Go in Android settings to get football alerts and news.",
                    "Ruhusu arifa za Rahim Lux Go kwenye mipangilio ya Android ili upate arifa za mpira na habari."
                )
            )
            .setPositiveButton(t(s, "Open settings", "Fungua mipangilio")) { _, _ ->
                try {
                    act.startActivity(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)
                    )
                } catch (e: Exception) { }
            }
            .setNegativeButton(t(s, "Not now", "Sio sasa"), null)
            .show()
    }
}
