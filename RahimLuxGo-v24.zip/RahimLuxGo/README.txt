RAHIM LUX GO v24 - Android browser (Kotlin + WebView)
Mpya v24: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
