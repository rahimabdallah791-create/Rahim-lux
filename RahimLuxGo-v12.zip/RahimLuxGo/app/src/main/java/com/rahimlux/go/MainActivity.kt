package com.rahimlux.go

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Message
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import org.json.JSONArray
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private val homeHost = "home.rahimlux.go"
    private val home = "https://$homeHost/"
    private val accent = Color.parseColor("#FFB300")

    private val brand = mapOf(
        "Google" to "#4285F4", "YouTube" to "#FF0000", "Facebook" to "#1877F2",
        "Instagram" to "#E1306C", "WhatsApp" to "#25D366", "TikTok" to "#222222",
        "Wikipedia" to "#636466", "Mwananchi" to "#E53935",
        "Betway" to "#00A826", "Betpawa" to "#1F8A4C", "SportyBet" to "#00A64F", "1win" to "#2D6BFF"
    )
    private val palette = listOf("#FF7043", "#26A69A", "#5C6BC0", "#AB47BC", "#EC407A", "#29B6F6", "#9CCC65", "#FFA726")

    private lateinit var store: Store
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var tabsCount: TextView
    private lateinit var suggestList: ListView
    private lateinit var dlBtn: TextView
    private lateinit var adBox: FrameLayout
    private lateinit var adView: AdView
    private lateinit var bottomBar: View
    private val tabs = mutableListOf<WebView>()
    private var cur = 0
    private var fullUrl = ""
    private val web get() = tabs[cur]
    private var pendingDl: (() -> Unit)? = null
    private var adOk = false
    private var kbOpen = false
    private var programmatic = false
    private var suggestions = listOf<String>()
    private var suggestSeq = 0
    private var suggestJob: Runnable? = null
    private var videoUrl: String? = null
    private val handler = Handler(Looper.getMainLooper())

    /** Tafsiri: Kiingereza (default) / Kiswahili */
    private fun t(en: String, sw: String) = if (store.lang == "sw") sw else en

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) load(said)
        }
    }

    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pendingDl?.invoke() else toast(t("Storage permission is needed to download", "Ruhusa ya kuhifadhi inahitajika ili kupakua"))
        pendingDl = null
    }

    /** Hukagua kila sekunde chache kama ukurasa una video ya kupakua. */
    private val poll = object : Runnable {
        override fun run() {
            if (tabs.isNotEmpty() && fullUrl.isNotEmpty() && !kbOpen) {
                val js = "(function(){var v=document.querySelector('video');if(!v)return '';var s=v.currentSrc||v.src||'';if(!s){var e=v.querySelector('source');s=e?e.src:''}return s})()"
                web.evaluateJavascript(js) { res ->
                    val s = try { JSONTokener(res).nextValue() as? String } catch (e: Exception) { null }
                    if (!s.isNullOrEmpty() && s.startsWith("http") && !s.contains(".m3u8")) offerVideo(s)
                }
            }
            handler.postDelayed(this, 2500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        AdBlock.init(applicationContext)
        BlockLog.load(store.blockLogJson)
        if (AdBlock.isStale()) Thread { AdBlock.update() }.start()

        urlBar = findViewById(R.id.url)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.container)
        tabsCount = findViewById(R.id.tabsCount)
        suggestList = findViewById(R.id.suggestList)
        dlBtn = findViewById(R.id.dlBtn)
        adBox = findViewById(R.id.adBox)
        bottomBar = findViewById(R.id.bottomBar)

        MobileAds.initialize(this) { }
        adView = AdView(this)
        adView.setAdSize(AdSize.LARGE_BANNER)
        adView.adUnitId = getString(R.string.admob_banner_id)
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() { adOk = true; updateAd() }
            override fun onAdFailedToLoad(e: LoadAdError) { adOk = false; updateAd() }
        }
        adBox.addView(adView, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        adView.loadAd(AdRequest.Builder().build())

        // Kibodi wazi: ficha tangazo, bar ya chini na kitufe cha video
        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {
            val vis = ViewCompat.getRootWindowInsets(window.decorView)
                ?.isVisible(WindowInsetsCompat.Type.ime()) ?: false
            if (vis != kbOpen) {
                kbOpen = vis
                bottomBar.visibility = if (vis) View.GONE else View.VISIBLE
                if (vis) dlBtn.visibility = View.GONE
                updateAd()
            }
        }

        urlBar.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                load(urlBar.text.toString()); true
            } else false
        }
        urlBar.setOnFocusChangeListener { _, f ->
            if (f) { setBar(fullUrl); urlBar.selectAll() } else { setBar(pretty(fullUrl)); hideSuggestions() }
        }
        urlBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (programmatic || !urlBar.hasFocus()) return
                val q = s?.toString()?.trim() ?: ""
                if (q.length < 2 || q.startsWith("http") || (!q.contains(" ") && q.contains("."))) {
                    hideSuggestions(); return
                }
                suggest(q)
            }
        })
        suggestList.setOnItemClickListener { _, _, i, _ ->
            val s = suggestions.getOrNull(i) ?: return@setOnItemClickListener
            hideSuggestions()
            load(s)
        }
        dlBtn.setOnClickListener {
            videoUrl?.let { download(it, web.settings.userAgentString, "", "video/mp4") }
            dlBtn.visibility = View.GONE
        }

        findViewById<View>(R.id.mic).setOnClickListener { startVoice() }
        findViewById<View>(R.id.back).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.fwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.homeBtn).setOnClickListener { web.loadUrl(home) }
        findViewById<View>(R.id.tabsBox).setOnClickListener { showTabs() }
        findViewById<View>(R.id.menuBtn).setOnClickListener { showMenu() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    suggestList.visibility == View.VISIBLE -> hideSuggestions()
                    web.canGoBack() -> web.goBack()
                    tabs.size > 1 -> closeTab()
                    else -> finish()
                }
            }
        })

        newTab(intent?.data?.toString() ?: home)
    }

    // ---------------- Tabs ----------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String, incognito: Boolean = false, load: Boolean = true) {
        val w = WebView(this)
        w.tag = if (incognito) "inc" else null
        w.setBackgroundColor(Color.parseColor("#0B0B0D"))
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = store.dataSaver
        if (incognito) w.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        applyDark(w)
        w.settings.setSupportMultipleWindows(true)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.thirdCookies)
        w.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val host = r.url.host ?: return null
                if (host == homeHost) {
                    val p = r.url.path
                    return when {
                        p.isNullOrEmpty() || p == "/" -> html(homeHtml(v.tag == "inc"))
                        p == "/logo.png" -> WebResourceResponse("image/png", null, resources.openRawResource(R.raw.logo))
                        else -> empty()
                    }
                }
                if (store.adblock && AdBlock.isBlocked(host)) { store.addBlocked(); BlockLog.add(host); return empty() }
                val path = r.url.path ?: ""
                if (store.dataSaver && AdBlock.isHeavyMedia(path)) { store.addBlocked(); BlockLog.add("🎞 $host"); return empty() }
                if (path.endsWith(".mp4", true) || path.endsWith(".webm", true)) {
                    val u = r.url.toString()
                    runOnUiThread { if (v === web) offerVideo(u) }
                }
                return null
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: return false
                if (s == "http" || s == "https" || s == "about" || s == "data") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }

            override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                runOnUiThread { recreate() }
                return true
            }

            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                if (v === web) {
                    showUrl(u)
                    progress.visibility = View.VISIBLE
                    videoUrl = null
                    dlBtn.visibility = View.GONE
                }
            }

            override fun onPageFinished(v: WebView, u: String) {
                if (v === web) progress.visibility = View.GONE
                if (v.tag != "inc" && u.startsWith("http") && Uri.parse(u).host != homeHost) {
                    store.addHistory(v.title ?: u, u)
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === web) progress.progress = p
            }

            // Madirisha ya login (mfano "Sign in with Google") yanafunguka kama tab mpya
            override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false
                newTab("about:blank", v.tag == "inc", false)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = web
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val i = tabs.indexOf(window)
                if (i >= 0 && tabs.size > 1) { cur = i; closeTab() }
            }
        }
        tabs.add(w)
        show(tabs.size - 1)
        if (load) w.loadUrl(url)
    }

    private fun applyDark(w: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, store.darkWeb)
        }
    }

    private fun show(i: Int) {
        cur = i
        container.removeAllViews()
        container.addView(web, FrameLayout.LayoutParams(-1, -1))
        updateHint()
        showUrl(web.url ?: "")
        tabsCount.text = tabs.size.toString()
        videoUrl = null
        dlBtn.visibility = View.GONE
        hideSuggestions()
    }

    private fun closeTab() {
        if (tabs.size == 1) { web.loadUrl(home); return }
        container.removeAllViews()
        val w = tabs.removeAt(cur)
        if (w.tag == "inc") { w.clearCache(true); w.clearHistory() }
        w.destroy()
        show(minOf(cur, tabs.size - 1))
    }

    private fun updateHint() {
        urlBar.hint = if (web.tag == "inc") t("🕶 Private tab", "🕶 Tab ya faragha")
        else t("Search or type address", "Tafuta au andika anwani")
    }

    // ---------------- URL bar, suggestions ----------------

    private fun setBar(s: String) { programmatic = true; urlBar.setText(s); programmatic = false }

    private fun pretty(u: String): String =
        if (u.isEmpty()) "" else (Uri.parse(u).host?.removePrefix("www.") ?: u)

    private fun showUrl(u: String) {
        fullUrl = if (Uri.parse(u).host == homeHost) "" else u
        if (!urlBar.hasFocus()) setBar(pretty(fullUrl))
        updateAd()
    }

    private fun updateAd() {
        adBox.visibility = if (fullUrl.isEmpty() && adOk && !kbOpen) View.VISIBLE else View.GONE
    }

    private fun load(input: String) {
        val t = input.trim()
        val url = when {
            t.isEmpty() -> return
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(" ") && t.contains(".") -> "https://$t"
            else -> "https://www.google.com/search?hl=" + (if (store.lang == "sw") "sw" else "en") + "&q=" + Uri.encode(t)
        }
        hideSuggestions()
        web.loadUrl(url)
        urlBar.clearFocus()
    }

    private fun suggest(q: String) {
        suggestJob?.let { handler.removeCallbacks(it) }
        val seq = ++suggestSeq
        val r = Runnable {
            Thread {
                val list = try {
                    val lang = if (store.lang == "sw") "sw" else "en"
                    val c = URL("https://suggestqueries.google.com/complete/search?client=firefox&hl=$lang&q=" + Uri.encode(q))
                        .openConnection() as HttpURLConnection
                    c.connectTimeout = 4000
                    c.readTimeout = 4000
                    val body = c.inputStream.bufferedReader().readText()
                    c.disconnect()
                    val a = JSONArray(body).getJSONArray(1)
                    (0 until a.length()).map { a.getString(it) }.take(8)
                } catch (e: Exception) {
                    emptyList<String>()
                }
                runOnUiThread { if (seq == suggestSeq) showSuggestions(list) }
            }.start()
        }
        suggestJob = r
        handler.postDelayed(r, 250)
    }

    private fun showSuggestions(l: List<String>) {
        suggestions = l
        if (l.isEmpty() || !urlBar.hasFocus()) { suggestList.visibility = View.GONE; return }
        suggestList.adapter = ArrayAdapter(this, R.layout.item_suggest, l.map { "🔍  $it" })
        suggestList.visibility = View.VISIBLE
    }

    private fun hideSuggestions() {
        suggestSeq++
        suggestJob?.let { handler.removeCallbacks(it) }
        suggestList.visibility = View.GONE
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (store.lang == "sw") "sw-TZ" else "en-US")
            putExtra(RecognizerIntent.EXTRA_PROMPT, t("Say what you want to search", "Sema unachotafuta…"))
        }
        try { voice.launch(i) } catch (e: Exception) {
            toast(t("Voice search is not available on this phone", "Voice search haipatikani kwenye simu hii"))
        }
    }

    // ---------------- Video / downloads ----------------

    private fun offerVideo(u: String) {
        videoUrl = u
        if (!kbOpen && fullUrl.isNotEmpty()) dlBtn.visibility = View.VISIBLE
    }

    private fun download(url: String, ua: String, cd: String, mime: String) {
        if (!url.startsWith("http")) { toast(t("This link can't be downloaded", "Kiungo hiki hakiwezi kupakuliwa")); return }
        val go: () -> Unit = {
            try {
                val name = URLUtil.guessFileName(url, cd, mime)
                val req = DownloadManager.Request(Uri.parse(url))
                if (mime.isNotEmpty()) req.setMimeType(mime)
                req.addRequestHeader("User-Agent", ua)
                web.url?.let { req.addRequestHeader("Referer", it) }
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setTitle(name)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                toast(t("Downloading: ", "Inapakua: ") + name)
            } catch (e: Exception) {
                toast(t("Download failed", "Imeshindwa kupakua"))
            }
        }
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDl = go
            storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else go()
    }

    // ---------------- Home page ----------------

    private fun html(s: String) = WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(s.toByteArray()))
    private fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;")

    private fun floaters(): String {
        val sym = listOf("✦", "◆", "➤", "★", "⚡", "👑", "🌐", "✧", "▶", "●", "✦", "◆", "★", "✧")
        return sym.mapIndexed { i, s ->
            val left = (i * 83 + 7) % 94
            val size = 14 + (i * 7) % 22
            val dur = 14 + (i * 5) % 12
            val delay = -((i * 3) % 14)
            "<span style='left:$left%;font-size:${size}px;animation-duration:${dur}s;animation-delay:${delay}s'>$s</span>"
        }.joinToString("")
    }

    private fun homeHtml(inc: Boolean): String {
        val acc = if (inc) "#8E5CFF" else "#FFB300"
        val glow = if (inc) "rgba(142,92,255,.45)" else "rgba(255,179,0,.40)"
        val tiles = store.sites().joinToString("") { (n, u) ->
            val c = brand[n] ?: palette[Math.abs(n.hashCode()) % palette.size]
            val host = Uri.parse(u).host ?: ""
            "<a class=t href='${esc(u)}'><i style='background:$c'><span>${esc(n.take(1).uppercase())}</span>" +
                "<img src='https://www.google.com/s2/favicons?domain=${esc(host)}&amp;sz=128' onload=\"this.style.background='#fff'\" onerror='this.remove()'></i>" +
                "<b>${esc(n)}</b></a>"
        }
        val on = t("ON", "ON")
        val off = t("OFF", "OFF")
        val ds = if (store.dataSaver) on else off
        val ab = if (store.adblock) on else off
        val logo = if (inc) "<div class=lg>&#128374;</div>" else "<img class=lg src='/logo.png'>"
        val tag = if (inc) t("Private tab: history is not saved", "Tab ya faragha: historia haihifadhiwi")
        else t("Fast, secure and smart browser", "Kivinjari cha haraka na salama")
        val lBlocked = t("Blocked", "Vilivyozuiwa")
        return """<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><meta name=color-scheme content=dark><title>Rahim Lux Go</title><style>
body{margin:0;min-height:100vh;background:radial-gradient(circle at 50% 12%,#2a2008 0%,#0B0B0D 62%);color:#fff;font-family:sans-serif;text-align:center;box-sizing:border-box}
.c{position:relative;z-index:1;padding:28px 18px}
.f{position:fixed;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;z-index:0}
.f span{position:absolute;bottom:-60px;color:$acc;opacity:0;animation-name:up;animation-timing-function:linear;animation-iteration-count:infinite}
@keyframes up{0%{transform:translateY(0) rotate(0deg);opacity:0}12%{opacity:.22}85%{opacity:.18}100%{transform:translateY(-115vh) rotate(300deg);opacity:0}}
h1{margin:18px 0 4px;font-size:30px}h1 span{color:$acc}
p{margin:0 0 28px;color:#a8a290;font-size:14px}
.lg{width:96px;height:96px;border-radius:26px;margin:10px auto 0;display:flex;align-items:center;justify-content:center;font-size:42px;background:$acc;box-shadow:0 0 38px $glow}
img.lg{display:block;background:none;object-fit:cover}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:20px 8px;max-width:420px;margin:0 auto}
.t{text-decoration:none;color:#ddd;font-size:12px}
.t i{display:block;position:relative;overflow:hidden;width:56px;height:56px;border-radius:18px;margin:0 auto 8px;line-height:56px;font-style:normal;font-size:24px;font-weight:700;color:#fff}
.t i img{position:absolute;left:0;top:0;width:100%;height:100%;box-sizing:border-box;padding:10px;object-fit:contain}
.t b{font-weight:500;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.s{margin:34px auto 0;max-width:420px;background:rgba(30,30,34,.85);border:1px solid rgba(255,179,0,.25);border-radius:18px;padding:16px;display:flex;justify-content:space-around}
.s div{font-size:12px;color:#a8a290}.s strong{display:block;font-size:22px;color:#fff;margin-bottom:2px}
</style></head><body>
<div class=f>${floaters()}</div>
<div class=c>
$logo
<h1>Rahim Lux <span>Go</span></h1><p>$tag</p>
<div class=g>$tiles</div>
<div class=s><div><strong>${store.blocked}</strong>$lBlocked</div><div><strong>$ds</strong>Data saver</div><div><strong>$ab</strong>Ad-block</div></div>
</div>
</body></html>"""
    }

    // ---------------- Dialogs / menu ----------------

    private fun showTabs() {
        val names = tabs.map {
            (if (it.tag == "inc") "🕶 " else "") + (it.title?.take(40) ?: pretty(it.url ?: "").ifEmpty { t("New tab", "Tab mpya") })
        } + t("＋ New tab", "＋ Tab mpya")
        AlertDialog.Builder(this).setTitle("Tabs")
            .setItems(names.toTypedArray()) { _, i ->
                if (i == tabs.size) newTab(home) else show(i)
            }.show()
    }

    private fun manageSites() {
        val s = store.sites()
        if (s.isEmpty()) { toast(t("Home has no sites", "Home haina tovuti")); return }
        AlertDialog.Builder(this).setTitle(t("Tap a site to remove it", "Gusa tovuti ili kuiondoa"))
            .setItems(s.map { it.first }.toTypedArray()) { _, i ->
                store.removeSite(s[i].second)
                toast(t("Removed", "Imeondolewa"))
            }.show()
    }

    private fun showMenu() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = layoutInflater.inflate(R.layout.sheet_menu, null)
        val statsView = root.findViewById<TextView>(R.id.stats)
        statsView.text = "🛡 ${store.blocked} " + t("blocked", "zimezuiwa") + " ›"
        statsView.setOnClickListener { d.dismiss(); showBlocked() }
        val grid = root.findViewById<GridLayout>(R.id.grid)

        fun cell(icon: String, label: String, on: Boolean? = null, action: () -> Unit) {
            val color = when (on) {
                true -> accent
                false -> Color.parseColor("#8A8A94")
                null -> Color.WHITE
            }
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            box.setPadding(0, 22, 0, 22)
            val ic = TextView(this)
            ic.text = icon; ic.textSize = 24f; ic.gravity = Gravity.CENTER
            val lb = TextView(this)
            lb.text = label; lb.textSize = 11f; lb.gravity = Gravity.CENTER; lb.setTextColor(color)
            box.addView(ic)
            box.addView(lb)
            box.setOnClickListener { d.dismiss(); action() }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            grid.addView(box, lp)
        }

        cell("➕", t("New tab", "Tab mpya")) { newTab(home) }
        cell("🕶", t("Private", "Faragha")) { newTab(home, true) }
        cell("✖️", t("Close tab", "Funga tab")) { closeTab() }
        cell("🔄", t("Reload", "Pakia upya")) { web.reload() }

        cell("⭐", t("Bookmark", "Bookmark")) {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) {
                store.addBookmark(web.title ?: u, u); toast(t("Saved ⭐", "Imehifadhiwa ⭐"))
            }
        }
        cell("📚", "Bookmarks") { pick("Bookmarks", store.bookmarks()) }
        cell("🕘", "History") { pick("History", store.history()) }
        cell("⬇️", t("Downloads", "Vipakuliwa")) {
            try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
            catch (e: Exception) { toast(t("Open Files > Downloads", "Fungua Files > Downloads")) }
        }

        cell("🛡️", "Ad-block", store.adblock) {
            store.adblock = !store.adblock
            web.reload()
            toast(if (store.adblock) t("Ad-block on", "Ad-block imewashwa") else t("Ad-block off", "Ad-block imezimwa"))
        }
        cell("📉", "Data saver", store.dataSaver) {
            store.dataSaver = !store.dataSaver
            tabs.forEach { w -> w.settings.blockNetworkImage = store.dataSaver }
            web.reload()
            toast(if (store.dataSaver) t("Data saver on", "Data saver imewashwa") else t("Data saver off", "Data saver imezimwa"))
        }
        cell("🍪", "3rd-party cookies", store.thirdCookies) {
            store.thirdCookies = !store.thirdCookies
            tabs.forEach { w -> CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.thirdCookies) }
            web.reload()
            toast(if (store.thirdCookies) t("3rd-party cookies on (logins work better)", "Cookies za third-party zimewashwa")
            else t("3rd-party cookies off (more private)", "Cookies za third-party zimezimwa"))
        }
        cell("🌙", "Dark web", store.darkWeb) {
            store.darkWeb = !store.darkWeb
            tabs.forEach { w -> applyDark(w) }
            web.reload()
            toast(if (store.darkWeb) t("Dark mode on", "Dark mode imewashwa") else t("Dark mode off", "Dark mode imezimwa"))
        }
        cell("🏠", t("Add to Home", "Ongeza Home")) {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) {
                store.addSite((web.title ?: pretty(u)).take(14), u)
                toast(t("Added to Home", "Imeongezwa kwenye Home"))
            } else toast(t("Open a website first", "Fungua tovuti kwanza"))
        }

        cell("✏️", t("Edit Home", "Dhibiti Home")) { manageSites() }
        cell("🔁", t("Update list", "Sasisha list")) {
            toast(t("Updating ad list…", "Inasasisha ad-list…"))
            Thread {
                val n = AdBlock.update()
                runOnUiThread {
                    toast(if (n > 0) t("Ad list updated: $n domains", "Ad-list imesasishwa: $n domains")
                    else t("Update failed, try again", "Imeshindwa, jaribu tena"))
                }
            }.start()
        }
        cell("🚫", t("Blocked", "Zilizozuiwa")) { showBlocked() }
        cell("🔗", "Share") {
            if (fullUrl.isNotEmpty()) {
                val s = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, fullUrl) }
                startActivity(Intent.createChooser(s, t("Share via", "Tuma kupitia")))
            }
        }
        cell("🗑️", t("Clear data", "Futa data")) {
            store.clearHistory()
            tabs.forEach { w -> w.clearCache(true); w.clearHistory() }
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            toast(t("Data cleared", "Data imefutwa"))
        }
        cell("🌐", "English / Swahili") {
            store.lang = if (store.lang == "sw") "en" else "sw"
            updateHint()
            if (fullUrl.isEmpty()) web.reload()
            toast(if (store.lang == "sw") "Lugha: Kiswahili" else "Language: English")
        }

        d.setContentView(root)
        d.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun showBlocked() {
        val l = BlockLog.top()
        if (l.isEmpty()) { toast(t("Nothing blocked yet", "Hakuna kilichozuiwa bado")); return }
        AlertDialog.Builder(this).setTitle("🚫 " + t("Blocked", "Zilizozuiwa") + " (${store.blocked})")
            .setItems(l.map { "${it.first}  ×${it.second}" }.toTypedArray(), null)
            .setPositiveButton(t("Close", "Funga"), null)
            .setNeutralButton(t("Clear list", "Futa orodha")) { _, _ ->
                BlockLog.clear(); store.resetBlocked(); store.blockLogJson = "{}"
                toast(t("Cleared", "Imefutwa"))
            }.show()
    }

    private fun pick(title: String, items: List<Pair<String, String>>) {
        if (items.isEmpty()) { toast(t("Nothing here yet", "Hakuna kitu bado")); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(items.map { it.first.take(40) + "\n" + it.second.take(50) }.toTypedArray()) { _, i ->
                web.loadUrl(items[i].second)
            }.show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- Lifecycle ----------------

    override fun onPause() {
        handler.removeCallbacks(poll)
        adView.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        adView.resume()
        handler.postDelayed(poll, 2500)
        // Home ikiwa tupu baada ya app kukaa nyuma, ipakie upya
        if (tabs.isNotEmpty() && fullUrl.isEmpty()) web.loadUrl(home)
    }

    override fun onStop() {
        store.blockLogJson = BlockLog.toJson()
        super.onStop()
    }

    override fun onDestroy() {
        adView.destroy()
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
