LIVE SCORES — PROXY YA RAHIM LUX GO (Cloudflare Worker, bure)

KWA NINI PROXY?
Ufunguo wa API ukiwekwa ndani ya APK, mtu yeyote anaweza kuutoa. Kwa hiyo app haizungumzi na
API-Football moja kwa moja: inazungumza na Worker yako, na ufunguo unakaa kwenye Worker (secret).
Worker pia inaweka cache, kwa hiyo requests za API zinapungua sana.

HATUA (zinawezekana kwa simu):
1. API-Football: jisajili api-sports.io (au dashboard.api-football.com), nakili API key.
2. Cloudflare: dash.cloudflare.com > Workers & Pages > Create > "Hello World" Worker > Edit code.
   Futa kila kitu, bandika yaliyomo yote ya backend/worker.js, bonyeza Deploy.
3. Worker > Settings > Variables and Secrets > Add:
      FOOTBALL_API_KEY = (ufunguo wako)           [aina: Secret]
   Hiari: APP_TOKEN, LEAGUES, TIMEZONE, LIVE_TTL, IDLE_TTL (angalia juu ya worker.js).
4. Fungua  https://JINA-LAKO.workers.dev/scores  kwenye browser. Unapaswa kuona JSON yenye "ok":true.
5. Kwenye Rahim Lux Go: menyu (⋮) > Settings > Live scores > Scores server URL,
   bandika  https://JINA-LAKO.workers.dev   (bila /scores). Kama uliweka APP_TOKEN, weka pia Access token.
   Hiari: weka SCORES_BASE_URL kama env var wakati wa build ili iwe chaguo-msingi.

QUOTA (API-Football):
- Free: maombi 100 kwa siku, na misimu inaweza kuwa na kikomo — jaribu na ufunguo wako kuona kama
  ligi/msimu unaoutaka unapatikana. Pro ($19): 7,500 kwa siku.
- Worker inaita API tu cache ikiisha: kila LIVE_TTL (chaguo-msingi 60s) kukiwa na mechi live,
  na kila IDLE_TTL (600s) hakuna mechi live. Kwa Free weka LIVE_TTL=300 ili quota idumu.
- App yenyewe inauliza proxy kila dakika 1 (kukiwa na mechi live) au dakika 10 (hakuna), na
  ukurasa wa Home tu ukiwa wazi. Hakuna maombi ya kila sekunde.

Hii ni taarifa za michezo tu: hakuna odds, betting wala utabiri.
