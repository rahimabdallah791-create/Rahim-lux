// Rahim Lux Go — Live Scores proxy (Cloudflare Worker)
// Data ya mpira kutoka API-Football (api-sports.io). Ufunguo wa API unakaa HAPA (secret), si ndani ya app.
//
// Environment variables / secrets (Worker > Settings > Variables and Secrets):
//   FOOTBALL_API_KEY  (secret, LAZIMA)  ufunguo wa API-Football
//   APP_TOKEN         (hiari)           ukiweka, app lazima itume token hiyo (Settings > Live scores > Access token)
//   LEAGUES           (hiari)           ligi unazotaka tu, mfano "39,140,135,78,61,2"  (id za API-Football)
//   TIMEZONE          (hiari)           chaguo-msingi "Africa/Dar_es_Salaam"
//   LIVE_TTL          (hiari)           sekunde za cache kukiwa na mechi live, chaguo-msingi 60
//   IDLE_TTL          (hiari)           sekunde za cache hakuna mechi live, chaguo-msingi 600
//
// Endpoint:  GET /scores?date=YYYY-MM-DD   (jana, leo au kesho tu)

const LIVE = new Set(["1H", "HT", "2H", "ET", "BT", "P", "LIVE", "INT"]);
const memo = new Map(); // cache ya muda mfupi ndani ya Worker (inapunguza requests za API)

function reply(obj, status, ttl) {
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": ttl ? "public, max-age=" + ttl : "no-store",
      "access-control-allow-origin": "*",
      "x-content-type-options": "nosniff",
    },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: { "access-control-allow-origin": "*", "access-control-allow-headers": "x-app-token" } });
    if (url.pathname !== "/scores") return reply({ ok: false, error: "not_found" }, 404);

    if (env.APP_TOKEN && request.headers.get("X-App-Token") !== env.APP_TOKEN) {
      return reply({ ok: false, error: "unauthorized", matches: [] }, 401);
    }
    if (!env.FOOTBALL_API_KEY) return reply({ ok: false, error: "not_configured", matches: [] }, 503);

    const tz = env.TIMEZONE || "Africa/Dar_es_Salaam";
    const today = new Intl.DateTimeFormat("en-CA", { timeZone: tz }).format(new Date());
    let date = url.searchParams.get("date") || today;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) date = today;
    const diffDays = Math.abs((Date.parse(date + "T00:00:00Z") - Date.parse(today + "T00:00:00Z")) / 86400000);
    if (!(diffDays <= 1)) date = today; // zuia matumizi mabaya ya quota

    const liveTtl = Math.max(15, parseInt(env.LIVE_TTL || "60", 10) || 60);
    const idleTtl = Math.max(60, parseInt(env.IDLE_TTL || "600", 10) || 600);

    const hit = memo.get(date);
    if (hit && hit.exp > Date.now()) {
      return reply(hit.body, 200, Math.max(1, Math.round((hit.exp - Date.now()) / 1000)));
    }

    try {
      const up = await fetch(
        "https://v3.football.api-sports.io/fixtures?date=" + date + "&timezone=" + encodeURIComponent(tz),
        { headers: { "x-apisports-key": env.FOOTBALL_API_KEY } }
      );
      if (!up.ok) throw new Error("upstream " + up.status);
      const data = await up.json();
      if (data.errors && Object.keys(data.errors).length) throw new Error("upstream errors");

      const allow = env.LEAGUES ? new Set(env.LEAGUES.split(",").map((s) => s.trim())) : null;
      const matches = (data.response || [])
        .filter((r) => !allow || allow.has(String(r.league && r.league.id)))
        .slice(0, 400)
        .map((r) => ({
          id: r.fixture.id,
          lg: r.league.name,
          co: r.league.country,
          h: r.teams.home.name,
          a: r.teams.away.name,
          hg: r.goals.home,
          ag: r.goals.away,
          st: r.fixture.status.short,
          min: r.fixture.status.elapsed,
          ko: r.fixture.date,
        }));
      const hasLive = matches.some((m) => LIVE.has(m.st));
      const body = { ok: true, updated: new Date().toISOString(), hasLive: hasLive, matches: matches };
      const ttl = hasLive ? liveTtl : idleTtl;
      memo.set(date, { body: body, exp: Date.now() + ttl * 1000 });
      return reply(body, 200, ttl);
    } catch (e) {
      if (hit) return reply(Object.assign({}, hit.body, { stale: true }), 200, 15); // toa data ya zamani badala ya kosa
      return reply({ ok: false, error: "upstream_error", matches: [] }, 502);
    }
  },
};
