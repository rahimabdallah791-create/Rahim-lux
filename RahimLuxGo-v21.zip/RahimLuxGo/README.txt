RAHIM LUX GO v21 - Android browser (Kotlin + WebView)
Mpya v21: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
