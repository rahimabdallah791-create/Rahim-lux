// Rahim Lux Go — standalone Weather Worker
// Deploy this file as a NEW Cloudflare Worker. Do NOT replace your Live Scores Worker.
// Required secret: OPENWEATHER_API_KEY
// Optional secret: APP_TOKEN
// Optional KV binding: STATE
// Optional variable: WEATHER_TTL (default 600 seconds)

const mem = new Map();
const reply = (obj, status, ttl) => new Response(JSON.stringify(obj), {
  status: status || 200,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": ttl ? "public, max-age=" + ttl : "no-store",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, OPTIONS",
    "access-control-allow-headers": "Content-Type, X-App-Token",
    "x-content-type-options": "nosniff",
  },
});
const kv = (env) => ({
  async get(k) {
    if (env.STATE) return env.STATE.get(k);
    const e = mem.get(k);
    return e && e.exp > Date.now() ? e.v : null;
  },
  async put(k, v, ttl) {
    const t = Math.max(60, ttl || 604800);
    if (env.STATE) return env.STATE.put(k, v, { expirationTtl: t });
    mem.set(k, { v, exp: Date.now() + t * 1000 });
  },
});
function ctEq(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
// ---------- Weather (OpenWeather) ----------
// Ufunguo: Secret OPENWEATHER_API_KEY (haumo ndani ya app). Eneo: ?q=Jina la mji, au (bila q) makadirio kutoka anwani ya mtandao (request.cf).
const wxMemo = new Map();
async function owm(env, path, params) {
  const qs = Object.keys(params).map((k) => k + "=" + encodeURIComponent(params[k])).join("&");
  const r = await fetch("https://api.openweathermap.org" + path + "?" + qs + "&appid=" + env.OPENWEATHER_API_KEY);
  if (!r.ok) throw new Error("owm " + r.status);
  return r.json();
}
async function geocode(env, st, q) {
  const key = "geo:" + q.toLowerCase();
  const hit = await st.get(key);
  if (hit) return JSON.parse(hit);
  const a = await owm(env, "/geo/1.0/direct", { q: q, limit: 1 });
  if (!Array.isArray(a) || !a.length) return null;
  const g = { name: a[0].name, country: a[0].country, lat: a[0].lat, lon: a[0].lon };
  await st.put(key, JSON.stringify(g), 2592000);
  return g;
}
async function getWeather(env, url, cf) {
  if (!env.OPENWEATHER_API_KEY) return { status: 503, body: { ok: false, error: "not_configured" } };
  const st = kv(env);
  let lat, lon, label = "", country = "";
  const q = (url.searchParams.get("q") || "").trim().slice(0, 60);
  try {
    if (q) {
      const g = await geocode(env, st, q);
      if (!g) return { status: 404, body: { ok: false, error: "city_not_found" } };
      lat = g.lat; lon = g.lon; label = g.name; country = g.country;
    } else if (cf && cf.latitude && cf.longitude) {
      lat = parseFloat(cf.latitude); lon = parseFloat(cf.longitude); label = cf.city || ""; country = cf.country || "";
    } else { lat = -6.79; lon = 39.21; label = "Dar es Salaam"; country = "TZ"; }
  } catch (e) { return { status: 502, body: { ok: false, error: String(e && e.message || e).includes("401") ? "invalid_api_key" : "geocode_failed" } }; }
  if (!isFinite(lat) || !isFinite(lon)) { lat = -6.79; lon = 39.21; }
  const key = "wx:" + lat.toFixed(1) + "," + lon.toFixed(1); // eneo la ~11km hushiriki cache (watumiaji wengi, maombi machache)
  const withLabel = (b) => Object.assign({}, b, { city: label || b.city, country: country || b.country });
  const ttl = Math.max(120, parseInt(env.WEATHER_TTL || "600", 10) || 600);
  let c = wxMemo.get(key);
  if (!c) { const raw = await st.get(key); if (raw) { try { c = JSON.parse(raw); wxMemo.set(key, c); } catch (e) { c = null; } } }
  if (c && c.exp > Date.now()) return { status: 200, body: withLabel(c.body), ttl: Math.max(1, Math.round((c.exp - Date.now()) / 1000)) };
  try {
    const [cur, fc] = await Promise.all([
      owm(env, "/data/2.5/weather", { lat: lat, lon: lon, units: "metric" }),
      owm(env, "/data/2.5/forecast", { lat: lat, lon: lon, units: "metric" }),
    ]);
    const tz = (fc.city && fc.city.timezone) || cur.timezone || 0;
    const w0 = (cur.weather && cur.weather[0]) || {};
    const wOf = (x) => (x.weather && x.weather[0]) || {};
    const list = fc.list || [];
    const hourly = list.slice(0, 8).map((x) => ({ ts: x.dt * 1000, t: Math.round(x.main.temp), id: wOf(x).id, icon: wOf(x).icon, pop: Math.round((x.pop || 0) * 100) }));
    const days = {}, order = [];
    for (const x of list) {
      const d = new Date((x.dt + tz) * 1000).toISOString().slice(0, 10);
      let e = days[d];
      if (!e) { e = days[d] = { min: 99, max: -99, ids: {} }; order.push(d); }
      e.min = Math.min(e.min, x.main.temp_min); e.max = Math.max(e.max, x.main.temp_max);
      const id = wOf(x).id; e.ids[id] = (e.ids[id] || 0) + 1;
    }
    const daily = order.slice(0, 5).map((d) => {
      const e = days[d]; let best = 0, bid = 0;
      for (const k in e.ids) if (e.ids[k] > best) { best = e.ids[k]; bid = +k; }
      return { d: d, min: Math.round(e.min), max: Math.round(e.max), id: bid };
    });
    const body = { ok: true, updated: new Date().toISOString(), city: cur.name || "", country: (cur.sys && cur.sys.country) || "",
      now: { t: Math.round(cur.main.temp), feels: Math.round(cur.main.feels_like), hum: cur.main.humidity,
        wind: Math.round(((cur.wind && cur.wind.speed) || 0) * 3.6), id: w0.id, icon: w0.icon },
      hourly: hourly, daily: daily };
    const entry = { body: body, exp: Date.now() + ttl * 1000 };
    wxMemo.set(key, entry);
    await st.put(key, JSON.stringify(entry), 10800);
    return { status: 200, body: withLabel(body), ttl: ttl };
  } catch (e) {
    if (c && Date.now() - Date.parse(c.body.updated) < 10800000) return { status: 200, body: Object.assign({}, withLabel(c.body), { stale: true }), ttl: 30 };
    return { status: 502, body: { ok: false, error: String(e && e.message || e).includes("401") ? "invalid_api_key" : "upstream_error" } };
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, {
      status: 204,
      headers: {
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET, OPTIONS",
        "access-control-allow-headers": "Content-Type, X-App-Token",
        "access-control-max-age": "86400",
      },
    });
    if (url.pathname === "/" || url.pathname === "/health") {
      return reply({ ok: true, service: "Rahim Lux Go Weather", weatherConfigured: !!env.OPENWEATHER_API_KEY,
        tokenProtection: !!env.APP_TOKEN, cacheBinding: !!env.STATE, endpoint: "/weather" });
    }
    if (url.pathname !== "/weather" || request.method !== "GET") return reply({ ok: false, error: "not_found" }, 404);
    if (env.APP_TOKEN && !ctEq(request.headers.get("X-App-Token") || "", env.APP_TOKEN)) {
      return reply({ ok: false, error: "unauthorized" }, 401);
    }
    const r = await getWeather(env, url, request.cf);
    return reply(r.body, r.status, r.ttl);
  },
};
