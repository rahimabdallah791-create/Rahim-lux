RAHIM LUX GO v28 - Android browser (Kotlin + WebView)
Mpya v28: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.


WEATHER AS A SEPARATE WORKER
- Deploy backend/weather-worker.js as a NEW Cloudflare Worker; do not replace backend/worker.js or your current Live Scores Worker.
- Add OPENWEATHER_API_KEY as a secret on the new Weather Worker.
- Optionally add APP_TOKEN as a secret; if set, enter the same value in the app's Weather access token setting.
- In app Settings > Weather, set Weather server URL to the new Worker URL. Live Scores keeps using its existing Scores server URL.
- Optional: bind a KV namespace named STATE for weather/geocoding cache.
