package com.rahimlux.go

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** FCM: token, topics na mawasiliano na seva yako. Hakuna siri ndani ya app (Firebase config ya mteja si siri). */
object Push {
    val EVENTS = setOf("goal", "start", "ht", "ft", "et", "pen")

    /** Firebase imewekwa kwenye build hii? (google-services.json ipo) */
    fun configured(ctx: Context): Boolean = try {
        FirebaseApp.getApps(ctx).isNotEmpty()
    } catch (e: Throwable) { false }

    /** Topics zinazotakiwa kulingana na mipangilio na mechi unazozifuata. */
    fun desiredTopics(s: Store): Set<String> {
        val t = mutableSetOf("all_users")
        if (s.nAnnounce) t.add("announcements")
        if (s.nFootball) {
            t.add("football")
            if (s.nGoals) t.add("football_goals")
            for ((id, f) in s.follows()) {
                f.events.filter { it in EVENTS }.forEach { e -> t.add("m${id}_$e") }
                t.add("m${id}_status")
            }
        }
        if (s.nNews) {
            if (s.nNewsBreaking) t.add("news")
            if (s.nNewsTz) t.add("news_tanzania")
            if (s.nNewsSports) t.add("news_sports")
            if (s.nNewsFootball) t.add("news_football")
            if (s.nNewsTech) t.add("news_technology")
        }
        return t
    }

    /** Linganisha topics ulizo nazo na zinazotakiwa; jiandikishe/jiondoe kwa tofauti tu. */
    fun syncTopics(ctx: Context) {
        if (!configured(ctx)) return
        try {
            val s = Store(ctx)
            val now = System.currentTimeMillis()
            val weekly = now - s.fcmTopicsAt > 7L * 24 * 3600 * 1000 // FCM inapendekeza kujisajili upya mara kwa mara
            val want = if (s.nAll) desiredTopics(s) else emptySet()
            val have = if (weekly) emptySet() else s.fcmTopics
            val fm = FirebaseMessaging.getInstance()
            (have - want).forEach { fm.unsubscribeFromTopic(it) }
            s.fcmTopics = want
            if (weekly) s.fcmTopicsAt = now
            (want - have).forEach { t ->
                // Ikishindwa (mtandao/token), ondoa kwenye orodha ili jaribio lijalo lijaribu tena
                fm.subscribeToTopic(t).addOnCompleteListener { task ->
                    if (!task.isSuccessful) {
                        val st = Store(ctx)
                        st.fcmTopics = st.fcmTopics - t
                    }
                }
            }
        } catch (e: Exception) { }
    }

    /** Jisajili upya kwenye topics zote (kurekebisha usajili uliopotea). */
    fun resubscribe(ctx: Context) {
        Store(ctx).fcmTopics = emptySet()
        syncTopics(ctx)
    }

    /** Pata token (inatokea mara chache) na uisajili kwenye seva ikibadilika. */
    fun refreshToken(ctx: Context) {
        if (!configured(ctx)) return
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                val tok = if (task.isSuccessful) task.result else null
                if (!tok.isNullOrEmpty()) {
                    val s = Store(ctx)
                    if (tok != s.fcmToken) {
                        s.fcmToken = tok
                        register(ctx, tok)
                    }
                }
            }
        } catch (e: Exception) { }
    }

    /** Seva inahifadhi hash tu (si token yenyewe). Ikifeli, app inaendelea kufanya kazi kupitia topics. */
    fun register(ctx: Context, token: String) {
        val s = Store(ctx)
        Thread {
            call(ctx, "/device", JSONObject().put("token", token).put("lang", s.lang))
        }.start()
    }

    /** Futa usajili wa push: token, topics, na rekodi ya seva. Kisha pata token mpya. */
    fun reset(ctx: Context, done: (Boolean) -> Unit) {
        if (!configured(ctx)) { done(false); return }
        val s = Store(ctx)
        val old = s.fcmToken
        Thread {
            try {
                if (old.isNotEmpty()) call(ctx, "/device/delete", JSONObject().put("token", old))
            } catch (e: Exception) { }
        }.start()
        try {
            val fm = FirebaseMessaging.getInstance()
            s.fcmTopics.forEach { fm.unsubscribeFromTopic(it) }
            s.fcmTopics = emptySet()
            s.fcmToken = ""
            fm.deleteToken().addOnCompleteListener { t1 ->
                refreshToken(ctx)
                syncTopics(ctx)
                done(t1.isSuccessful)
            }
        } catch (e: Exception) { done(false) }
    }

    /** Tuma push ya majaribio kutoka kwenye seva yako hadi simu hii. Inarudisha msimbo wa HTTP na kosa halisi. */
    fun sendTest(ctx: Context, done: (ok: Boolean, code: Int, detail: String) -> Unit) {
        val s = Store(ctx)
        if (!configured(ctx)) { done(false, 0, "no_firebase"); return }
        val tok = s.fcmToken
        if (tok.isEmpty()) { done(false, 0, "no_token"); return }
        if (s.scoresUrl.isEmpty()) { done(false, 0, "no_server"); return }
        Thread {
            val t0 = System.currentTimeMillis()
            val r = call(ctx, "/test", JSONObject().put("token", tok))
            val ok = r.code in 200..299
            done(ok, r.code, if (ok) timingText(r, System.currentTimeMillis() - t0) else errorText(r))
        }.start()
    }

    /** Muda: app -> seva -> FCM (ms). Inasaidia kujua ucheleweshaji uko wapi. */
    private fun timingText(r: CallResult, roundTrip: Long): String = try {
        val ms = JSONObject(r.text).optJSONObject("ms")
        "app→server→FCM $roundTrip ms" + (if (ms != null) " (server ${ms.optLong("total")} ms: OAuth ${ms.optLong("oauth")}, FCM ${ms.optLong("send")})" else "")
    } catch (e: Exception) { "app→server→FCM $roundTrip ms" }

    class CallResult(val code: Int, val text: String)

    private fun errorText(r: CallResult): String = try {
        JSONObject(r.text).optString("error", r.text)
    } catch (e: Exception) { r.text }

    /** POST JSON kwenda kwenye seva (URL ile ile ya scores). code -1 = hakuna jibu, -2 = anwani si https. */
    private fun call(ctx: Context, path: String, body: JSONObject): CallResult {
        val s = Store(ctx)
        val base = s.scoresUrl.trim().trimEnd('/')
        if (!base.startsWith("https://")) return CallResult(-2, "bad_url")
        var c: HttpURLConnection? = null
        return try {
            c = URL(base + path).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            if (s.scoresToken.isNotEmpty()) c.setRequestProperty("X-App-Token", s.scoresToken)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            CallResult(code, text.take(500))
        } catch (e: Exception) {
            CallResult(-1, (e.javaClass.simpleName + ": " + (e.message ?: "")).take(200))
        } finally {
            c?.disconnect()
        }
    }
}
