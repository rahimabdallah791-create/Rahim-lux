package com.rahimlux.go

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Mipangilio ya arifa: kuzima/kuwasha kwa kategoria, mechi unazofuata, majaribio, na hali ya push. */
class NotificationSettingsActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var list: LinearLayout
    private val perm = PermHelper(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)
        Notif.ensureChannels(this, store)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0B0D"))
        root.addView(ui.header(ui.t("Notification settings", "Mipangilio ya arifa")))
        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(28))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) build()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun sync() = Push.syncTopics(this)

    private fun onMaster(on: Boolean) {
        if (on) {
            perm.ensure { ok ->
                store.nAll = ok
                if (ok) { Notif.ensureChannels(this, store); Push.refreshToken(this) }
                sync()
                build()
            }
        } else {
            store.nAll = false
            sync()
            build()
        }
    }

    private fun systemSettings() {
        try {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun openBattery() {
        try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) { systemSettings() }
    }

    private fun channelSettings() {
        val ids = Notif.CHANNELS
        AlertDialog.Builder(this).setTitle(ui.t("Sound & vibration", "Sauti na mtetemo"))
            .setItems(ids.map { Notif.channelName(store, it) }.toTypedArray()) { _, i ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            .putExtra(Settings.EXTRA_CHANNEL_ID, ids[i])
                    )
                } catch (e: Exception) { systemSettings() }
            }.show()
    }

    private fun followedDialog() {
        val f = store.follows().entries.toList()
        if (f.isEmpty()) { toast(ui.t("You are not following any match", "Hujafuata mechi yoyote")); return }
        AlertDialog.Builder(this)
            .setTitle(ui.t("Tap a match to stop following", "Gusa mechi ili uache kuifuata"))
            .setItems(f.map { it.value.label.ifEmpty { it.key } }.toTypedArray()) { _, i ->
                store.unfollow(f[i].key)
                sync()
                build()
            }.show()
    }

    private fun testServer() {
        Push.sendTest(this) { ok, code, detail ->
            runOnUiThread { showTestResult(ok, code, detail) }
        }
    }

    /** Maelezo yanayoeleweka ya kosa halisi la seva (badala ya ujumbe wa jumla). */
    private fun explain(ok: Boolean, code: Int, d: String): String {
        val l = d.lowercase()
        return when {
            ok -> ui.t("Sent to Firebase. The notification should appear within a few seconds. If it comes much later, the delay is on the phone/Google side: allow Rahim Lux Go to run in the background (Tools > Battery optimization).",
                "Imetumwa Firebase. Arifa inapaswa kuonekana baada ya sekunde chache. Ikichelewa sana, ucheleweshaji uko kwenye simu/Google: ruhusu Rahim Lux Go ifanye kazi nyuma (Zana > Uboreshaji wa betri).")
            d == "no_firebase" -> ui.t("Firebase is not set up in this build.", "Firebase haijawekwa kwenye build hii.")
            d == "no_token" -> ui.t("Push token not ready yet. Try again in a minute, or use Reset push registration.", "Token ya push bado. Jaribu tena baada ya dakika, au tumia Reset push registration.")
            d == "no_server" -> ui.t("Set the server URL in Settings > Live scores.", "Weka anwani ya seva kwenye Settings > Live scores.")
            code == -2 -> ui.t("The server URL must start with https://", "Anwani ya seva lazima ianze na https://")
            code == -1 -> ui.t("Could not reach the server. Check your internet and the server URL.", "Seva haipatikani. Angalia intaneti na anwani ya seva.")
            code == 404 -> ui.t("The server does not have /test: your Worker still has the OLD code. Paste the new worker.js and press Deploy.", "Seva haina /test: Worker yako bado ina code ya ZAMANI. Bandika worker.js mpya na ubonyeze Deploy.")
            code == 401 -> ui.t("Unauthorized: the Access token in Settings does not match APP_TOKEN on the server (or remove APP_TOKEN from the Worker).", "Imekataliwa: Access token ya Settings haifanani na APP_TOKEN ya seva (au futa APP_TOKEN kwenye Worker).")
            code == 429 -> ui.t("Too many tests. Wait one minute and try again.", "Majaribio mengi. Subiri dakika moja na ujaribu tena.")
            code == 400 -> ui.t("The server rejected the device token. Try Reset push registration.", "Seva imekataa token ya simu. Jaribu Reset push registration.")
            l.contains("fcm_not_configured") -> ui.t("The secret FCM_SERVICE_ACCOUNT is missing on the Worker.", "Secret FCM_SERVICE_ACCOUNT haipo kwenye Worker.")
            l.contains("unregistered") || l.contains("requested entity was not found") ->
                ui.t("Firebase says this device token is not registered. Try Reset push registration.", "Firebase inasema token ya simu hii haijasajiliwa. Jaribu Reset push registration.")
            l.contains("oauth") || l.contains("invalid_grant") || l.contains("unauthenticated") || l.contains("invalid_client") ->
                ui.t("The server could not sign in to Firebase. Check that FCM_SERVICE_ACCOUNT contains the whole service account JSON.", "Seva imeshindwa kuingia Firebase. Hakikisha FCM_SERVICE_ACCOUNT ina JSON nzima ya service account.")
            l.contains("permission") || l.contains("not been used") || l.contains("disabled") || l.contains("forbidden") ->
                ui.t("Firebase refused the request. Enable 'Firebase Cloud Messaging API (V1)' and use a service account from the same Firebase project.", "Firebase imekataa. Washa 'Firebase Cloud Messaging API (V1)' na utumie service account ya project ile ile ya Firebase.")
            l.contains("invalid_argument") -> ui.t("Firebase rejected the message format. Send these details to the developer.", "Firebase imekataa muundo wa ujumbe. Tuma maelezo haya kwa msanidi.")
            code == 502 || code == 503 -> ui.t("The server could not send through Firebase.", "Seva imeshindwa kutuma kupitia Firebase.")
            else -> ui.t("The server could not send the test push.", "Seva imeshindwa kutuma push ya majaribio.")
        }
    }

    private fun showTestResult(ok: Boolean, code: Int, detail: String) {
        val msg = explain(ok, code, detail)
        val tech = if (code != 0) "HTTP $code" + (if (detail.isNotEmpty()) " · $detail" else "") else detail
        val full = if (tech.isEmpty()) msg else msg + "\n\n" + ui.t("Details: ", "Maelezo: ") + tech
        val b = AlertDialog.Builder(this)
            .setTitle(if (ok) ui.t("Test push sent", "Push imetumwa") else ui.t("Test push failed", "Push imeshindwa"))
            .setMessage(full)
            .setPositiveButton("OK", null)
        if (!ok && tech.isNotEmpty()) {
            b.setNeutralButton(ui.t("Copy details", "Nakili maelezo")) { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("push-test", tech))
                toast(ui.t("Copied", "Imenakiliwa"))
            }
        }
        b.show()
    }

    private fun build() {
        list.removeAllViews()
        val allowed = perm.granted()
        val pushOk = Push.configured(this)

        // ---- Hali
        ui.section(list, ui.t("Status", "Hali"))
        var c = ui.card()
        ui.switchRow(
            c, ui.t("Enable notifications", "Washa arifa"),
            ui.t("Master switch for all Rahim Lux Go notifications", "Kitufe kikuu cha arifa zote za Rahim Lux Go"),
            store.nAll && allowed
        ) { onMaster(it) }
        ui.row(
            c, ui.t("System permission", "Ruhusa ya mfumo"),
            if (allowed) ui.t("Allowed", "Imeruhusiwa") else ui.t("Blocked. Tap to fix.", "Imezuiwa. Bonyeza kurekebisha."),
            ui.arrow()
        ) { if (allowed) systemSettings() else perm.ensure { build() } }
        ui.row(
            c, "Push (FCM)",
            when {
                !pushOk -> ui.t("Not set up in this build (Firebase config missing)", "Haijawekwa kwenye build hii (Firebase config haipo)")
                store.fcmToken.isEmpty() -> ui.t("Connecting…", "Inaunganisha…")
                else -> ui.t("Connected", "Imeunganishwa") + " · " + store.fcmTopics.size + " topics"
            },
            null, null
        )
        ui.addCard(list, c)

        // ---- Football
        ui.section(list, ui.t("Football", "Mpira"))
        c = ui.card()
        ui.switchRow(c, ui.t("Football notifications", "Arifa za mpira"),
            ui.t("Match start, half-time, full-time and results", "Mechi kuanza, mapumziko, mwisho na matokeo"), store.nFootball) {
            store.nFootball = it; sync()
        }
        ui.switchRow(c, ui.t("Football goals", "Magoli"), ui.t("Goal alerts", "Arifa za magoli"), store.nGoals) {
            store.nGoals = it; sync()
        }
        ui.row(c, ui.t("Followed matches", "Mechi unazofuata"), store.follows().size.toString(), ui.arrow()) { followedDialog() }
        ui.addCard(list, c)

        // ---- News
        ui.section(list, ui.t("News", "Habari"))
        c = ui.card()
        ui.switchRow(c, ui.t("News notifications", "Arifa za habari"), null, store.nNews) { store.nNews = it; sync() }
        ui.switchRow(c, ui.t("Breaking news", "Habari za haraka"), null, store.nNewsBreaking) { store.nNewsBreaking = it; sync() }
        ui.switchRow(c, "Tanzania", null, store.nNewsTz) { store.nNewsTz = it; sync() }
        ui.switchRow(c, ui.t("Sports", "Michezo"), null, store.nNewsSports) { store.nNewsSports = it; sync() }
        ui.switchRow(c, ui.t("Football news", "Habari za mpira"), null, store.nNewsFootball) { store.nNewsFootball = it; sync() }
        ui.switchRow(c, ui.t("Technology", "Teknolojia"), null, store.nNewsTech) { store.nNewsTech = it; sync() }
        ui.addCard(list, c)

        // ---- Mengine
        ui.section(list, ui.t("Other", "Mengineyo"))
        c = ui.card()
        ui.switchRow(c, ui.t("Download notifications", "Arifa za vipakuliwa"),
            ui.t("Progress and completion (shown by Android)", "Progress na kukamilika (zinaonyeshwa na Android)"), store.nDownloads) { store.nDownloads = it }
        ui.switchRow(c, ui.t("Announcements", "Matangazo ya app"),
            ui.t("New features, updates, maintenance", "Vipengele vipya, masasisho, matengenezo"), store.nAnnounce) { store.nAnnounce = it; sync() }
        ui.switchRow(c, ui.t("Account & security", "Akaunti na usalama"),
            ui.t("Reserved. Rahim Lux Go has no accounts yet.", "Imehifadhiwa. Rahim Lux Go haina akaunti bado."), store.nSecurity) { store.nSecurity = it }
        ui.addCard(list, c)

        // ---- Zana
        ui.section(list, ui.t("Tools", "Zana"))
        c = ui.card()
        ui.row(c, ui.t("Notification center", "Kituo cha arifa"),
            ui.t("Unread: ", "Hazijasomwa: ") + Notif.unread(store), ui.arrow()) {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }
        ui.row(c, ui.t("Sound & vibration", "Sauti na mtetemo"), ui.t("Per-channel settings in Android", "Mipangilio ya kila channel kwenye Android"), ui.arrow()) { channelSettings() }
        ui.row(c, ui.t("Send test notification", "Tuma arifa ya majaribio"), ui.t("On this phone", "Kwenye simu hii"), ui.arrow()) {
            perm.ensure { ok -> if (ok) Notif.test(this) else toast(ui.t("Allow notifications first", "Ruhusu arifa kwanza")) }
        }
        ui.row(c, ui.t("Send test push", "Tuma push ya majaribio"), ui.t("Through your server (checks FCM end to end)", "Kupitia seva yako (inajaribu FCM yote)"), ui.arrow()) { testServer() }
        ui.row(c, ui.t("Refresh subscriptions", "Sasisha usajili wa topics"),
            ui.t("Re-subscribe to football and news topics", "Jisajili upya kwenye topics za mpira na habari"), ui.arrow()) {
            Push.resubscribe(this)
            toast(ui.t("Subscribed again", "Umejisajili upya"))
            build()
        }
        ui.row(c, ui.t("Battery optimization", "Uboreshaji wa betri"),
            ui.t("Allow background running (fixes delayed alerts on some phones)", "Ruhusu kufanya kazi nyuma (inarekebisha arifa zinazochelewa kwenye simu fulani)"), ui.arrow()) { openBattery() }
        ui.row(c, ui.t("Reset push registration", "Weka upya usajili wa push"), ui.t("Deletes the token and subscriptions", "Inafuta token na usajili"), ui.arrow()) {
            AlertDialog.Builder(this)
                .setTitle(ui.t("Reset push registration?", "Weka upya usajili wa push?"))
                .setPositiveButton(ui.t("Reset", "Weka upya")) { _, _ ->
                    Push.reset(this) { ok -> runOnUiThread { toast(if (ok) ui.t("Done", "Imekamilika") else ui.t("Not available", "Haipatikani")); build() } }
                }
                .setNegativeButton(ui.t("Cancel", "Ghairi"), null).show()
        }
        ui.addCard(list, c)
    }
}
