package com.rahimlux.go

/** JavaScript ya sehemu ya LIVE SCORES kwenye Home. Data inaingia kupitia textContent (si innerHTML). */
object ScoresJs {
    const val CODE = """
function lsEl(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined&&x!==null)e.textContent=x;return e}
function lsKind(s){if('1H,2H,HT,ET,BT,P,LIVE,INT'.split(',').indexOf(s)>=0)return 'live';if('FT,AET,PEN,AWD,WO,CANC,ABD'.split(',').indexOf(s)>=0)return 'fin';return 'up'}
function lsRank(m){var k=['Premier League','La Liga','Serie A','Bundesliga','Ligue 1','Champions League','Europa','World Cup','AFCON','Africa','CAF','NBC','Tanzania'];var n=m.lg||'';for(var i=0;i<k.length;i++){if(n.indexOf(k[i])>=0)return i}return 99}
function lsTime(ko){var d=new Date(ko);if(isNaN(d.getTime()))return '';var h=d.getHours(),mi=d.getMinutes();return (h<10?'0':'')+h+':'+(mi<10?'0':'')+mi}
function lsAge(){var t0=SC.srv>0?SC.srv:SC.at;return t0>0?(Date.now()-t0)/60000:0}
function lsTab(k){SC.tab=k;lsRender()}
function lsRender(){
 var box=document.getElementById('ls');if(!box||!SC.cfg)return;
 var cnt={live:0,up:0,fin:0},list=[],i,m,k;
 for(i=0;i<SC.m.length;i++){m=SC.m[i];k=lsKind(m.st);cnt[k]++;if(k===SC.tab)list.push(m)}
 var tabs=document.querySelectorAll('.stab');
 for(i=0;i<tabs.length;i++){k=tabs[i].getAttribute('data-t');tabs[i].className='stab'+(k===SC.tab?' on':'');tabs[i].textContent=SC.i[k]+' '+cnt[k]}
 var u=document.getElementById('lsu');
 if(u){var s='';var t0=SC.srv>0?SC.srv:SC.at;if(t0>0){var d=new Date(t0);var h=d.getHours(),mi=d.getMinutes();s=' \u00b7 '+SC.i.upd+(h<10?'0':'')+h+':'+(mi<10?'0':'')+mi;if(SC.err)s+=' \u00b7 '+SC.i.off;if(SC.stale||(cnt.live>0&&lsAge()>12))s+=' \u00b7 \u26a0 '+SC.i.late}u.textContent=s}
 list.sort(function(a,b){var d=lsRank(a)-lsRank(b);if(d)return d;return a.ko<b.ko?-1:(a.ko>b.ko?1:0)});
 box.innerHTML='';
 if(!list.length){var msg=(SC.m.length===0&&SC.err)?SC.i.fail:(SC.tab==='live'?SC.i.noLive:(SC.tab==='up'?SC.i.noUp:SC.i.noFin));box.appendChild(lsEl('div','lsempty',msg));return}
 for(i=0;i<list.length&&i<40;i++){
  m=list[i];var c=lsEl('div','mc');c.setAttribute('data-id',m.id);c.onclick=function(){location.href='rlg://match/'+this.getAttribute('data-id')};c.appendChild(lsEl('div','ml',((SC.f||[]).indexOf(String(m.id))>=0?'\u2605 ':'')+(m.lg||'')));
  var r1=lsEl('div','mr');r1.appendChild(lsEl('span','mt',m.h));r1.appendChild(lsEl('b','',(m.hg===null||m.hg===undefined)?'-':m.hg));c.appendChild(r1);
  var r2=lsEl('div','mr');r2.appendChild(lsEl('span','mt',m.a));r2.appendChild(lsEl('b','',(m.ag===null||m.ag===undefined)?'-':m.ag));c.appendChild(r2);
  var kk=lsKind(m.st),txt;
  if(kk==='live'){var age=lsAge();if(m.st==='HT'){txt='HT'}else if(age>25){txt='\u25cf '+SC.i.late}else if(m.min!==null&&m.min!==undefined){var mm=m.min,cap=(m.st==='1H')?45:((m.st==='2H')?90:120);if(m.st==='1H'||m.st==='2H'||m.st==='ET'){mm=Math.min(cap,m.min+Math.floor(age))}txt='\u25cf '+(age>1.5?'~':'')+mm+"'"}else{txt='\u25cf LIVE'}}
  else if(kk==='fin'){txt=m.st}
  else{txt=(m.st==='NS'||m.st==='TBD')?lsTime(m.ko):m.st}
  c.appendChild(lsEl('div','mb'+(kk==='live'?' live':''),txt));box.appendChild(c)}
}
window.setScores=function(p){SC.m=p.m||[];SC.at=p.at||0;SC.err=p.err||'';if(p.f)SC.f=p.f;if(p.srv)SC.srv=p.srv;SC.stale=!!p.stale;lsRender()};
setInterval(lsRender,30000);
lsRender();
"""
}
