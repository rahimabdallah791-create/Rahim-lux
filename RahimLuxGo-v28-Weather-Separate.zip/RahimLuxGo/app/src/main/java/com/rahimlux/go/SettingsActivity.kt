package com.rahimlux.go

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Skrini ya Settings: mipangilio yote mahali pamoja + About. */
class SettingsActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var list: LinearLayout
    private val gold = Color.parseColor("#FFB300")

    private fun t(en: String, sw: String) = if (store.lang == "sw") sw else en
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        setResult(RESULT_OK)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0B0D"))

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(6), dp(10), dp(16), dp(10))
        val back = TextView(this)
        back.text = "←"; back.textSize = 24f; back.setTextColor(Color.WHITE)
        back.setPadding(dp(14), dp(6), dp(14), dp(6))
        back.setOnClickListener { finish() }
        val title = TextView(this)
        title.text = t("Settings", "Mipangilio")
        title.textSize = 20f; title.setTextColor(Color.WHITE); title.setTypeface(null, Typeface.BOLD)
        head.addView(back)
        head.addView(title)
        root.addView(head)

        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(16), 0, dp(16), dp(28))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) build()
    }

    // ---------------- Yaliyomo ----------------

    private fun build() {
        list.removeAllViews()

        section(t("General", "Jumla"))
        var c = card()
        choiceRow(c, t("Language", "Lugha"), listOf("en" to "English", "sw" to "Kiswahili"), { store.lang }) {
            store.lang = it; recreate()
        }
        choiceRow(c, t("Voice search language", "Lugha ya voice search"), listOf("sw" to "Kiswahili", "en" to "English"), { store.voiceLang }) {
            store.voiceLang = it
        }
        choiceRow(c, t("Search engine", "Injini ya kutafuta"),
            listOf("google" to "Google", "ddg" to "DuckDuckGo", "bing" to "Bing", "yahoo" to "Yahoo"), { store.engine }) {
            store.engine = it
        }
        row(c, t("Set as default browser", "Weka kama kivinjari chaguomsingi"), null, arrow()) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
            catch (e: Exception) { toast(t("Open Settings > Apps > Default apps", "Fungua Settings > Apps > Default apps")) }
        }
        addCard(c)

        section(t("Privacy & security", "Faragha na usalama"))
        c = card()
        switchRow(c, "Ad-block", t("Block ads and trackers on websites", "Zuia matangazo na trackers kwenye tovuti"),
            { store.adblock }) { store.adblock = it }
        switchRow(c, t("Third-party cookies", "Cookies za third-party"),
            t("Needed for many logins. Turn off for more privacy.", "Zinahitajika na login nyingi. Zima kwa faragha zaidi."),
            { store.thirdCookies }) { store.thirdCookies = it }
        row(c, t("Clear browsing data", "Futa data ya kuvinjari"),
            t("History, searches, cookies and cache", "History, utafutaji, cookies na cache"), arrow()) { confirmClear() }
        addCard(c)

        section(t("Appearance & data", "Muonekano na data"))
        c = card()
        switchRow(c, t("Dark mode for websites", "Dark mode kwa tovuti"),
            t("Makes light websites dark", "Inafanya tovuti nyeupe ziwe nyeusi"), { store.darkWeb }) { store.darkWeb = it }
        switchRow(c, "Desktop site", t("Request the desktop version of websites", "Omba toleo la kompyuta la tovuti"),
            { store.desktop }) { store.desktop = it }
        switchRow(c, "Data saver", t("Block images and heavy video to save data", "Zuia picha na video nzito kuokoa bando"),
            { store.dataSaver }) { store.dataSaver = it }
        addCard(c)

        section(t("Downloads", "Vipakuliwa"))
        c = card()
        row(c, t("Downloads", "Vipakuliwa"), t("See and open your downloaded files", "Tazama na ufungue faili ulizopakua"), arrow()) {
            startActivity(Intent(this, DownloadsActivity::class.java))
        }
        addCard(c)

        section(t("Notifications", "Arifa"))
        c = card()
        row(c, t("Notification settings", "Mipangilio ya arifa"),
            t("Football, news, announcements", "Mpira, habari, matangazo"), arrow()) {
            startActivity(Intent(this, NotificationSettingsActivity::class.java))
        }
        row(c, t("Notification center", "Kituo cha arifa"),
            t("Unread: ", "Hazijasomwa: ") + Notif.unread(store), arrow()) {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }
        addCard(c)

        section(t("Weather", "Hali ya hewa"))
        c = card()
        switchRow(c, t("Show on Home", "Onyesha kwenye Home"),
            t("Current weather and forecast", "Hali ya hewa ya sasa na utabiri"), { store.weatherOn }) { store.weatherOn = it }
        row(c, t("Location", "Eneo"),
            store.weatherCity.ifEmpty { t("Auto (approximate, from your network)", "Otomatiki (makadirio, kutoka mtandao wako)") }, arrow()) {
            inputDialog(t("City (leave empty for Auto)", "Mji (acha tupu kwa Otomatiki)"), store.weatherCity, "Arusha") { v ->
                store.weatherCity = v.take(60)
                store.weatherJson = "{}"
                store.weatherAtMs = 0L
                build()
            }
        }
        row(c, t("Weather server URL", "Anwani ya seva ya hali ya hewa"),
            store.weatherUrl.ifEmpty { t("Not set", "Haijawekwa") }, arrow()) {
            inputDialog(t("Weather server URL", "Anwani ya seva ya hali ya hewa"), store.weatherUrl, "https://your-weather-worker.workers.dev") { v ->
                when {
                    v.isEmpty() -> { store.weatherUrl = ""; build() }
                    LinkParser.safeUrl(v)?.startsWith("https://", ignoreCase = true) == true -> {
                        store.weatherUrl = v.trim().trimEnd('/'); store.weatherJson = "{}"; store.weatherAtMs = 0L; build()
                    }
                    else -> toast(t("Enter a valid https:// address", "Weka anwani sahihi ya https://"))
                }
            }
        }
        row(c, t("Weather access token (optional)", "Token ya hali ya hewa (hiari)"),
            if (store.weatherToken.isEmpty()) t("Not set", "Haijawekwa") else "••••••••", arrow()) {
            inputDialog(t("Weather access token (optional)", "Token ya hali ya hewa (hiari)"), store.weatherToken, "") { v ->
                store.weatherToken = v.take(200); build()
            }
        }
        row(c, t("Weather server setup", "Jinsi ya kuweka seva ya hali ya hewa"), null, arrow()) { showWeatherHelp() }
        addCard(c)

        section(t("Live scores", "Live scores"))
        c = card()
        switchRow(c, t("Show on Home", "Onyesha kwenye Home"),
            t("Football scores (information only)", "Matokeo ya mpira (taarifa tu)"),
            { store.scoresOn }) { store.scoresOn = it }
        row(c, t("Scores server URL", "Anwani ya seva ya scores"),
            store.scoresUrl.ifEmpty { t("Not set", "Haijawekwa") }, arrow()) {
            inputDialog(t("Scores server URL", "Anwani ya seva ya scores"), store.scoresUrl, "https://your-worker.workers.dev") { v ->
                when {
                    v.isEmpty() -> { store.scoresUrl = ""; build() }
                    LinkParser.safeUrl(v)?.startsWith("https://", ignoreCase = true) == true -> {
                        store.scoresUrl = v.trim().trimEnd('/'); build()
                    }
                    else -> toast(t("Enter a valid https:// address", "Weka anwani sahihi ya https://"))
                }
            }
        }
        row(c, t("Access token (optional)", "Token ya ufikiaji (hiari)"),
            if (store.scoresToken.isEmpty()) t("Not set", "Haijawekwa") else "••••••••", arrow()) {
            inputDialog(t("Access token (optional)", "Token ya ufikiaji (hiari)"), store.scoresToken, "") { v ->
                store.scoresToken = v.take(200); build()
            }
        }
        row(c, t("How to set up", "Jinsi ya kuweka"), null, arrow()) { showScoresHelp() }
        addCard(c)

        section("About")
        c = card()
        row(c, "Rahim Lux Go", t("Version ", "Toleo ") + versionName(), null, null)
        row(c, t("Privacy & data use", "Faragha na matumizi ya data"), null, arrow()) { showPrivacy() }
        row(c, t("Ads", "Matangazo"), t("Ads are provided by Google AdMob", "Matangazo yanatolewa na Google AdMob"), null, null)
        addCard(c)
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) { "" }

    private fun inputDialog(title: String, current: String, hint: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.setText(current)
        et.hint = hint
        et.setSingleLine(true)
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(Color.parseColor("#8A8A94"))
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton(t("Cancel", "Ghairi"), null)
            .show()
    }

    private fun showWeatherHelp() {
        AlertDialog.Builder(this)
            .setTitle(t("Weather server setup", "Kuweka seva ya hali ya hewa"))
            .setMessage(
                t(
                    "Weather now uses its own separate Cloudflare Worker; your Live Scores Worker does not need to be changed.\n\n" +
                        "1. Create a new Cloudflare Worker for Weather and deploy backend/weather-worker.js from the project.\n" +
                        "2. Add OPENWEATHER_API_KEY as a Worker secret.\n" +
                        "3. Optionally add APP_TOKEN as a secret if you want token protection.\n" +
                        "4. Paste the new https://...workers.dev address in Weather server URL. If you set APP_TOKEN, enter the same value in Weather access token.\n\n" +
                        "The Weather Worker can use a KV namespace named STATE for caching, but it can also run without it.",
                    "Hali ya hewa sasa inatumia Cloudflare Worker yake tofauti; Worker yako ya Live Scores haihitaji kubadilishwa.\n\n" +
                        "1. Tengeneza Worker mpya ya hali ya hewa na uweke backend/weather-worker.js kutoka kwenye project.\n" +
                        "2. Ongeza OPENWEATHER_API_KEY kama Worker secret.\n" +
                        "3. Kwa hiari ongeza APP_TOKEN kama secret kwa ulinzi wa token.\n" +
                        "4. Bandika anwani mpya ya https://...workers.dev kwenye Weather server URL. Ukiweka APP_TOKEN, weka thamani hiyo hiyo kwenye Weather access token.\n\n" +
                        "Unaweza kuunganisha KV namespace inayoitwa STATE kwa cache, lakini Worker inaweza kufanya kazi hata bila hiyo."
                )
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showScoresHelp() {
        AlertDialog.Builder(this)
            .setTitle(t("Live scores setup", "Kuweka Live scores"))
            .setMessage(
                t(
                    "Live scores come from your own small proxy server, so the API key is never inside the app.\n\n" +
                        "1. Get an API-Football key (api-sports.io).\n" +
                        "2. Deploy backend/worker.js as a Cloudflare Worker and add the secret FOOTBALL_API_KEY.\n" +
                        "3. Paste the Worker address (https://...workers.dev) in 'Scores server URL'.\n\n" +
                        "Full steps are in backend/README.txt. This is for football information only.",
                    "Live scores zinatoka kwenye proxy yako ndogo, kwa hiyo ufunguo wa API haumo ndani ya app.\n\n" +
                        "1. Chukua ufunguo wa API-Football (api-sports.io).\n" +
                        "2. Weka backend/worker.js kama Cloudflare Worker na uongeze secret FOOTBALL_API_KEY.\n" +
                        "3. Bandika anwani ya Worker (https://...workers.dev) kwenye 'Anwani ya seva ya scores'.\n\n" +
                        "Hatua kamili ziko kwenye backend/README.txt. Hii ni taarifa za mpira tu."
                )
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showPrivacy() {
        AlertDialog.Builder(this)
            .setTitle(t("Privacy & data use", "Faragha na matumizi ya data"))
            .setMessage(
                t(
                    "Rahim Lux Go keeps your history, bookmarks, searches and settings only on your phone. There is no account, and nothing is uploaded to our servers.\n\n" +
                        "The app connects to: the search engine and suggestion service you choose (Google, Bing, DuckDuckGo or Yahoo); Google News, BBC and Al Jazeera for headlines; the football scores server you configure (if any); weather from OpenWeather through the separate weather server you configure (Auto mode uses approximate location from your network address, which is not stored); Google's icon service for Home icons; and Google AdMob, which shows ads and may use your device's advertising ID.\n\n" +
                        "Private tabs do not save history, but cookies are shared with normal tabs. You can clear your data at any time in Settings.",
                    "Rahim Lux Go inahifadhi history, bookmarks, utafutaji na mipangilio yako kwenye simu yako tu. Hakuna akaunti, na hakuna kinachopakiwa kwenye seva zetu.\n\n" +
                        "App inaunganishwa na: injini ya kutafuta na mapendekezo uliyochagua (Google, Bing, DuckDuckGo au Yahoo); Google News, BBC na Al Jazeera kwa vichwa vya habari; seva ya football scores uliyoiweka (kama ipo); hali ya hewa kutoka OpenWeather kupitia seva yake tofauti unayoweka (hali ya Otomatiki inatumia makadirio ya eneo kutoka anwani ya mtandao wako, na haihifadhiwi); huduma ya icons ya Google kwa icons za Home; na Google AdMob, inayoonyesha matangazo na inaweza kutumia advertising ID ya simu yako.\n\n" +
                        "Tab za faragha hazihifadhi history, lakini cookies zinashirikiwa na tab za kawaida. Unaweza kufuta data yako wakati wowote kwenye Settings."
                )
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle(t("Clear browsing data?", "Futa data ya kuvinjari?"))
            .setMessage(
                t(
                    "This clears history, search history, cookies and cache. Bookmarks and Home sites are kept.",
                    "Hii inafuta history, historia ya utafutaji, cookies na cache. Bookmarks na tovuti za Home zinabaki."
                )
            )
            .setPositiveButton(t("Clear", "Futa")) { _, _ ->
                store.clearHistory()
                store.clearSearches()
                CookieManager.getInstance().removeAllCookies(null)
                WebStorage.getInstance().deleteAllData()
                WebView(this).clearCache(true)
                setResult(RESULT_OK, Intent().putExtra("cleared", true))
                toast(t("Data cleared", "Data imefutwa"))
            }
            .setNegativeButton(t("Cancel", "Ghairi"), null)
            .show()
    }

    // ---------------- Vipande vya UI ----------------

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun section(title: String) {
        val tv = TextView(this)
        tv.text = title.uppercase()
        tv.setTextColor(gold); tv.textSize = 12f; tv.setTypeface(null, Typeface.BOLD); tv.letterSpacing = 0.1f
        tv.setPadding(dp(4), dp(22), 0, dp(8))
        list.addView(tv)
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = resources.getDrawable(R.drawable.bg_card, theme)
        return c
    }

    private fun addCard(c: LinearLayout) {
        if (c.childCount > 0) c.removeViewAt(c.childCount - 1)
        list.addView(c)
    }

    private fun arrow(): View {
        val a = TextView(this)
        a.text = "›"; a.textSize = 22f; a.setTextColor(gold)
        return a
    }

    private fun row(parent: LinearLayout, title: String, sub: String?, trailing: View?, onClick: (() -> Unit)?) {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(14), dp(16), dp(14))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        val tt = TextView(this)
        tt.text = title; tt.textSize = 15f; tt.setTextColor(Color.WHITE)
        tx.addView(tt)
        if (sub != null) {
            val ss = TextView(this)
            ss.text = sub; ss.textSize = 12f; ss.setTextColor(Color.parseColor("#8A8A94"))
            tx.addView(ss)
        }
        r.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) r.addView(trailing)
        if (onClick != null) r.setOnClickListener { onClick() }
        parent.addView(r)
        val d = View(this)
        d.setBackgroundColor(Color.parseColor("#14FFFFFF"))
        parent.addView(d, LinearLayout.LayoutParams(-1, 1))
    }

    private fun switchRow(parent: LinearLayout, title: String, sub: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val sw = SwitchCompat(this)
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, checked -> set(checked) }
        row(parent, title, sub, sw) { sw.toggle() }
    }

    private fun choiceRow(
        parent: LinearLayout, title: String, options: List<Pair<String, String>>,
        get: () -> String, set: (String) -> Unit
    ) {
        val cur = options.firstOrNull { it.first == get() }?.second ?: ""
        val value = TextView(this)
        value.text = cur; value.textSize = 14f; value.setTextColor(gold)
        row(parent, title, null, value) {
            val idx = options.indexOfFirst { it.first == get() }.coerceAtLeast(0)
            AlertDialog.Builder(this).setTitle(title)
                .setSingleChoiceItems(options.map { it.second }.toTypedArray(), idx) { dlg, i ->
                    set(options[i].first)
                    dlg.dismiss()
                    build()
                }.show()
        }
    }
}
