package com.rahimlux.go

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val homeHost = "home.rahimlux.go"
    private val home = "https://$homeHost/"
    private val accent = Color.parseColor("#FFB300")
    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val betNames = setOf("Betway", "Betpawa", "SportyBet", "1win")

    private val brand = mapOf(
        "Google" to "#4285F4", "YouTube" to "#FF0000", "Facebook" to "#1877F2",
        "Instagram" to "#E1306C", "WhatsApp" to "#25D366", "TikTok" to "#222222",
        "Wikipedia" to "#636466", "Mwananchi" to "#E53935",
        "Betway" to "#00A826", "Betpawa" to "#1F8A4C", "SportyBet" to "#00A64F", "1win" to "#2D6BFF"
    )
    private val palette = listOf("#FF7043", "#26A69A", "#5C6BC0", "#AB47BC", "#EC407A", "#29B6F6", "#9CCC65", "#FFA726")

    private lateinit var store: Store
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var tabsCount: TextView
    private lateinit var suggestList: ListView
    private lateinit var dlBtn: TextView
    private lateinit var adBox: FrameLayout
    private lateinit var adView: AdView
    private lateinit var bottomBar: View
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var siteIcon: TextView
    private lateinit var findBar: View
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private data class News(val title: String, val link: String, val src: String, val img: String = "")
    private data class Sug(val text: String, val hist: Boolean)
    private data class Feed(val key: String, val en: String, val sw: String, val url: String, val src: String)
    private val feeds = listOf(
        Feed("top", "Top", "Kuu", "https://feeds.bbci.co.uk/news/rss.xml", "BBC News"),
        Feed("tz", "Tanzania", "Tanzania", "", "Google News"),
        Feed("sports", "Sport", "Michezo", "https://feeds.bbci.co.uk/sport/rss.xml", "BBC Sport"),
        Feed("biz", "Business", "Biashara", "https://feeds.bbci.co.uk/news/business/rss.xml", "BBC News"),
        Feed("ent", "Entertainment", "Burudani", "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml", "BBC News"),
        Feed("africa", "Africa", "Afrika", "https://feeds.bbci.co.uk/news/world/africa/rss.xml", "BBC News"),
        Feed("tech", "Tech", "Teknolojia", "https://feeds.bbci.co.uk/news/technology/rss.xml", "BBC News"),
        Feed("swahili", "Kiswahili", "Kiswahili", "https://feeds.bbci.co.uk/swahili/rss.xml", "BBC Swahili"),
        Feed("world", "World", "Dunia", "https://www.aljazeera.com/xml/rss/all.xml", "Al Jazeera")
    )
    private val cats = ConcurrentHashMap<String, List<News>>()
    private val chromeUa = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    @Volatile private var news = listOf<News>()
    private var newsAt = 0L
    private var lastNav = 0L
    private var langAtOpen = ""
    private var scoresErr = ""
    private var scoresBusy = false
    private var scoresNext = 0L
    private var scoresFails = 0
    private var scoresHasLive = false
    private var weatherBusy = false
    private var weatherNext = 0L
    private var weatherErr = ""

    /** Download ikikamilika/ikishindwa: weka kwenye Notification Center (Android yenyewe inaonyesha arifa ya mfumo). */
    private val dlReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id >= 0) Notif.recordDownload(applicationContext, id)
        }
    }

    /** UA ya Chrome halisi (bila "wv" na "Version/4.0") ili tovuti zisikatae WebView. */
    private val mobileUa: String by lazy {
        WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(" Version/4.0", "")
    }
    private val tabs = mutableListOf<WebView>()
    private val lazyUrls = mutableMapOf<WebView, String>()
    private val pageHosts = ConcurrentHashMap<WebView, String>()
    private var cur = 0
    private var fullUrl = ""
    private val web get() = tabs[cur]
    private var pendingDl: (() -> Unit)? = null
    private var adOk = false
    private var kbOpen = false
    private var programmatic = false
    private var suggestions = listOf<Sug>()
    private var suggestSeq = 0
    private var suggestJob: Runnable? = null
    private var videoUrl: String? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun t(en: String, sw: String) = if (store.lang == "sw") sw else en
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) load(said)
        }
    }

    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pendingDl?.invoke() else toast(t("Storage permission is needed to download", "Ruhusa ya kuhifadhi inahitajika ili kupakua"))
        pendingDl = null
    }

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    private val settingsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.data?.getBooleanExtra("cleared", false) == true) tabs.forEach { it.clearCache(true); it.clearHistory() }
        applyAll()
    }

    private val poll = object : Runnable {
        override fun run() {
            if (tabs.isNotEmpty() && fullUrl.isEmpty() && System.currentTimeMillis() - newsAt > 15 * 60 * 1000) {
                newsAt = System.currentTimeMillis()
                loadNews()
            }
            if (tabs.isNotEmpty() && fullUrl.isEmpty() && !kbOpen && !scoresBusy &&
                scoresConfigured() && System.currentTimeMillis() >= scoresNext) loadScores()
            if (tabs.isNotEmpty() && fullUrl.isEmpty() && !kbOpen && !weatherBusy &&
                weatherConfigured() && System.currentTimeMillis() >= weatherNext) loadWeather()
            if (tabs.isNotEmpty() && fullUrl.isNotEmpty() && !kbOpen) {
                val js = "(function(){var v=document.querySelector('video');if(!v)return '';var s=v.currentSrc||v.src||'';if(!s){var e=v.querySelector('source');s=e?e.src:''}return s})()"
                web.evaluateJavascript(js) { res ->
                    val s = try { JSONTokener(res).nextValue() as? String } catch (e: Exception) { null }
                    if (!s.isNullOrEmpty() && s.startsWith("http") && !s.contains(".m3u8")) offerVideo(s)
                }
            }
            handler.postDelayed(this, 2500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        AdBlock.init(applicationContext)
        BlockLog.load(store.blockLogJson)
        initScores()
        weatherNext = store.weatherAtMs + 30 * 60 * 1000L
        Notif.ensureChannels(this, store)
        Push.refreshToken(this)
        Push.syncTopics(this)
        try {
            ContextCompat.registerReceiver(
                this, dlReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED
            )
        } catch (e: Exception) { }
        if (AdBlock.isStale()) Thread { AdBlock.update() }.start()

        urlBar = findViewById(R.id.url)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.container)
        tabsCount = findViewById(R.id.tabsCount)
        suggestList = findViewById(R.id.suggestList)
        dlBtn = findViewById(R.id.dlBtn)
        adBox = findViewById(R.id.adBox)
        bottomBar = findViewById(R.id.bottomBar)
        refresh = findViewById(R.id.refresh)
        siteIcon = findViewById(R.id.siteIcon)
        findBar = findViewById(R.id.findBar)
        findInput = findViewById(R.id.findInput)
        findCount = findViewById(R.id.findCount)

        refresh.setColorSchemeColors(accent)
        refresh.setProgressBackgroundColorSchemeColor(Color.parseColor("#1F1F24"))
        refresh.setOnRefreshListener {
            if (fullUrl.isEmpty()) { newsAt = System.currentTimeMillis(); loadNews(true) } else web.reload()
            handler.postDelayed({ refresh.isRefreshing = false }, 1500)
        }
        refresh.setOnChildScrollUpCallback { _, _ -> web.canScrollVertically(-1) || customView != null }

        findInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString() ?: ""
                if (q.isEmpty()) { web.clearMatches(); findCount.text = "0/0" } else web.findAllAsync(q)
            }
        })
        findViewById<View>(R.id.findNext).setOnClickListener { web.findNext(true) }
        findViewById<View>(R.id.findPrev).setOnClickListener { web.findNext(false) }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }

        MobileAds.initialize(this) { }
        adView = AdView(this)
        adView.setAdSize(AdSize.LARGE_BANNER)
        adView.adUnitId = getString(R.string.admob_banner_id)
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() { adOk = true; updateAd() }
            override fun onAdFailedToLoad(e: LoadAdError) { adOk = false; updateAd() }
        }
        adBox.addView(adView, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        adView.loadAd(AdRequest.Builder().build())

        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {
            val vis = ViewCompat.getRootWindowInsets(window.decorView)
                ?.isVisible(WindowInsetsCompat.Type.ime()) ?: false
            if (vis != kbOpen) {
                kbOpen = vis
                bottomBar.visibility = if (vis) View.GONE else View.VISIBLE
                if (vis) dlBtn.visibility = View.GONE
                updateAd()
            }
        }

        urlBar.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                load(urlBar.text.toString()); true
            } else false
        }
        urlBar.setOnFocusChangeListener { _, f ->
            if (f) { setBar(fullUrl); urlBar.selectAll(); showSuggestions("", emptyList()) } else { setBar(pretty(fullUrl)); hideSuggestions() }
        }
        urlBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (programmatic || !urlBar.hasFocus()) return
                val q = s?.toString()?.trim() ?: ""
                if (q.startsWith("http") || (!q.contains(" ") && q.contains("."))) {
                    hideSuggestions(); return
                }
                if (q.length < 2) { showSuggestions(q, emptyList()); return }
                suggest(q)
            }
        })
        suggestList.setOnItemClickListener { _, _, i, _ ->
            val s = suggestions.getOrNull(i)?.text ?: return@setOnItemClickListener
            hideSuggestions()
            load(s)
        }
        suggestList.setOnItemLongClickListener { _, _, i, _ ->
            val s = suggestions.getOrNull(i)
            if (s != null && s.hist) {
                store.removeSearch(s.text)
                showSuggestions(urlBar.text.toString().trim(), emptyList())
                toast(t("Removed from search history", "Imeondolewa kwenye historia ya utafutaji"))
                true
            } else false
        }
        dlBtn.setOnClickListener {
            videoUrl?.let { download(it, web.settings.userAgentString, "", "video/mp4") }
            dlBtn.visibility = View.GONE
        }

        findViewById<View>(R.id.mic).setOnClickListener { startVoice() }
        findViewById<View>(R.id.back).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.fwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.homeBtn).setOnClickListener { web.loadUrl(home) }
        findViewById<View>(R.id.tabsBox).setOnClickListener { showTabs() }
        findViewById<View>(R.id.menuBtn).setOnClickListener { showMenu() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    findBar.visibility == View.VISIBLE -> closeFind()
                    suggestList.visibility == View.VISIBLE -> hideSuggestions()
                    web.canGoBack() -> web.goBack()
                    tabs.size > 1 -> closeTab()
                    else -> finish()
                }
            }
        })

        newsAt = System.currentTimeMillis()
        loadNewsCache()
        loadNews()
        restoreTabs()
        if (savedInstanceState == null) handleIntent(intent)
        if (tabs.isEmpty()) newTab(home)
    }

    // ---------------- Tabs ----------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String, incognito: Boolean = false, load: Boolean = true): WebView {
        val w = WebView(this)
        w.tag = if (incognito) "inc" else null
        w.setBackgroundColor(Color.parseColor("#0B0B0D"))
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = store.dataSaver
        w.settings.setSupportMultipleWindows(true)
        w.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        w.setFindListener { a, n, _ -> if (w === web) findCount.text = if (n == 0) "0/0" else "${a + 1}/$n" }
        if (incognito) w.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        applyDark(w)
        applyDesktop(w)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.thirdCookies)
        w.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }
        w.setOnLongClickListener { v ->
            val wv = v as WebView
            val hit = wv.hitTestResult
            when (hit.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    val h = Handler(Looper.getMainLooper()) { m ->
                        val link = m.data.getString("url") ?: hit.extra
                        val img = m.data.getString("src")
                        showContextMenu(link, if (hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) img else null)
                        true
                    }
                    wv.requestFocusNodeHref(h.obtainMessage())
                    true
                }
                WebView.HitTestResult.IMAGE_TYPE -> { showContextMenu(null, hit.extra); true }
                else -> false
            }
        }

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val host = r.url.host ?: return null
                if (r.isForMainFrame) pageHosts[v] = host
                if (host == homeHost) {
                    val p = r.url.path
                    return when {
                        p.isNullOrEmpty() || p == "/" -> html(homeHtml(v.tag == "inc"))
                        p == "/logo.png" -> WebResourceResponse("image/png", null, resources.openRawResource(R.raw.logo))
                        else -> empty()
                    }
                }
                if (store.adblock && !store.isAdOff(pageHosts[v]) && AdBlock.isBlocked(host)) {
                    store.addBlocked(); BlockLog.add(host); return blocked()
                }
                val path = r.url.path ?: ""
                if (store.dataSaver && AdBlock.isHeavyMedia(path)) { store.addBlocked(); BlockLog.add("🎞 $host"); return blocked() }
                if (path.endsWith(".mp4", true) || path.endsWith(".webm", true)) {
                    val u = r.url.toString()
                    runOnUiThread { if (v === web) offerVideo(u) }
                }
                return null
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = (r.url.scheme ?: return false).lowercase()
                if (s == "rlg") {
                    // Kadi za Home tu (ukurasa wa Home) zinaweza kufungua ukurasa wa mechi
                    val pageHost = Uri.parse(v.url ?: "").host
                    val mid = r.url.lastPathSegment ?: ""
                    if (pageHost == homeHost && r.url.host == "match" && mid.isNotEmpty() && mid.length <= 12 && mid.all { it.isDigit() }) {
                        startActivity(Intent(this@MainActivity, MatchActivity::class.java).putExtra("id", mid))
                    }
                    return true
                }
                if (s == "http" || s == "https" || s == "about" || s == "data") return false
                // Usifungue faili za ndani wala javascript kupitia intents
                if (s == "file" || s == "content" || s == "javascript") return true
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }

            override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                runOnUiThread { recreate() }
                return true
            }

            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                recordSearch(v.tag == "inc", u)
                if (v === web) {
                    showUrl(u)
                    progress.visibility = View.VISIBLE
                    videoUrl = null
                    dlBtn.visibility = View.GONE
                }
            }

            override fun onPageFinished(v: WebView, u: String) {
                if (v === web) progress.visibility = View.GONE
                refresh.isRefreshing = false
                if (v.tag != "inc" && u.startsWith("http") && Uri.parse(u).host != homeHost) {
                    store.addHistory(v.title ?: u, u)
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === web) progress.progress = p
            }

            override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false
                newTab("about:blank", v.tag == "inc", false)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = web
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val i = tabs.indexOf(window)
                if (i >= 0 && tabs.size > 1) closeTabAt(i)
            }

            // Video ya skrini nzima (fullscreen)
            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                view.setBackgroundColor(Color.BLACK)
                (window.decorView as ViewGroup).addView(view, ViewGroup.LayoutParams(-1, -1))
                WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() { exitFullscreen() }

            // Kupakia faili (upload)
            override fun onShowFileChooser(
                webView: WebView, filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                return try { fileLauncher.launch(fileChooserParams.createIntent()); true }
                catch (e: Exception) { fileCb = null; false }
            }
        }
        tabs.add(w)
        show(tabs.size - 1)
        if (load) w.loadUrl(url)
        return w
    }

    private fun applyDark(w: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, store.darkWeb)
        }
    }

    private fun applyDesktop(w: WebView) {
        w.settings.userAgentString = if (store.desktop) desktopUa else mobileUa
        w.settings.useWideViewPort = true
        w.settings.loadWithOverviewMode = true
        w.settings.setSupportZoom(true)
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
    }

    private fun show(i: Int) {
        cur = i
        container.removeAllViews()
        container.addView(web, FrameLayout.LayoutParams(-1, -1))
        updateHint()
        val lazy = lazyUrls.remove(web)
        if (lazy != null) { web.loadUrl(lazy); showUrl(lazy) } else showUrl(web.url ?: "")
        tabsCount.text = tabs.size.toString()
        videoUrl = null
        dlBtn.visibility = View.GONE
        hideSuggestions()
    }

    private fun closeTabAt(i: Int) { cur = i; closeTab() }

    private fun closeTab() {
        if (tabs.size == 1) { web.loadUrl(home); return }
        container.removeAllViews()
        val w = tabs.removeAt(cur)
        lazyUrls.remove(w)
        pageHosts.remove(w)
        if (w.tag == "inc") { w.clearCache(true); w.clearHistory() }
        w.destroy()
        show(minOf(cur, tabs.size - 1))
    }

    private fun restoreTabs() {
        try {
            val o = JSONObject(store.tabsJson)
            val a = o.getJSONArray("u")
            if (a.length() == 0) return
            for (k in 0 until a.length()) {
                val u = a.getString(k)
                val w = newTab(u, false, false)
                lazyUrls[w] = u
            }
            show(o.optInt("i", 0).coerceIn(0, tabs.size - 1))
        } catch (e: Exception) { }
    }

    private fun saveTabs() {
        if (tabs.isEmpty()) return
        val pairs = tabs.filter { it.tag != "inc" }
            .mapNotNull { w -> (lazyUrls[w] ?: w.url)?.takeIf { it.startsWith("http") }?.let { w to it } }
            .take(12)
        val idx = pairs.indexOfFirst { it.first === web }.coerceAtLeast(0)
        val o = JSONObject().put("i", idx).put("u", JSONArray(pairs.map { it.second }))
        store.tabsJson = o.toString()
    }

    private fun exitFullscreen() {
        val v = customView ?: return
        (window.decorView as ViewGroup).removeView(v)
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    private fun openFind() {
        findBar.visibility = View.VISIBLE
        findInput.setText("")
        findInput.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(findInput, 0)
    }

    private fun closeFind() {
        web.clearMatches()
        findBar.visibility = View.GONE
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(findInput.windowToken, 0)
    }

    private fun unxml(s: String) = s.replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&#39;", "'").trim()

    private fun saveNewsCache() {
        val o = JSONObject()
        for ((k, l) in cats) {
            val a = JSONArray()
            l.forEach { a.put(JSONObject().put("t", it.title).put("l", it.link).put("s", it.src).put("i", it.img)) }
            o.put(k, a)
        }
        store.newsJson = o.toString()
    }

    private fun loadNewsCache() {
        try {
            val o = JSONObject(store.newsJson)
            o.keys().forEach { k ->
                val a = o.getJSONArray(k)
                cats[k] = (0 until a.length()).map {
                    val x = a.getJSONObject(it)
                    News(x.getString("t"), x.getString("l"), x.getString("s"), x.optString("i", ""))
                }
            }
        } catch (e: Exception) { }
    }

    /** Vichwa vya habari kutoka RSS yoyote, pamoja na picha (media:thumbnail / media:content / enclosure). */
    private fun parseFeed(xml: String, srcLabel: String, max: Int): List<News> {
        val dot = RegexOption.DOT_MATCHES_ALL
        val imgExt = Regex("""\.(jpe?g|png|webp)""", RegexOption.IGNORE_CASE)
        return Regex("<item>(.*?)</item>", dot).findAll(xml).take(max).mapNotNull { m ->
            val b = m.groupValues[1]
            val title = Regex("<title>(.*?)</title>", dot).find(b)?.groupValues?.get(1)?.let { unxml(it) } ?: return@mapNotNull null
            val link = Regex("<link>(.*?)</link>", dot).find(b)?.groupValues?.get(1)?.let { unxml(it) } ?: return@mapNotNull null
            val img = Regex("""<media:thumbnail[^>]*url=["']([^"']+)["']""").find(b)?.groupValues?.get(1)
                ?: Regex("""<media:content[^>]*url=["']([^"']+)["']""").findAll(b).map { it.groupValues[1] }.firstOrNull { imgExt.containsMatchIn(it) }
                ?: Regex("""<enclosure[^>]*url=["']([^"']+)["']""").findAll(b).map { it.groupValues[1] }.firstOrNull { imgExt.containsMatchIn(it) }
                ?: ""
            News(title, link.trim(), srcLabel, unxml(img).replace("http://", "https://"))
        }.toList()
    }

    /** Habari: Tanzania (Google News) + za kimataifa (BBC, Al Jazeera) zenye picha. */
    private fun loadNews(manual: Boolean = false) {
        Thread {
            val dot = RegexOption.DOT_MATCHES_ALL
            var ok = false
            try {
                val feed = if (store.lang == "sw") "https://news.google.com/rss?hl=sw&gl=TZ&ceid=TZ:sw"
                else "https://news.google.com/rss?hl=en-TZ&gl=TZ&ceid=TZ:en"
                val c = URL(feed).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 8000
                val xml = c.inputStream.bufferedReader().readText()
                c.disconnect()
                val items = Regex("<item>(.*?)</item>", dot).findAll(xml).take(8).mapNotNull { m ->
                    val b = m.groupValues[1]
                    val title = Regex("<title>(.*?)</title>", dot).find(b)?.groupValues?.get(1) ?: return@mapNotNull null
                    val link = Regex("<link>(.*?)</link>", dot).find(b)?.groupValues?.get(1) ?: return@mapNotNull null
                    val src = Regex("<source[^>]*>(.*?)</source>", dot).find(b)?.groupValues?.get(1) ?: ""
                    News(unxml(title).substringBeforeLast(" - "), unxml(link), unxml(src))
                }.toList()
                if (items.isNotEmpty()) { cats["tz"] = items; ok = true }
            } catch (e: Exception) { }

            val pool = Executors.newFixedThreadPool(4)
            for (f in feeds) {
                if (f.url.isEmpty()) continue
                try {
                    val c = URL(f.url).openConnection() as HttpURLConnection
                    c.connectTimeout = 6000
                    c.readTimeout = 8000
                    c.setRequestProperty("User-Agent", chromeUa)
                    val xml = c.inputStream.bufferedReader().readText()
                    c.disconnect()
                    val raw = parseFeed(xml, f.src, 6)
                    val futures = raw.map { n ->
                        if (n.img.isEmpty() && !store.dataSaver) pool.submit(Callable<String?> { ogImage(n.link) }) else null
                    }
                    val items = raw.mapIndexed { i, n ->
                        val got = try { futures[i]?.get(8, TimeUnit.SECONDS) } catch (e: Exception) { null }
                        if (got != null) n.copy(img = got) else n
                    }
                    if (items.isNotEmpty()) { cats[f.key] = items; ok = true }
                } catch (e: Exception) { }
            }
            pool.shutdown()
            if (ok) { store.newsUpdated = System.currentTimeMillis(); saveNewsCache() }
            runOnUiThread {
                if (manual) toast(if (ok) t("News updated", "Habari zimesasishwa")
                else t("Couldn't update news. Check your internet.", "Imeshindwa kusasisha habari. Angalia intaneti."))
                if (tabs.isNotEmpty() && fullUrl.isEmpty() && lazyUrls[web] == null) web.reload()
            }
        }.start()
    }

    /** og:image ya makala (picha ya habari) — inasoma mwanzo wa ukurasa tu. */
    private fun ogImage(pageUrl: String): String? {
        return try {
            val c = URL(pageUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 4000
            c.setRequestProperty("User-Agent", chromeUa)
            val buf = ByteArray(60000)
            var n = 0
            c.inputStream.use { ins ->
                while (n < buf.size) {
                    val r = ins.read(buf, n, buf.size - n)
                    if (r < 0) break
                    n += r
                }
            }
            c.disconnect()
            val head = String(buf, 0, n)
            val m = Regex("""<meta[^>]+(?:property|name)=["']og:image["'][^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(head)
                ?: Regex("""<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']og:image["']""", RegexOption.IGNORE_CASE).find(head)
            m?.groupValues?.get(1)?.let { unxml(URL(URL(pageUrl), it).toString()) }
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Kupokea viungo/maandishi kutoka apps nyingine ----------------

    /** Share, Open link, Search with Rahim Lux Go. Inafungua tab MPYA; tabs zilizopo haziguswi. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val ex = i.extras
        if (i.getStringExtra("rlg_dest") == null && ex != null && ex.containsKey("google.message_id")) {
            val d = HashMap<String, String>()
            for (k in ex.keySet()) {
                @Suppress("DEPRECATION") val v = ex.get(k)
                if (v is String) d[k] = v
            }
            d.remove("_direct")
            Notif.recordFromSystem(this, d)
            val (dest2, arg2) = Notif.destOf(d)
            if (dest2.isNotEmpty()) routeDest(dest2, arg2, null)
            return
        }
        val dest = i.getStringExtra("rlg_dest")
        if (dest != null) {
            routeDest(dest, i.getStringExtra("rlg_arg") ?: "", i.getStringExtra("rlg_nid"))
            return
        }
        val target: String? = when (i.action) {
            Intent.ACTION_VIEW -> {
                val d = i.dataString
                if (d == null) null
                else LinkParser.safeUrl(d) ?: run { toast(t("Unsupported link", "Kiungo hakitumiki")); null }
            }
            Intent.ACTION_SEND ->
                if (i.type?.startsWith("text/") == true) LinkParser.resolve(i.getCharSequenceExtra(Intent.EXTRA_TEXT)) { searchUrl(it) } else null
            Intent.ACTION_PROCESS_TEXT ->
                LinkParser.resolve(i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)) { searchUrl(it) }
            Intent.ACTION_WEB_SEARCH ->
                LinkParser.resolve(i.getStringExtra(SearchManager.QUERY)) { searchUrl(it) }
            else -> null
        }
        if (target == null) return
        exitFullscreen()
        if (tabs.isNotEmpty() && findBar.visibility == View.VISIBLE) closeFind()
        hideSuggestions()
        lastNav = System.currentTimeMillis()
        newTab(target)
    }

    /** Destination za arifa (match, notifications, downloads, settings, url). Zinakubali thamani zilizothibitishwa tu. */
    private fun routeDest(dest: String, arg: String, nid: String?) {
        if (nid != null) Notif.markRead(store, nid)
        lastNav = System.currentTimeMillis()
        when (dest) {
            "match" -> if (arg.isNotEmpty() && arg.length <= 12 && arg.all { it.isDigit() }) {
                startActivity(Intent(this, MatchActivity::class.java).putExtra("id", arg))
            }
            "notifications" -> startActivity(Intent(this, NotificationsActivity::class.java))
            "downloads" -> startActivity(Intent(this, DownloadsActivity::class.java))
            "settings" -> startActivity(Intent(this, NotificationSettingsActivity::class.java))
            "url" -> LinkParser.safeUrl(arg)?.let { newTab(it) }
        }
    }

    // ---------------- Hali ya hewa ----------------

    private fun weatherConfigured() = store.weatherOn && store.weatherUrl.isNotEmpty()

    /** Dakika 30 kati ya masasisho (seva ina cache pia). Ikifeli inajaribu tena baada ya dakika 5. */
    private fun loadWeather() {
        if (weatherBusy || !weatherConfigured()) return
        weatherBusy = true
        val base = store.weatherUrl
        val token = store.weatherToken
        val city = store.weatherCity
        Thread {
            val r = Weather.fetch(base, token, city)
            runOnUiThread {
                weatherBusy = false
                val now = System.currentTimeMillis()
                if (r.json != null) {
                    store.weatherJson = r.json
                    store.weatherAtMs = now
                    weatherErr = ""
                    weatherNext = now + 30 * 60 * 1000L
                } else {
                    weatherErr = r.error ?: "network"
                    weatherNext = now + 5 * 60 * 1000L
                }
                pushWeather()
            }
        }.start()
    }

    private fun pushWeather() {
        if (tabs.isEmpty() || fullUrl.isNotEmpty() || lazyUrls[web] != null) return
        val d = try { JSONObject(store.weatherJson) } catch (e: Exception) { JSONObject() }
        val p = JSONObject().put("d", d).put("at", store.weatherAtMs).put("err", weatherErr)
        web.evaluateJavascript("window.setWeather&&window.setWeather(" + p.toString().replace("<", "\\u003c") + ")", null)
    }

    // ---------------- Live scores ----------------

    private fun todayStr() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun scoresConfigured() = store.scoresOn && store.scoresUrl.isNotEmpty()

    private fun initScores() {
        val fresh = store.scoresDate == todayStr()
        scoresHasLive = fresh && Scores.hasLive(store.scoresJson)
        scoresNext = if (fresh) store.scoresAtMs + (if (scoresHasLive) 60_000L else 600_000L) else 0L
    }

    /** Inaita proxy mara moja (si kila sekunde): dakika 1 kukiwa na mechi live, dakika 10 vinginevyo; ikifeli inajaribu tena baadaye. */
    private fun loadScores() {
        if (scoresBusy || !scoresConfigured()) return
        scoresBusy = true
        val base = store.scoresUrl
        val token = store.scoresToken
        val date = todayStr()
        Thread {
            val r = Scores.fetch(base, token, date)
            runOnUiThread {
                scoresBusy = false
                val now = System.currentTimeMillis()
                if (r.matchesJson != null) {
                    store.scoresJson = r.matchesJson
                    store.scoresAtMs = now
                    store.scoresDate = date
                    store.scoresSrvMs = if (r.srvMs > 0) r.srvMs else now
                    store.scoresStale = r.stale || r.quota
                    scoresHasLive = r.hasLive
                    scoresErr = ""
                    scoresFails = 0
                    // Data ya zamani (quota ya API): usiulize mara kwa mara
                    scoresNext = now + (if (r.stale || r.quota) 300_000L else if (r.hasLive) 60_000L else 600_000L)
                } else {
                    scoresErr = r.error ?: "network"
                    scoresFails++
                    scoresNext = now + minOf(300_000L, 60_000L * (1L shl minOf(scoresFails - 1, 3)))
                }
                pushScores()
            }
        }.start()
    }

    /** Inasasisha sehemu ya scores ndani ya Home bila kupakia ukurasa upya. */
    private fun pushScores() {
        if (tabs.isEmpty() || fullUrl.isNotEmpty() || lazyUrls[web] != null) return
        val arr = try {
            if (store.scoresDate == todayStr()) JSONArray(store.scoresJson) else JSONArray()
        } catch (e: Exception) { JSONArray() }
        val p = JSONObject().put("m", arr).put("at", store.scoresAtMs).put("err", scoresErr)
            .put("f", JSONArray(store.follows().keys.toList()))
            .put("srv", store.scoresSrvMs).put("stale", store.scoresStale)
        web.evaluateJavascript("window.setScores&&window.setScores(" + p.toString().replace("<", "\\u003c") + ")", null)
    }

    // ---------------- Menyu ya long-press (kiungo / picha) ----------------

    private fun copyText(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", s))
        toast(t("Copied", "Imenakiliwa"))
    }

    private fun shareText(s: String) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, s) }
        startActivity(Intent.createChooser(i, t("Share via", "Tuma kupitia")))
    }

    private fun showContextMenu(link: String?, img: String?) {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        fun add(label: String, a: () -> Unit) { items.add(label to a) }
        if (link != null && link.startsWith("http")) {
            add(t("Open in new tab", "Fungua kwenye tab mpya")) { newTab(link) }
            add(t("Open in private tab", "Fungua kwenye tab ya faragha")) { newTab(link, true) }
            add(t("Copy link", "Nakili kiungo")) { copyText(link) }
            add(t("Share link", "Shiriki kiungo")) { shareText(link) }
        }
        if (img != null && img.startsWith("http")) {
            add(t("Download image", "Pakua picha")) { download(img, web.settings.userAgentString, "", "") }
            add(t("Open image in new tab", "Fungua picha kwenye tab mpya")) { newTab(img) }
            if (link == null) add(t("Copy image link", "Nakili kiungo cha picha")) { copyText(img) }
        }
        if (items.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle((link ?: img ?: "").take(60))
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }
            .show()
    }

    /** Mipangilio ikibadilishwa kwenye Settings, itumie kwenye tabs zote. */
    private fun applyAll() {
        weatherNext = 0L
        weatherErr = ""
        scoresNext = 0L
        scoresErr = ""
        tabs.forEach { w ->
            applyDark(w)
            applyDesktop(w)
            w.settings.blockNetworkImage = store.dataSaver
            CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.thirdCookies)
        }
        updateHint()
        if (store.lang != langAtOpen) { news = listOf(); cats.clear(); loadNews() }
        if (fullUrl.isEmpty()) web.reload()
    }

    private fun updateHint() {
        urlBar.hint = if (web.tag == "inc") t("🕶 Private tab", "🕶 Tab ya faragha")
        else t("Search or type address", "Tafuta au andika anwani")
    }

    // ---------------- URL bar, search, suggestions ----------------

    private fun setBar(s: String) { programmatic = true; urlBar.setText(s); programmatic = false }

    private fun pretty(u: String): String =
        if (u.isEmpty()) "" else (Uri.parse(u).host?.removePrefix("www.") ?: u)

    private fun showUrl(u: String) {
        fullUrl = if (Uri.parse(u).host == homeHost) "" else u
        if (!urlBar.hasFocus()) setBar(pretty(fullUrl))
        siteIcon.text = when {
            fullUrl.isEmpty() -> "🔍"
            fullUrl.startsWith("https") -> "🔒"
            else -> "⚠️"
        }
        updateAd()
    }

    private fun updateAd() {
        adBox.visibility = if (fullUrl.isEmpty() && adOk && !kbOpen) View.VISIBLE else View.GONE
    }

    private fun searchUrl(q: String): String {
        val e = Uri.encode(q)
        return when (store.engine) {
            "ddg" -> "https://duckduckgo.com/?q=$e"
            "bing" -> "https://www.bing.com/search?q=$e"
            "yahoo" -> "https://search.yahoo.com/search?p=$e"
            else -> "https://www.google.com/search?hl=" + (if (store.lang == "sw") "sw" else "en") + "&q=$e"
        }
    }

    private fun load(input: String) {
        val t = input.trim()
        val url = when {
            t.isEmpty() -> return
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(" ") && t.contains(".") -> "https://$t"
            else -> searchUrl(t)
        }
        hideSuggestions()
        lastNav = System.currentTimeMillis()
        web.loadUrl(url)
        urlBar.clearFocus()
    }

    private fun suggest(q: String) {
        suggestJob?.let { handler.removeCallbacks(it) }
        showSuggestions(q, emptyList())
        val seq = ++suggestSeq
        val r = Runnable {
            Thread {
                val list = try {
                    val lang = if (store.lang == "sw") "sw" else "en"
                    val enc = Uri.encode(q)
                    val endpoint = when (store.engine) {
                        "ddg" -> "https://duckduckgo.com/ac/?type=list&q=$enc"
                        "bing" -> "https://api.bing.com/osjson.aspx?query=$enc"
                        else -> "https://suggestqueries.google.com/complete/search?client=firefox&hl=$lang&q=$enc"
                    }
                    val c = URL(endpoint).openConnection() as HttpURLConnection
                    c.connectTimeout = 4000
                    c.readTimeout = 4000
                    val body = c.inputStream.bufferedReader().readText()
                    c.disconnect()
                    val a = JSONArray(body).getJSONArray(1)
                    (0 until a.length()).map { a.getString(it) }.take(8)
                } catch (e: Exception) {
                    emptyList<String>()
                }
                runOnUiThread { if (seq == suggestSeq) showSuggestions(q, list) }
            }.start()
        }
        suggestJob = r
        handler.postDelayed(r, 250)
    }

    /** Historia ya utafutaji (🕘) kwanza, kisha mapendekezo ya mtandaoni (🔍). */
    private fun showSuggestions(q: String, online: List<String>) {
        val ql = q.trim().lowercase()
        val hist = if (web.tag == "inc") listOf() else store.searches()
            .filter { ql.isEmpty() || it.lowercase().contains(ql) }
            .filter { it.lowercase() != ql }
            .take(if (ql.isEmpty()) 8 else 4)
        val seen = hist.map { it.lowercase() }.toMutableSet()
        val on = online.filter { seen.add(it.lowercase()) }
        val l = (hist.map { Sug(it, true) } + on.map { Sug(it, false) }).take(9)
        suggestions = l
        if (l.isEmpty() || !urlBar.hasFocus()) { suggestList.visibility = View.GONE; return }
        suggestList.adapter = ArrayAdapter(this, R.layout.item_suggest, l.map { (if (it.hist) "🕘  " else "🔍  ") + it.text })
        suggestList.visibility = View.VISIBLE
    }

    private fun recordSearch(incognito: Boolean, u: String) {
        if (incognito) return
        val uri = Uri.parse(u)
        val host = uri.host ?: return
        val path = uri.path ?: ""
        val q = when {
            host.contains("google.") && path == "/search" -> uri.getQueryParameter("q")
            host.endsWith("bing.com") && path == "/search" -> uri.getQueryParameter("q")
            host.endsWith("duckduckgo.com") && (path == "/" || path.isEmpty()) -> uri.getQueryParameter("q")
            host.endsWith("search.yahoo.com") && path == "/search" -> uri.getQueryParameter("p")
            else -> null
        }
        q?.trim()?.takeIf { it.length in 2..100 }?.let { store.addSearch(it) }
    }

    private fun hideSuggestions() {
        suggestSeq++
        suggestJob?.let { handler.removeCallbacks(it) }
        suggestList.visibility = View.GONE
    }

    private fun pickEngine() {
        val keys = listOf("google", "ddg", "bing", "yahoo")
        val names = listOf("Google", "DuckDuckGo", "Bing", "Yahoo")
        AlertDialog.Builder(this).setTitle(t("Search engine", "Injini ya kutafuta"))
            .setSingleChoiceItems(names.toTypedArray(), keys.indexOf(store.engine).coerceAtLeast(0)) { dlg, i ->
                store.engine = keys[i]
                dlg.dismiss()
                if (fullUrl.isEmpty()) web.reload()
                toast(t("Search engine: ", "Injini: ") + names[i])
            }.show()
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val vl = if (store.voiceLang == "sw") "sw-TZ" else "en-US"
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, vl)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, vl)
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (store.voiceLang == "sw") "Sema unachotafuta…" else "Say what you want to search")
        }
        try { voice.launch(i) } catch (e: Exception) {
            toast(t("Voice search is not available on this phone", "Voice search haipatikani kwenye simu hii"))
        }
    }

    // ---------------- Video / downloads ----------------

    private fun offerVideo(u: String) {
        videoUrl = u
        if (!kbOpen && fullUrl.isNotEmpty()) dlBtn.visibility = View.VISIBLE
    }

    private fun download(url: String, ua: String, cd: String, mime: String) {
        if (!url.startsWith("http")) { toast(t("This link can't be downloaded", "Kiungo hiki hakiwezi kupakuliwa")); return }
        val go: () -> Unit = {
            try {
                val name = URLUtil.guessFileName(url, cd, mime)
                val req = DownloadManager.Request(Uri.parse(url))
                if (mime.isNotEmpty()) req.setMimeType(mime)
                req.addRequestHeader("User-Agent", ua)
                web.url?.let { req.addRequestHeader("Referer", it) }
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                req.setNotificationVisibility(
                    if (store.nDownloads) DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    else DownloadManager.Request.VISIBILITY_HIDDEN
                )
                req.setTitle(name)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                toast(t("Downloading: ", "Inapakua: ") + name)
            } catch (e: Exception) {
                toast(t("Download failed", "Imeshindwa kupakua"))
            }
        }
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDl = go
            storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else go()
    }

    // ---------------- Home page ----------------

    private fun html(s: String) = WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(s.toByteArray()))
    /** Jibu la 404 kwa maombi yaliyozuiwa: players za video hazikwami zikisubiri tangazo. */
    private fun blocked() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", mapOf<String, String>(), ByteArrayInputStream(ByteArray(0))
    )

    private fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;")

    private fun floaters(): String {
        val sym = listOf("✦", "◆", "➤", "★", "⚡", "👑", "🌐", "✧", "▶", "●", "✦", "◆", "★", "✧")
        return sym.mapIndexed { i, s ->
            val left = (i * 83 + 7) % 94
            val size = 14 + (i * 7) % 22
            val dur = 14 + (i * 5) % 12
            val delay = -((i * 3) % 14)
            "<span style='left:$left%;font-size:${size}px;animation-duration:${dur}s;animation-delay:${delay}s'>$s</span>"
        }.joinToString("")
    }

    private fun homeHtml(inc: Boolean): String {
        val acc = if (inc) "#8E5CFF" else "#FFB300"
        val glow = if (inc) "rgba(142,92,255,.45)" else "rgba(255,179,0,.40)"

        fun tile(i: Int, n: String, u: String): String {
            val c = brand[n] ?: palette[Math.abs(n.hashCode()) % palette.size]
            val host = (Uri.parse(u).host ?: "").removePrefix("www.").removePrefix("web.").removePrefix("m.")
            return "<a class=t style='animation-delay:${i * 45}ms' href='${esc(u)}'><i style='background:$c'><span>${esc(n.take(1).uppercase())}</span>" +
                "<img src='https://www.google.com/s2/favicons?domain=${esc(host)}&amp;sz=128' onload=\"this.style.background='#fff'\" onerror='this.remove()'></i>" +
                "<b>${esc(n)}</b></a>"
        }

        val all = store.sites()
        val fav = all.filter { it.first !in betNames }
        val bets = all.filter { it.first in betNames }
        val favHtml = fav.mapIndexed { i, s -> tile(i, s.first, s.second) }.joinToString("")
        val betHtml = bets.mapIndexed { i, s -> tile(i + fav.size, s.first, s.second) }.joinToString("")
        val favSection = if (fav.isEmpty()) "" else "<h2>${t("Favorites", "Vipendwa")}</h2><div class=g>$favHtml</div>"
        val betSection = if (bets.isEmpty()) "" else "<h2>${t("Sports &amp; betting · 18+", "Michezo na kubeti · 18+")}</h2><div class=g>$betHtml</div>"

        val groups = feeds.map { f -> Triple(f.key, t(f.en, f.sw), cats[f.key] ?: listOf()) }
        val firstKey = (groups.firstOrNull { it.third.isNotEmpty() } ?: groups.first()).first
        val newsSection = run {
            val chips = groups.joinToString("") { g ->
                "<button type=button class='chip${if (g.first == firstKey) " on" else ""}' onclick=\"sh('${g.first}',this)\">${esc(g.second)}</button>"
            }
            val lists = groups.joinToString("") { g ->
                val items = if (g.third.isEmpty()) {
                    "<div class=empty>${t("Loading news… (needs internet)", "Inapakia habari… (inahitaji intaneti)")}</div>"
                } else g.third.mapIndexed { j, n ->
                    val letter = esc(n.src.take(1).uppercase().ifEmpty { "N" })
                    val orig = n.img
                    val shown = if (j == 0 && orig.contains("ichef.bbci.co.uk")) orig.replace("/standard/240/", "/standard/624/") else orig
                    val img = if (orig.isNotEmpty())
                        "<img loading=lazy src='${esc(shown)}' data-o='${esc(orig)}' onerror=\"if(this.dataset.o&&this.src!=this.dataset.o){this.src=this.dataset.o}else{this.remove()}\">"
                    else ""
                    "<a class='n${if (j == 0) " big" else ""}' href='${esc(n.link)}'><div class=ph><em>$letter</em>$img</div>" +
                        "<div class=tx><b>${esc(n.title)}</b><span>${esc(n.src)}</span></div></a>"
                }.joinToString("")
                "<div class=nl id='n_${g.first}' style='display:${if (g.first == firstKey) "block" else "none"}'>$items</div>"
            }
            val upd = if (store.newsUpdated > 0)
                " · " + t("updated ", "imesasishwa ") + java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(store.newsUpdated))
            else ""
            "<h2>${t("News", "Habari")}$upd</h2><div class=chips>$chips</div>$lists"
        }

        val lang = if (store.lang == "sw") "sw" else "en"
        val (sAction, sName, sHidden, sLabel) = when (store.engine) {
            "ddg" -> listOf("https://duckduckgo.com/", "q", "", "DuckDuckGo")
            "bing" -> listOf("https://www.bing.com/search", "q", "", "Bing")
            "yahoo" -> listOf("https://search.yahoo.com/search", "p", "", "Yahoo")
            else -> listOf("https://www.google.com/search", "q", "<input type=hidden name=hl value=$lang>", "Google")
        }
        val placeholder = t("Search with $sLabel", "Tafuta kwa $sLabel")

        val on = "ON"
        val off = "OFF"
        val ds = if (store.dataSaver) on else off
        val ab = if (store.adblock) on else off
        val logo = if (inc) "<div class=lg>&#128374;</div>" else "<img class=lg src='/logo.png'>"
        val tag = if (inc) t("Private tab: history is not saved", "Tab ya faragha: historia haihifadhiwi")
        else t("Fast, secure and smart browser", "Kivinjari cha haraka na salama")
        val lBlocked = t("Blocked", "Vilivyozuiwa")
        val gm = t("Good morning", "Habari za asubuhi")
        val ga = t("Good afternoon", "Habari za mchana")
        val ge = t("Good evening", "Habari za jioni")

        // HALI YA HEWA (OpenWeather kupitia seva yako)
        val wxOn = store.weatherOn && store.weatherUrl.isNotEmpty()
        val wxSection = if (!wxOn) "" else
            "<h2>${t("Weather", "Hali ya hewa")}<span id=wxu></span></h2><div id=wx class=wx></div>"
        val wxData = try { JSONObject(store.weatherJson) } catch (e: Exception) { JSONObject() }
        val wxInit = JSONObject().put("d", wxData).put("at", store.weatherAtMs).put("err", weatherErr)
            .put("cfg", wxOn).put("sw", store.lang == "sw")
            .put("i", JSONObject()
                .put("feels", t("Feels like", "Inahisi"))
                .put("today", t("Today", "Leo"))
                .put("upd", t("updated ", "imesasishwa "))
                .put("old", t("old data", "data ya zamani"))
                .put("load", t("Loading weather…", "Inapakia hali ya hewa…"))
                .put("fail", t("Couldn't load the weather. Check your internet.", "Imeshindwa kupakia hali ya hewa. Angalia intaneti."))
                .put("setup", t("Weather is not set up on the server yet.", "Hali ya hewa haijawekwa kwenye seva bado."))
                .put("key", t("The weather key is invalid or not active yet (new keys can take up to 2 hours).", "Ufunguo wa hali ya hewa si sahihi au bado haujaamka (mpya huchukua hadi saa 2)."))
                .put("city", t("City not found. Change it in Settings > Weather.", "Mji haujapatikana. Ubadilishe kwenye Settings > Weather.")))
            .toString().replace("<", "\\u003c")

        // LIVE SCORES (taarifa za mpira tu) — inaonekana ikiwa proxy imewekwa
        val scoresSection = if (!store.scoresOn || store.scoresUrl.isEmpty()) "" else
            "<h2>LIVE SCORES<span id=lsu></span></h2><div class=stabs>" +
                "<button type=button class='stab on' data-t=live onclick=\"lsTab('live')\"></button>" +
                "<button type=button class=stab data-t=up onclick=\"lsTab('up')\"></button>" +
                "<button type=button class=stab data-t=fin onclick=\"lsTab('fin')\"></button></div>" +
                "<div id=ls class=ls></div>"
        val scArr = try {
            if (store.scoresDate == todayStr()) JSONArray(store.scoresJson) else JSONArray()
        } catch (e: Exception) { JSONArray() }
        val scInit = JSONObject()
            .put("m", scArr).put("at", store.scoresAtMs).put("err", scoresErr).put("cfg", scoresSection.isNotEmpty())
            .put("f", JSONArray(store.follows().keys.toList()))
            .put("srv", store.scoresSrvMs).put("stale", store.scoresStale)
            .put("tab", "live")
            .put("i", JSONObject()
                .put("live", "LIVE")
                .put("up", t("UPCOMING", "ZINAZOKUJA"))
                .put("fin", t("FINISHED", "ZIMEMALIZIKA"))
                .put("noLive", t("No matches are being played right now.", "Hakuna mechi zinazoendelea kwa sasa."))
                .put("noUp", t("No upcoming matches today.", "Hakuna mechi zinazokuja leo."))
                .put("noFin", t("No finished matches yet.", "Hakuna mechi zilizomalizika bado."))
                .put("fail", t("Couldn't load scores. Check your internet.", "Imeshindwa kupakia scores. Angalia intaneti."))
                .put("upd", t("updated ", "imesasishwa "))
                .put("off", t("offline", "nje ya mtandao"))
                .put("late", t("delayed data", "data ya zamani")))
            .toString().replace("<", "\\u003c")

        return """<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><meta name=color-scheme content=dark><title>Rahim Lux Go</title><style>
body{margin:0;min-height:100vh;background:radial-gradient(circle at 50% 10%,#2a2008 0%,#0B0B0D 60%);color:#fff;font-family:sans-serif;text-align:center;box-sizing:border-box}
.c{position:relative;z-index:1;padding:22px 16px 40px}
.f{position:fixed;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;z-index:0}
.f span{position:absolute;bottom:-60px;color:$acc;opacity:0;animation-name:up;animation-timing-function:linear;animation-iteration-count:infinite}
@keyframes up{0%{transform:translateY(0) rotate(0deg);opacity:0}12%{opacity:.22}85%{opacity:.18}100%{transform:translateY(-115vh) rotate(300deg);opacity:0}}
@keyframes in{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
.lg{width:84px;height:84px;border-radius:24px;margin:6px auto 0;display:flex;align-items:center;justify-content:center;font-size:38px;background:$acc;box-shadow:0 0 38px $glow}
img.lg{display:block;background:none;object-fit:cover}
h1{margin:14px 0 2px;font-size:28px}h1 span{color:$acc}
.hi{margin:0;color:#e9dfbf;font-size:14px;font-weight:600}
p{margin:2px 0 18px;color:#a8a290;font-size:13px}
.sb{display:flex;align-items:center;max-width:420px;margin:0 auto 6px;background:rgba(255,255,255,.07);border:1px solid rgba(255,179,0,.32);border-radius:28px;padding:4px 6px 4px 18px}
.sb input{flex:1;min-width:0;background:transparent;border:0;outline:0;color:#fff;font-size:16px;padding:12px 0}
.sb button{width:42px;height:42px;border-radius:21px;border:0;background:$acc;color:#000;font-size:18px}
h2{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#8d8775;text-align:left;max-width:420px;margin:22px auto 10px;padding-left:4px}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;max-width:420px;margin:0 auto}
.t{display:block;text-decoration:none;color:#ddd;font-size:11px;padding:12px 2px 9px;border-radius:20px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);animation:in .5s both}
.t:active{transform:scale(.95)}
.t i{display:block;position:relative;overflow:hidden;width:54px;height:54px;border-radius:17px;margin:0 auto 8px;line-height:54px;font-style:normal;font-size:22px;font-weight:700;color:#fff}
.t i img{position:absolute;left:0;top:0;width:100%;height:100%;box-sizing:border-box;padding:10px;object-fit:contain}
.t b{font-weight:500;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 3px}
.chips{display:flex;gap:8px;max-width:420px;margin:0 auto 12px;overflow-x:auto}
.chip{flex:none;white-space:nowrap;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.05);color:#ddd;border-radius:16px;padding:7px 14px;font-size:12px}
.chip.on{background:$acc;color:#000;border-color:$acc;font-weight:700}
.nl{max-width:420px;margin:0 auto}
.wx{max-width:420px;margin:0 auto;text-align:left;background:linear-gradient(135deg,rgba(255,179,0,.14),rgba(255,255,255,.04));border:1px solid rgba(255,179,0,.25);border-radius:22px;padding:14px 14px 10px}
.wxt{display:flex;align-items:center;gap:12px}
.wxi{font-size:44px;line-height:1}
.wxm{display:flex;flex-direction:column;min-width:0}
.wxm b{font-size:34px;line-height:1;color:#fff}
.wxm span{font-size:12px;color:#a8a290;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:130px}
.wxd{flex:1;text-align:right;font-size:12px;color:#a8a290}
.wxn{font-size:14px;color:#fff;font-weight:600;margin-bottom:3px}
.wxs{line-height:1.5}
.wxh{display:flex;gap:6px;margin-top:12px;overflow-x:auto}
.wxc{flex:1 0 46px;display:flex;flex-direction:column;align-items:center;gap:2px;background:rgba(255,255,255,.05);border-radius:12px;padding:6px 2px;font-size:11px;color:#a8a290}
.wxc em{font-style:normal;font-size:18px}.wxc b{color:#fff;font-size:13px}.wxc i{font-style:normal;font-size:9px;color:#6fb6ff}
.wxdays{margin-top:10px;border-top:1px solid rgba(255,255,255,.08);padding-top:6px}
.wxr{display:flex;align-items:center;gap:10px;padding:4px 2px;font-size:12px;color:#a8a290}
.wxr span{width:34px}.wxr em{font-style:normal;font-size:16px;width:24px}.wxr b{margin-left:auto;color:#fff;font-weight:600}
.wxe{color:#8d8775;font-size:13px;padding:10px 4px;text-align:center}
.stabs{display:flex;gap:8px;max-width:420px;margin:0 auto 10px}
.stab{flex:none;white-space:nowrap;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.05);color:#ddd;border-radius:14px;padding:6px 12px;font-size:11px}
.stab.on{background:$acc;color:#000;border-color:$acc;font-weight:700}
.ls{display:flex;gap:10px;overflow-x:auto;max-width:420px;margin:0 auto;padding-bottom:4px}
.mc{flex:0 0 150px;text-align:left;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:10px 12px}
.ml{font-size:10px;color:#8d8775;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:6px}
.mr{display:flex;justify-content:space-between;gap:8px;font-size:13px;line-height:1.55;color:#eee}
.mr .mt{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.mr b{color:#fff}
.mb{margin-top:6px;font-size:11px;color:#a8a290}
.mb.live{color:#ff5252;font-weight:700}
.lsempty{color:#8d8775;font-size:13px;padding:14px 4px;text-align:center;width:100%}
.empty{color:#8d8775;font-size:13px;padding:18px 4px;text-align:center}
.n{display:flex;align-items:center;gap:12px;text-align:left;text-decoration:none;color:#eee;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.07);border-radius:16px;padding:10px;margin:0 0 8px;animation:in .5s both}
.n .ph{position:relative;overflow:hidden;flex:0 0 84px;height:84px;border-radius:12px;background:linear-gradient(135deg,rgba(255,179,0,.35),rgba(255,255,255,.06))}
.n .ph em{position:absolute;left:0;right:0;top:50%;margin-top:-16px;font-style:normal;font-size:24px;font-weight:700;line-height:32px;color:rgba(255,255,255,.5);text-align:center}
.n .ph img{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:cover}
.n .tx{flex:1;min-width:0}
.n b{display:block;font-size:14px;font-weight:600;line-height:1.35}
.n span{display:block;margin-top:5px;font-size:11px;color:$acc}
.n.big{display:block;padding:0 0 12px;overflow:hidden}
.n.big .ph{width:100%;height:176px;border-radius:16px 16px 0 0}
.n.big .tx{padding:10px 14px 0}
.s{margin:26px auto 0;max-width:420px;background:rgba(30,30,34,.85);border:1px solid rgba(255,179,0,.25);border-radius:20px;padding:14px;display:flex;justify-content:space-around}
.s div{font-size:11px;color:#a8a290}.s strong{display:block;font-size:20px;color:#fff;margin-bottom:2px}
</style></head><body>
<div class=f>${floaters()}</div>
<div class=c>
$logo
<h1>Rahim Lux <span>Go</span></h1>
<div class=hi id=hi></div>
<p>$tag</p>
<form class=sb action='$sAction' method=get>$sHidden<input name='$sName' placeholder='$placeholder' autocomplete=off><button type=submit>&#128269;</button></form>
$favSection
$wxSection
$scoresSection
$betSection
$newsSection
<div class=s><div><strong>${store.blocked}</strong>$lBlocked</div><div><strong>$ds</strong>Data saver</div><div><strong>$ab</strong>Ad-block</div></div>
</div>
<script>var h=new Date().getHours();document.getElementById('hi').textContent=h<12?'$gm':h<18?'$ga':'$ge';function sh(k,b){var l=document.querySelectorAll('.nl');for(var i=0;i<l.length;i++){l[i].style.display=l[i].id=='n_'+k?'block':'none'}var c=document.querySelectorAll('.chip');for(var j=0;j<c.length;j++){c[j].classList.remove('on')}b.classList.add('on')}</script>
<script>var SC=$scInit;</script>
<script>${ScoresJs.CODE}</script>
<script>var WX=$wxInit;</script>
<script>${WeatherJs.CODE}</script>
</body></html>"""
    }

    // ---------------- Tab switcher ----------------

    private fun sheetWindow(d: Dialog) {
        d.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun showTabs() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = resources.getDrawable(R.drawable.bg_sheet, theme)
        root.setPadding(dp(16), dp(16), dp(16), dp(16))

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Tabs (${tabs.size})"
        title.setTextColor(Color.WHITE); title.textSize = 18f; title.setTypeface(null, Typeface.BOLD)
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val add = TextView(this)
        add.text = t("＋ New", "＋ Mpya")
        add.setTextColor(Color.BLACK); add.textSize = 13f; add.setTypeface(null, Typeface.BOLD)
        add.background = resources.getDrawable(R.drawable.bg_dl, theme)
        add.setPadding(dp(14), dp(8), dp(14), dp(8))
        add.setOnClickListener { d.dismiss(); newTab(home) }
        head.addView(add)
        root.addView(head)

        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        tabs.forEachIndexed { i, w ->
            val u = lazyUrls[w] ?: w.url ?: ""
            val isHome = u.isEmpty() || Uri.parse(u).host == homeHost
            val inc = w.tag == "inc"
            val name = if (isHome) "Home" else (w.title?.takeIf { it.isNotBlank() }?.take(40) ?: pretty(u))
            val sub = if (isHome) t("Start page", "Ukurasa wa mwanzo") else pretty(u)

            val card = LinearLayout(this)
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(dp(12), dp(12), dp(6), dp(12))
            card.background = resources.getDrawable(if (i == cur) R.drawable.bg_card_cur else R.drawable.bg_card, theme)

            val badge = TextView(this)
            badge.text = if (inc) "🕶" else if (isHome) "🏠" else pretty(u).take(1).uppercase().ifEmpty { "•" }
            badge.gravity = Gravity.CENTER; badge.textSize = 16f; badge.setTextColor(Color.WHITE)
            badge.background = resources.getDrawable(R.drawable.bg_icon, theme)
            card.addView(badge, LinearLayout.LayoutParams(dp(40), dp(40)))

            val info = LinearLayout(this)
            info.orientation = LinearLayout.VERTICAL
            val tt = TextView(this)
            tt.text = name; tt.setTextColor(Color.WHITE); tt.textSize = 14f; tt.setTypeface(null, Typeface.BOLD)
            tt.maxLines = 1; tt.ellipsize = TextUtils.TruncateAt.END
            val ss = TextView(this)
            ss.text = sub; ss.setTextColor(Color.parseColor("#8A8A94")); ss.textSize = 12f
            ss.maxLines = 1; ss.ellipsize = TextUtils.TruncateAt.END
            info.addView(tt); info.addView(ss)
            val ilp = LinearLayout.LayoutParams(0, -2, 1f)
            ilp.marginStart = dp(12)
            card.addView(info, ilp)

            val x = TextView(this)
            x.text = "✕"; x.setTextColor(Color.parseColor("#B0B0B8")); x.textSize = 16f
            x.setPadding(dp(12), dp(8), dp(12), dp(8))
            x.setOnClickListener {
                closeTabAt(i)
                d.dismiss()
                showTabs()
            }
            card.addView(x)
            card.setOnClickListener { d.dismiss(); show(i) }

            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(10)
            list.addView(card, lp)
        }
        scroll.addView(list)
        val slp = LinearLayout.LayoutParams(-1, -2)
        slp.topMargin = dp(6)
        root.addView(scroll, slp)

        d.setContentView(root)
        sheetWindow(d)
        d.show()
    }

    // ---------------- Menu ----------------

    private fun manageSites() {
        val s = store.sites()
        if (s.isEmpty()) { toast(t("Home has no sites", "Home haina tovuti")); return }
        val checked = BooleanArray(s.size)
        AlertDialog.Builder(this).setTitle(t("Select sites to remove", "Chagua tovuti za kuondoa"))
            .setMultiChoiceItems(s.map { it.first }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(t("Remove", "Ondoa")) { _, _ ->
                s.indices.filter { checked[it] }.forEach { store.removeSite(s[it].second) }
                toast(t("Removed", "Imeondolewa"))
                if (fullUrl.isEmpty()) web.reload()
            }
            .setNegativeButton(t("Cancel", "Ghairi"), null)
            .show()
    }

    private fun showMenu() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = layoutInflater.inflate(R.layout.sheet_menu, null)
        val statsView = root.findViewById<TextView>(R.id.stats)
        statsView.text = "🛡 ${store.blocked} " + t("blocked", "zimezuiwa") + " ›"
        statsView.setOnClickListener { d.dismiss(); showBlocked() }
        val grid = root.findViewById<GridLayout>(R.id.grid)

        fun cell(icon: String, label: String, on: Boolean? = null, action: () -> Unit) {
            val color = when (on) {
                true -> accent
                false -> Color.parseColor("#8A8A94")
                null -> Color.WHITE
            }
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(0, dp(10), 0, dp(10))
            val ic = TextView(this)
            ic.text = icon; ic.textSize = 22f; ic.gravity = Gravity.CENTER
            ic.background = resources.getDrawable(if (on == true) R.drawable.bg_icon_on else R.drawable.bg_icon, theme)
            val iclp = LinearLayout.LayoutParams(dp(50), dp(50))
            iclp.gravity = Gravity.CENTER_HORIZONTAL
            box.addView(ic, iclp)
            val lb = TextView(this)
            lb.text = label; lb.textSize = 11f; lb.gravity = Gravity.CENTER; lb.setTextColor(color)
            lb.setPadding(0, dp(6), 0, 0)
            box.addView(lb)
            box.setOnClickListener { d.dismiss(); action() }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            grid.addView(box, lp)
        }

        val curHost = web.url?.let { Uri.parse(it).host }
        val onSite = curHost != null && curHost != homeHost

        cell("➕", t("New tab", "Tab mpya")) { newTab(home) }
        cell("🕶", t("Private", "Faragha")) { newTab(home, true) }
        cell("✖️", t("Close tab", "Funga tab")) { closeTab() }
        cell("🔄", t("Reload", "Pakia upya")) { web.reload() }
        cell("🔍", t("Find in page", "Tafuta ukurasani")) {
            if (onSite) openFind() else toast(t("Open a website first", "Fungua tovuti kwanza"))
        }

        cell("⭐", "Bookmark") {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) {
                store.addBookmark(web.title ?: u, u); toast(t("Saved ⭐", "Imehifadhiwa ⭐"))
            }
        }
        cell("📚", "Bookmarks") { pick("Bookmarks", store.bookmarks()) }
        cell("🕘", "History") { pick("History", store.history()) }
        cell("⬇️", t("Downloads", "Vipakuliwa")) { startActivity(Intent(this, DownloadsActivity::class.java)) }

        cell("🛡️", "Ad-block", store.adblock) {
            store.adblock = !store.adblock
            web.reload()
            toast(if (store.adblock) t("Ad-block on", "Ad-block imewashwa") else t("Ad-block off", "Ad-block imezimwa"))
        }
        cell("🎯", t("This site", "Tovuti hii"), if (onSite) !store.isAdOff(curHost) else null) {
            if (!onSite || curHost == null) toast(t("Open a website first", "Fungua tovuti kwanza"))
            else {
                val off = store.toggleAdOff(curHost)
                web.reload()
                val site = curHost.removePrefix("www.")
                toast(if (off) t("Ad-block off for $site", "Ad-block imezimwa kwa $site") else t("Ad-block on for $site", "Ad-block imewashwa kwa $site"))
            }
        }
        cell("📉", "Data saver", store.dataSaver) {
            store.dataSaver = !store.dataSaver
            tabs.forEach { w -> w.settings.blockNetworkImage = store.dataSaver }
            web.reload()
            toast(if (store.dataSaver) t("Data saver on", "Data saver imewashwa") else t("Data saver off", "Data saver imezimwa"))
        }
        cell("🌙", "Dark web", store.darkWeb) {
            store.darkWeb = !store.darkWeb
            tabs.forEach { w -> applyDark(w) }
            web.reload()
            toast(if (store.darkWeb) t("Dark mode on", "Dark mode imewashwa") else t("Dark mode off", "Dark mode imezimwa"))
        }

        cell("🖥️", "Desktop site", store.desktop) {
            store.desktop = !store.desktop
            tabs.forEach { w -> applyDesktop(w) }
            web.reload()
            toast(if (store.desktop) t("Desktop site on", "Desktop site imewashwa") else t("Desktop site off", "Desktop site imezimwa"))
        }
        cell("🍪", "3rd-party cookies", store.thirdCookies) {
            store.thirdCookies = !store.thirdCookies
            tabs.forEach { w -> CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.thirdCookies) }
            web.reload()
            toast(if (store.thirdCookies) t("3rd-party cookies on (logins work better)", "Cookies za third-party zimewashwa")
            else t("3rd-party cookies off (more private)", "Cookies za third-party zimezimwa"))
        }
        cell("🎤", t("Voice: ", "Sauti: ") + (if (store.voiceLang == "sw") "Swahili" else "English")) {
            store.voiceLang = if (store.voiceLang == "sw") "en" else "sw"
            toast(if (store.voiceLang == "sw") t("Voice search: Swahili", "Voice search: Kiswahili") else t("Voice search: English", "Voice search: Kiingereza"))
        }
        cell("🔎", t("Search engine", "Injini ya kutafuta")) { pickEngine() }
        cell("🌐", "English / Swahili") {
            store.lang = if (store.lang == "sw") "en" else "sw"
            news = listOf()
            cats.clear()
            loadNews()
            updateHint()
            if (fullUrl.isEmpty()) web.reload()
            toast(if (store.lang == "sw") "Lugha: Kiswahili" else "Language: English")
        }

        cell("🏠", t("Add to Home", "Ongeza Home")) {
            val u = web.url
            if (u != null && Uri.parse(u).host != homeHost) {
                store.addSite((web.title ?: pretty(u)).take(14), u)
                toast(t("Added to Home", "Imeongezwa kwenye Home"))
            } else toast(t("Open a website first", "Fungua tovuti kwanza"))
        }
        cell("✏️", t("Edit Home", "Dhibiti Home")) { manageSites() }
        cell("🔁", t("Update list", "Sasisha list")) {
            toast(t("Updating ad list…", "Inasasisha ad-list…"))
            Thread {
                val n = AdBlock.update()
                runOnUiThread {
                    toast(if (n > 0) t("Ad list updated: $n domains", "Ad-list imesasishwa: $n domains")
                    else t("Update failed, try again", "Imeshindwa, jaribu tena"))
                }
            }.start()
        }
        cell("🚫", t("Blocked", "Zilizozuiwa")) { showBlocked() }

        cell("🔗", "Share") {
            if (fullUrl.isNotEmpty()) {
                val s = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, fullUrl) }
                startActivity(Intent.createChooser(s, t("Share via", "Tuma kupitia")))
            }
        }
        cell("🗑️", t("Clear data", "Futa data")) {
            store.clearHistory()
            store.clearSearches()
            tabs.forEach { w -> w.clearCache(true); w.clearHistory() }
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            toast(t("Data cleared", "Data imefutwa"))
        }

        val unread = Notif.unread(store)
        cell("🔔", t("Notifications", "Arifa") + if (unread > 0) " ($unread)" else "", if (unread > 0) true else null) {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }
        cell("⚙️", t("Settings", "Mipangilio")) {
            langAtOpen = store.lang
            settingsLauncher.launch(Intent(this, SettingsActivity::class.java))
        }

        d.setContentView(root)
        sheetWindow(d)
        d.show()
    }

    private fun showBlocked() {
        val l = BlockLog.top()
        if (l.isEmpty()) { toast(t("Nothing blocked yet", "Hakuna kilichozuiwa bado")); return }
        AlertDialog.Builder(this).setTitle("🚫 " + t("Blocked", "Zilizozuiwa") + " (${store.blocked})")
            .setItems(l.map { "${it.first}  ×${it.second}" }.toTypedArray(), null)
            .setPositiveButton(t("Close", "Funga"), null)
            .setNeutralButton(t("Clear list", "Futa orodha")) { _, _ ->
                BlockLog.clear(); store.resetBlocked(); store.blockLogJson = "{}"
                toast(t("Cleared", "Imefutwa"))
            }.show()
    }

    private fun pick(title: String, items: List<Pair<String, String>>) {
        if (items.isEmpty()) { toast(t("Nothing here yet", "Hakuna kitu bado")); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(items.map { it.first.take(40) + "\n" + it.second.take(50) }.toTypedArray()) { _, i ->
                web.loadUrl(items[i].second)
            }.show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- Lifecycle ----------------

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        adView.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        adView.resume()
        Push.syncTopics(this)
        handler.postDelayed(poll, 2500)
        if (System.currentTimeMillis() - newsAt > 30 * 60 * 1000) { newsAt = System.currentTimeMillis(); loadNews() }
        if (tabs.isNotEmpty() && fullUrl.isEmpty() && lazyUrls[web] == null &&
            System.currentTimeMillis() - lastNav > 4000) web.loadUrl(home)
    }

    override fun onStop() {
        store.blockLogJson = BlockLog.toJson()
        saveTabs()
        super.onStop()
    }

    override fun onDestroy() {
        try { unregisterReceiver(dlReceiver) } catch (e: Exception) { }
        exitFullscreen()
        adView.destroy()
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
