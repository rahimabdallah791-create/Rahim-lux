package com.rahimlux.go

/** JavaScript ya kadi ya hali ya hewa kwenye Home. Data inaingia kupitia textContent (si innerHTML). */
object WeatherJs {
    const val CODE = """
function wxEl(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined&&x!==null)e.textContent=x;return e}
function wxEmoji(id,icon){var n=icon&&icon.charAt(icon.length-1)==='n';
 if(id>=200&&id<300)return '\u26c8\ufe0f';
 if(id>=300&&id<400)return '\ud83c\udf26\ufe0f';
 if(id>=500&&id<600){if(id===511)return '\ud83c\udf28\ufe0f';return (id<=501&&!n)?'\ud83c\udf26\ufe0f':'\ud83c\udf27\ufe0f'}
 if(id>=600&&id<700)return '\u2744\ufe0f';
 if(id>=700&&id<800)return '\ud83c\udf2b\ufe0f';
 if(id===800)return n?'\ud83c\udf19':'\u2600\ufe0f';
 if(id===801)return n?'\u2601\ufe0f':'\ud83c\udf24\ufe0f';
 if(id===802)return n?'\u2601\ufe0f':'\u26c5';
 return '\u2601\ufe0f'}
function wxDesc(id){var s=WX.sw;
 if(id>=200&&id<300)return s?'Radi na mvua':'Thunderstorm';
 if(id>=300&&id<400)return s?'Manyunyu':'Drizzle';
 if(id===500||id===501)return s?'Mvua nyepesi':'Light rain';
 if(id>=500&&id<600)return id===511?(s?'Mvua ya barafu':'Freezing rain'):(s?'Mvua kubwa':'Heavy rain');
 if(id>=600&&id<700)return s?'Theluji':'Snow';
 if(id>=700&&id<800)return s?'Ukungu':'Mist';
 if(id===800)return s?'Anga safi':'Clear sky';
 if(id===801||id===802)return s?'Mawingu kiasi':'Partly cloudy';
 return s?'Mawingu':'Cloudy'}
function wxHm(ts){var d=new Date(ts);var h=d.getHours(),m=d.getMinutes();return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
function wxRender(){
 var box=document.getElementById('wx');if(!box||!WX.cfg)return;
 var d=WX.d||{},n=d.now,u=document.getElementById('wxu');
 box.innerHTML='';
 if(!n){var msg=(WX.err==='not_configured')?WX.i.setup:(WX.err==='invalid_api_key')?WX.i.key:(WX.err==='city_not_found')?WX.i.city:(WX.err?WX.i.fail:WX.i.load);box.appendChild(wxEl('div','wxe',msg));if(u)u.textContent='';return}
 if(u){var t0=d.srv>0?d.srv:WX.at;var s='';if(t0>0){s=' \u00b7 '+WX.i.upd+wxHm(t0)}if(d.stale)s+=' \u00b7 \u26a0 '+WX.i.old;u.textContent=s}
 var top=wxEl('div','wxt');
 top.appendChild(wxEl('div','wxi',wxEmoji(n.id,n.icon)));
 var tt=wxEl('div','wxm');tt.appendChild(wxEl('b','',n.t+'\u00b0'));tt.appendChild(wxEl('span','',(d.city||'')+(d.country?', '+d.country:'')));top.appendChild(tt);
 var dd=wxEl('div','wxd');dd.appendChild(wxEl('div','wxn',wxDesc(n.id)));
 dd.appendChild(wxEl('div','wxs',WX.i.feels+' '+n.feels+'\u00b0'));
 dd.appendChild(wxEl('div','wxs','\ud83d\udca7 '+n.hum+'%  \ud83d\udca8 '+n.wind+' km/h'));
 top.appendChild(dd);box.appendChild(top);
 var hs=wxEl('div','wxh');
 (d.hourly||[]).slice(0,6).forEach(function(h){var c=wxEl('div','wxc');c.appendChild(wxEl('span','',wxHm(h.ts)));c.appendChild(wxEl('em','',wxEmoji(h.id,h.icon)));c.appendChild(wxEl('b','',h.t+'\u00b0'));if(h.pop>=30)c.appendChild(wxEl('i','','\ud83d\udca7'+h.pop+'%'));hs.appendChild(c)});
 box.appendChild(hs);
 var ds=wxEl('div','wxdays');
 (d.daily||[]).slice(0,4).forEach(function(x,i){var p=x.d.split('-');var dt=new Date(+p[0],+p[1]-1,+p[2]);var nm=WX.sw?['Jpl','Jtt','Jnn','Jtn','Alh','Ijm','Jms']:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];var r=wxEl('div','wxr');r.appendChild(wxEl('span','',i===0?WX.i.today:nm[dt.getDay()]));r.appendChild(wxEl('em','',wxEmoji(x.id,'d')));r.appendChild(wxEl('b','',x.min+'\u00b0 / '+x.max+'\u00b0'));ds.appendChild(r)});
 box.appendChild(ds);
}
window.setWeather=function(p){WX.d=p.d||{};WX.at=p.at||0;WX.err=p.err||'';wxRender()};
wxRender();
"""
}
