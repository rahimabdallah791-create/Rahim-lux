package com.rahimlux.go

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Hali ya hewa: inasoma kutoka seva yako (ufunguo wa OpenWeather uko kwenye seva, si ndani ya app). */
object Weather {
    class Result(val json: String?, val error: String?)

    private val dateRe = Regex("""^\d{4}-\d{2}-\d{2}$""")
    private fun clean(s: String?, max: Int): String = (s ?: "").filter { !it.isISOControl() }.trim().take(max)

    /** Tumia kwenye background thread. Inarudisha data iliyosafishwa. */
    fun fetch(base: String, token: String, city: String): Result {
        var c: HttpURLConnection? = null
        return try {
            val q = if (city.isNotBlank()) "?q=" + URLEncoder.encode(city.trim(), "UTF-8") else ""
            val url = base.trim().trimEnd('/') + "/weather" + q
            if (!url.startsWith("https://")) return Result(null, "bad_url")
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/json")
            if (token.isNotEmpty()) c.setRequestProperty("X-App-Token", token)
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (body.length > 500_000) return Result(null, "too_large")
            val o = JSONObject(body)
            if (!o.optBoolean("ok", false)) return Result(null, o.optString("error", "bad_response"))
            val now = o.optJSONObject("now") ?: return Result(null, "bad_response")
            val srv = try { java.time.Instant.parse(o.optString("updated")).toEpochMilli() } catch (e: Exception) { 0L }
            val out = JSONObject()
            out.put("city", clean(o.optString("city"), 40))
            out.put("country", clean(o.optString("country"), 3))
            out.put("srv", srv)
            out.put("stale", o.optBoolean("stale", false))
            out.put(
                "now",
                JSONObject().put("t", now.optInt("t")).put("feels", now.optInt("feels")).put("hum", now.optInt("hum"))
                    .put("wind", now.optInt("wind")).put("id", now.optInt("id")).put("icon", clean(now.optString("icon"), 4))
            )
            val hourly = JSONArray()
            val hs = o.optJSONArray("hourly")
            for (i in 0 until minOf(hs?.length() ?: 0, 8)) {
                val h = hs!!.optJSONObject(i) ?: continue
                hourly.put(
                    JSONObject().put("ts", h.optLong("ts")).put("t", h.optInt("t")).put("id", h.optInt("id"))
                        .put("icon", clean(h.optString("icon"), 4)).put("pop", h.optInt("pop"))
                )
            }
            out.put("hourly", hourly)
            val daily = JSONArray()
            val ds = o.optJSONArray("daily")
            for (i in 0 until minOf(ds?.length() ?: 0, 5)) {
                val d = ds!!.optJSONObject(i) ?: continue
                val day = d.optString("d")
                if (!dateRe.matches(day)) continue
                daily.put(JSONObject().put("d", day).put("min", d.optInt("min")).put("max", d.optInt("max")).put("id", d.optInt("id")))
            }
            out.put("daily", daily)
            Result(out.toString(), null)
        } catch (e: Exception) {
            Result(null, "network")
        } finally {
            c?.disconnect()
        }
    }
}
