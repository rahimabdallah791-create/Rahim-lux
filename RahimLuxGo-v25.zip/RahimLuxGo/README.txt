RAHIM LUX GO v25 - Android browser (Kotlin + WebView)
Mpya v25: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
