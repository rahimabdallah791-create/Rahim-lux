package com.rahimlux.go

import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Mfumo wa arifa: channels, kuchuja kwa mipangilio, dedupe, historia (Notification Center) na kuonyesha.
 * Data zote ni za ndani ya simu (SharedPreferences ya app). Hakuna siri yoyote ndani ya app.
 */
object Notif {
    const val CH_GENERAL = "general"
    const val CH_LIVE = "football_live"
    const val CH_GOALS = "football_goals"
    const val CH_NEWS = "news"
    const val CH_DOWNLOADS = "downloads"
    const val CH_ANN = "announcements"
    const val CH_ACCOUNT = "account"
    const val CH_TEST = "test"

    val CHANNELS = listOf(CH_GENERAL, CH_LIVE, CH_GOALS, CH_NEWS, CH_DOWNLOADS, CH_ANN, CH_ACCOUNT, CH_TEST)

    class Item(
        val id: String, val ts: Long, val type: String, val title: String, val body: String,
        val dest: String, val arg: String, val image: String, var read: Boolean
    )

    private fun t(s: Store, en: String, sw: String) = if (s.lang == "sw") sw else en

    fun channelName(s: Store, id: String): String = when (id) {
        CH_GENERAL -> t(s, "General", "Jumla")
        CH_LIVE -> t(s, "Football live scores", "Football live scores")
        CH_GOALS -> t(s, "Football goals", "Magoli ya mpira")
        CH_NEWS -> t(s, "News / Breaking news", "Habari / Habari za haraka")
        CH_DOWNLOADS -> t(s, "Downloads", "Vipakuliwa")
        CH_ANN -> t(s, "App announcements", "Matangazo ya app")
        CH_TEST -> t(s, "Test notifications", "Arifa za majaribio")
        else -> t(s, "Account & security", "Akaunti na usalama")
    }

    /** Inaweza kuitwa mara nyingi (idempotent). Pia inasasisha majina ya channels lugha ikibadilika. */
    fun ensureChannels(ctx: Context, s: Store) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val spec = listOf(
            CH_GENERAL to NotificationManager.IMPORTANCE_DEFAULT,
            CH_LIVE to NotificationManager.IMPORTANCE_DEFAULT,
            CH_GOALS to NotificationManager.IMPORTANCE_HIGH,
            CH_NEWS to NotificationManager.IMPORTANCE_DEFAULT,
            CH_DOWNLOADS to NotificationManager.IMPORTANCE_LOW,
            CH_ANN to NotificationManager.IMPORTANCE_DEFAULT,
            CH_ACCOUNT to NotificationManager.IMPORTANCE_HIGH,
            CH_TEST to NotificationManager.IMPORTANCE_HIGH
        )
        for ((id, imp) in spec) nm.createNotificationChannel(NotificationChannel(id, channelName(s, id), imp))
    }

    fun channelFor(d: Map<String, String>): String = when (d["type"]) {
        "football" -> if (d["event"] == "goal") CH_GOALS else CH_LIVE
        "news" -> CH_NEWS
        "announcement" -> CH_ANN
        "security" -> CH_ACCOUNT
        "download" -> CH_DOWNLOADS
        "test" -> CH_TEST
        else -> CH_GENERAL
    }

    // ---------------- Historia (Notification Center) ----------------

    @Synchronized
    fun history(s: Store): MutableList<Item> {
        val out = mutableListOf<Item>()
        try {
            val a = JSONArray(s.nHistJson)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Item(
                        o.getString("id"), o.optLong("ts"), o.optString("ty"), o.optString("t"), o.optString("b"),
                        o.optString("d"), o.optString("a"), o.optString("im"), o.optBoolean("r")
                    )
                )
            }
        } catch (e: Exception) { }
        return out
    }

    @Synchronized
    private fun save(s: Store, l: List<Item>) {
        val a = JSONArray()
        l.take(200).forEach {
            a.put(
                JSONObject().put("id", it.id).put("ts", it.ts).put("ty", it.type).put("t", it.title).put("b", it.body)
                    .put("d", it.dest).put("a", it.arg).put("im", it.image).put("r", it.read)
            )
        }
        s.nHistJson = a.toString()
    }

    @Synchronized
    fun add(s: Store, n: Item) {
        val l = history(s)
        l.removeAll { it.id == n.id }
        l.add(0, n)
        save(s, l)
    }

    fun unread(s: Store): Int = history(s).count { !it.read }

    @Synchronized
    fun markRead(s: Store, id: String) {
        val l = history(s)
        l.firstOrNull { it.id == id }?.read = true
        save(s, l)
    }

    @Synchronized
    fun markAllRead(s: Store) {
        val l = history(s)
        l.forEach { it.read = true }
        save(s, l)
    }

    @Synchronized
    fun delete(s: Store, id: String) {
        val l = history(s)
        l.removeAll { it.id == id }
        save(s, l)
    }

    @Synchronized
    fun clearAll(s: Store) { s.nHistJson = "[]" }

    // ---------------- Dedupe ----------------

    @Synchronized
    private fun isSeen(s: Store, id: String): Boolean {
        return try {
            val a = JSONArray(s.nSeenJson)
            (0 until a.length()).any { a.getString(it) == id }
        } catch (e: Exception) { false }
    }

    @Synchronized
    private fun markSeen(s: Store, id: String) {
        val l = try {
            val a = JSONArray(s.nSeenJson)
            (0 until a.length()).map { a.getString(it) }.toMutableList()
        } catch (e: Exception) { mutableListOf() }
        l.add(id)
        s.nSeenJson = JSONArray(l.takeLast(300)).toString()
    }

    // ---------------- Kuchuja kwa mipangilio ya mtumiaji ----------------

    private fun newsCat(s: Store, cat: String?): Boolean = when (cat) {
        "breaking" -> s.nNewsBreaking
        "tanzania" -> s.nNewsTz
        "sports" -> s.nNewsSports
        "football" -> s.nNewsFootball
        "technology" -> s.nNewsTech
        else -> true
    }

    fun allowed(s: Store, d: Map<String, String>): Boolean {
        if (!s.nAll) return false
        return when (d["type"]) {
            "football" -> {
                if (!s.nFootball) return false
                val ev = d["event"] ?: ""
                if (ev == "goal" && !s.nGoals) return false
                if (d["scope"] == "match") {
                    val f = s.getFollow(d["match_id"] ?: "") ?: return false
                    ev == "status" || ev in f.events
                } else true
            }
            "news" -> s.nNews && newsCat(s, d["cat"])
            "announcement" -> s.nAnnounce
            "security" -> s.nSecurity
            "download" -> s.nDownloads
            else -> true
        }
    }

    // ---------------- Maandishi (yanatengenezwa kwa lugha ya mtumiaji) ----------------

    fun compose(s: Store, d: Map<String, String>): Pair<String, String> {
        val h = d["h"]
        val a = d["a"]
        val ev = d["event"]
        if (d["type"] == "football" && ev != null && h != null && a != null) {
            val sw = s.lang == "sw"
            val hg = d["hg"] ?: "0"
            val ag = d["ag"] ?: "0"
            val score = "$h $hg–$ag $a"
            val title = when (ev) {
                "goal" -> (if (sw) "⚽ GOLI! " else "⚽ GOAL! ") + score
                "start" -> (if (sw) "▶ Mechi imeanza: " else "▶ Kick-off: ") + "$h vs $a"
                "ht" -> (if (sw) "⏸ Mapumziko: " else "⏸ Half-time: ") + score
                "ft" -> (if (sw) "🏁 Mechi imekwisha: " else "🏁 Full-time: ") + score
                "et" -> (if (sw) "⏱ Muda wa ziada: " else "⏱ Extra time: ") + score
                "pen" -> (if (sw) "🥅 Penalti: " else "🥅 Penalties: ") + score
                "status" -> "$h vs $a: " + when (d["st"]) {
                    "PST" -> if (sw) "imeahirishwa" else "postponed"
                    "CANC", "ABD" -> if (sw) "imefutwa" else "cancelled"
                    "SUSP" -> if (sw) "imesimamishwa" else "suspended"
                    else -> d["st"] ?: ""
                }
                else -> d["title"] ?: "$h vs $a"
            }
            val min = d["min"] ?: ""
            val parts = mutableListOf<String>()
            (d["lg"] ?: "").takeIf { it.isNotEmpty() }?.let { parts.add(it) }
            if (ev == "goal" && min.isNotEmpty()) parts.add(if (sw) "Dakika $min" else "$min'")
            return title to parts.joinToString(" · ")
        }
        var body = d["body"] ?: ""
        if (d["type"] == "test") {
            // Muda wa kufika: saa ya seva (sent_at) hadi saa ya simu. Saa za simu zikitofautiana sana, hatuonyeshi.
            val sent = d["sent_at"]?.toLongOrNull()
            if (sent != null) {
                val ms = System.currentTimeMillis() - sent
                if (ms in 0..600_000L) {
                    val txt = if (ms < 1000) "$ms ms" else String.format(Locale.US, "%.1f s", ms / 1000.0)
                    body += (if (body.isEmpty()) "" else "\n") + "⏱ " + txt + (if (s.lang == "sw") " (muda wa kufika)" else " delivery time")
                }
            }
        }
        return (d["title"]?.takeIf { it.isNotBlank() } ?: "Rahim Lux Go") to body
    }

    // ---------------- Deep links ----------------

    /** "rlg://match/123", "rlg://notifications", au https://... -> (dest, arg). Haikubali kingine chochote. */
    fun parseLink(link: String?): Pair<String, String> {
        if (link.isNullOrBlank()) return "" to ""
        if (link.startsWith("rlg://")) {
            val parts = link.removePrefix("rlg://").split("/").filter { it.isNotEmpty() }
            return when (parts.firstOrNull()) {
                "match" -> {
                    val id = parts.getOrNull(1) ?: ""
                    if (id.isNotEmpty() && id.length <= 12 && id.all { it.isDigit() }) "match" to id else "" to ""
                }
                "notifications", "downloads", "settings" -> parts[0] to ""
                "announcement" -> "notifications" to ""
                else -> "" to ""
            }
        }
        val u = LinkParser.safeUrl(link) ?: return "" to ""
        return "url" to u
    }

    fun destOf(d: Map<String, String>): Pair<String, String> {
        val l = parseLink(d["link"])
        if (l.first.isNotEmpty()) return l
        return when (d["type"]) {
            "football" -> {
                val id = d["match_id"] ?: ""
                if (id.isNotEmpty() && id.length <= 12 && id.all { it.isDigit() }) "match" to id else "" to ""
            }
            "news" -> parseLink(d["url"])
            "download" -> "downloads" to ""
            "announcement", "security", "general", "test" -> "notifications" to ""
            else -> "" to ""
        }
    }

    /** Intent inayofungua destination sahihi ndani ya Rahim Lux Go (MainActivity inaipitisha). */
    fun openIntent(ctx: Context, n: Item): Intent =
        Intent(ctx, MainActivity::class.java).apply {
            action = "rlg.open." + n.id
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("rlg_dest", n.dest.ifEmpty { "notifications" })
            putExtra("rlg_arg", n.arg)
            putExtra("rlg_nid", n.id)
        }

    // ---------------- Kuonyesha ----------------

    /** Inaitwa na FCM service (app wazi, background au imefungwa). Inachuja, inazuia duplicate, inahifadhi na kuonyesha. */
    @Synchronized
    fun handleIncoming(ctx: Context, d: Map<String, String>, force: Boolean = false) {
        val s = Store(ctx)
        val id = d["id"] ?: System.currentTimeMillis().toString()
        // "test" iliyotumwa moja kwa moja kwa token ya simu hii inapita swichi (mtumiaji ameomba); ya topic haipiti kamwe
        val bypass = force || (d["type"] == "test" && d["_direct"] == "1")
        if (!bypass) {
            if (isSeen(s, id)) return
            if (!allowed(s, d)) return
        }
        markSeen(s, id)
        val (title, body) = compose(s, d)
        val (dest, arg) = destOf(d)
        val img = d["image"]?.takeIf { it.startsWith("https://") } ?: ""
        val n = Item(id, System.currentTimeMillis(), d["type"] ?: "general", title, body, dest, arg, img, false)
        add(s, n)
        show(ctx, s, n, channelFor(d))
    }

    fun show(ctx: Context, s: Store, n: Item, channel: String) {
        ensureChannels(ctx, s)
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) return
        val nid = n.id.hashCode() and 0x7fffffff
        val pi = PendingIntent.getActivity(
            ctx, nid, openIntent(ctx, n), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_rlg)
            .setColor(Color.parseColor("#FFB300"))
            .setContentTitle(n.title)
            .setContentText(n.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(n.body))
            .setContentIntent(pi)
            .setAutoCancel(true)
        val bmp = if (n.image.isNotEmpty()) fetchBitmap(n.image) else null
        if (bmp != null) {
            b.setLargeIcon(bmp)
            b.setStyle(NotificationCompat.BigPictureStyle().bigPicture(bmp).setSummaryText(n.body))
        }
        try {
            NotificationManagerCompat.from(ctx).notify(nid, b.build())
        } catch (e: SecurityException) { }
    }

    private fun fetchBitmap(url: String): Bitmap? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 4000
            val bytes = c.inputStream.use { it.readBytes() }
            if (bytes.size > 3_000_000) return null
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            if (bmp.width > 1024) Bitmap.createScaledBitmap(bmp, 1024, bmp.height * 1024 / bmp.width, true) else bmp
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    /** Arifa ya majaribio kwenye simu hii (inapita kanuni zote isipokuwa ruhusa ya mfumo). */
    fun test(ctx: Context) {
        val s = Store(ctx)
        handleIncoming(
            ctx,
            mapOf(
                "id" to "test-" + System.currentTimeMillis(), "type" to "test", "title" to "Rahim Lux Go",
                "body" to t(s, "Test notification works ✅", "Arifa ya majaribio inafanya kazi ✅")
            ),
            force = true
        )
    }

    /** Download ikikamilika/ikishindwa: weka kwenye Notification Center (arifa ya mfumo inaonyeshwa na DownloadManager yenyewe). */
    fun recordDownload(ctx: Context, dlId: Long) {
        val s = Store(ctx)
        if (!s.nDownloads) return
        try {
            val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.query(DownloadManager.Query().setFilterById(dlId)).use { c ->
                if (!c.moveToFirst()) return
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "file"
                val ok = status == DownloadManager.STATUS_SUCCESSFUL
                if (!ok && status != DownloadManager.STATUS_FAILED) return
                val title = if (ok) t(s, "Download complete", "Upakuaji umekamilika") else t(s, "Download failed", "Upakuaji umeshindwa")
                add(s, Item("dl-$dlId", System.currentTimeMillis(), "download", title, name, "downloads", "", "", false))
            }
        } catch (e: Exception) { }
    }
}
