// Rahim Lux Go — Server (Cloudflare Worker)
// 1) GET  /scores            Live scores (API-Football) kwa app
// 2) POST /device, /device/delete, /test      usajili wa push (hash tu, token haihifadhiwi) + test push
// 3) scheduled (Cron)        football events + news -> FCM topics (server-side, app haihitaji kuwa wazi)
// 4) GET  /admin, POST /admin/send            kutuma announcement kwa topics
//
// Secrets / variables (Worker > Settings > Variables and Secrets):
//   FOOTBALL_API_KEY     (secret)  ufunguo wa API-Football
//   FCM_SERVICE_ACCOUNT  (secret)  JSON nzima ya Firebase service account (kwa kutuma push) — usiiweke kwenye app wala GitHub
//   ADMIN_TOKEN          (secret)  nenosiri la /admin
//   APP_TOKEN            (hiari)   app itume X-App-Token hii
//   LEAGUES              (hiari)   ligi za /scores, mfano "39,140,135"
//   LEAGUES_TOP          (hiari)   ligi zinazotuma push za jumla (football / football_goals)
//   TIMEZONE, LIVE_TTL, IDLE_TTL, FOOTBALL_POLL_SECS (120), FOOTBALL_IDLE_SECS (1800),
//   FOOTBALL_DAILY_BUDGET (60), NEWS_POLL_SECS (600)
//   KV Free: writes 1,000/siku -> weka FOOTBALL_POLL_SECS angalau 300 kwenye mpango wa bure
// Binding: KV namespace  STATE  (inapendekezwa; bila hiyo dedupe ni ya muda mfupi tu)
// Cron Trigger: "* * * * *"

const LIVE = new Set(["1H", "HT", "2H", "ET", "BT", "P", "LIVE", "INT"]);
const memo = new Map();
const mem = new Map();
const enc = new TextEncoder();
const TOP_DEFAULT = "39,140,135,78,61,2,3,848,12,6,1,4,5,567"; // thibitisha id za ligi unazotaka kupitia API-Football

function reply(obj, status, ttl) {
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": ttl ? "public, max-age=" + ttl : "no-store",
      "access-control-allow-origin": "*",
      "x-content-type-options": "nosniff",
    },
  });
}
const kv = (env) => ({
  async get(k) {
    if (env.STATE) return env.STATE.get(k);
    const e = mem.get(k);
    return e && e.exp > Date.now() ? e.v : null;
  },
  async put(k, v, ttl) {
    const t = Math.max(60, ttl || 604800);
    if (env.STATE) return env.STATE.put(k, v, { expirationTtl: t });
    mem.set(k, { v: v, exp: Date.now() + t * 1000 });
  },
  async del(k) {
    if (env.STATE) return env.STATE.delete(k);
    mem.delete(k);
  },
});
function ctEq(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
const appOk = (request, env) => !env.APP_TOKEN || ctEq(request.headers.get("X-App-Token") || "", env.APP_TOKEN);
async function sha(s) {
  const d = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function b64url(bytes) {
  const u = new Uint8Array(bytes);
  let s = "";
  for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function pemToDer(pem) {
  const s = atob(pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, ""));
  const u = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
  return u.buffer;
}

// ---------- FCM (HTTP v1) ----------
let tokCache = { v: "", exp: 0 };
async function accessToken(sa) {
  if (tokCache.v && tokCache.exp > Date.now() + 60000) return tokCache.v;
  const now = Math.floor(Date.now() / 1000);
  const head = b64url(enc.encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const claim = b64url(enc.encode(JSON.stringify({
    iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600,
  })));
  const key = await crypto.subtle.importKey("pkcs8", pemToDer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(head + "." + claim));
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: "grant_type=" + encodeURIComponent("urn:ietf:params:oauth:grant-type:jwt-bearer") + "&assertion=" + head + "." + claim + "." + b64url(sig),
  });
  if (!r.ok) throw new Error("oauth " + r.status);
  const j = await r.json();
  tokCache = { v: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return tokCache.v;
}
// opts (hiari): { notification: {title, body}, channel: "id" }  -> "notification message" (inafika hata simu za OEM zinazozuia data messages)
async function sendFcm(env, target, data, ttl, opts) {
  const t0 = Date.now();
  if (!env.FCM_SERVICE_ACCOUNT) return { ok: false, status: 0, text: "fcm_not_configured", ms: { total: 0 } };
  try {
    const sa = JSON.parse(env.FCM_SERVICE_ACCOUNT);
    const at = await accessToken(sa);
    const t1 = Date.now();
    const dd = {};
    for (const k in data) if (data[k] !== undefined && data[k] !== null) dd[k] = String(data[k]);
    const android = { priority: "HIGH", ttl: (ttl || 3600) + "s" };
    if (opts && opts.channel) android.notification = { channel_id: opts.channel };
    const message = Object.assign({}, target, { data: dd, android: android });
    if (opts && opts.notification) message.notification = opts.notification;
    const r = await fetch("https://fcm.googleapis.com/v1/projects/" + sa.project_id + "/messages:send", {
      method: "POST",
      headers: { authorization: "Bearer " + at, "content-type": "application/json" },
      body: JSON.stringify({ message: message }),
    });
    const t2 = Date.now();
    return { ok: r.ok, status: r.status, text: r.ok ? "" : (await r.text()).slice(0, 300), ms: { oauth: t1 - t0, send: t2 - t1, total: t2 - t0 } };
  } catch (e) {
    return { ok: false, status: 0, text: String(e && e.message || e).slice(0, 200), ms: { total: Date.now() - t0 } };
  }
}
const sendTopic = (env, topic, data, ttl) => sendFcm(env, { topic: topic }, data, ttl);

// ---------- /scores ----------
async function getScores(env, date) {
  const tz = env.TIMEZONE || "Africa/Dar_es_Salaam";
  const liveTtl = Math.max(15, parseInt(env.LIVE_TTL || "60", 10) || 60);
  const idleTtl = Math.max(60, parseInt(env.IDLE_TTL || "600", 10) || 600);
  const hit = memo.get(date);
  if (hit && hit.exp > Date.now()) return { body: hit.body, ttl: Math.max(1, Math.round((hit.exp - Date.now()) / 1000)) };
  try {
    const up = await fetch("https://v3.football.api-sports.io/fixtures?date=" + date + "&timezone=" + encodeURIComponent(tz),
      { headers: { "x-apisports-key": env.FOOTBALL_API_KEY } });
    if (!up.ok) throw new Error("upstream " + up.status);
    const data = await up.json();
    if (data.errors && Object.keys(data.errors).length) throw new Error("upstream errors");
    const allow = env.LEAGUES ? new Set(env.LEAGUES.split(",").map((s) => s.trim())) : null;
    const matches = (data.response || [])
      .filter((r) => !allow || allow.has(String(r.league && r.league.id)))
      .slice(0, 400)
      .map((r) => ({
        id: r.fixture.id, lg: r.league.name, co: r.league.country, h: r.teams.home.name, a: r.teams.away.name,
        hg: r.goals.home, ag: r.goals.away, st: r.fixture.status.short, min: r.fixture.status.elapsed, ko: r.fixture.date,
      }));
    const hasLive = matches.some((m) => LIVE.has(m.st));
    const body = { ok: true, updated: new Date().toISOString(), hasLive: hasLive, matches: matches };
    const ttl = hasLive ? liveTtl : idleTtl;
    memo.set(date, { body: body, exp: Date.now() + ttl * 1000 });
    return { body: body, ttl: ttl };
  } catch (e) {
    if (hit) return { body: Object.assign({}, hit.body, { stale: true }), ttl: 15 };
    return { error: true };
  }
}

// ---------- Football events (server-side) ----------
async function apiFixtures(env, q) {
  try {
    const tz = env.TIMEZONE || "Africa/Dar_es_Salaam";
    const r = await fetch("https://v3.football.api-sports.io/fixtures?" + q + "&timezone=" + encodeURIComponent(tz),
      { headers: { "x-apisports-key": env.FOOTBALL_API_KEY } });
    if (!r.ok) return null;
    const d = await r.json();
    if (d.errors && Object.keys(d.errors).length) return null;
    return d.response || [];
  } catch (e) { return null; }
}
const pack = (r) => ({
  id: r.fixture.id, lg: r.league.name, lgid: r.league.id, h: r.teams.home.name, a: r.teams.away.name,
  hg: r.goals.home, ag: r.goals.away, st: r.fixture.status.short, min: r.fixture.status.elapsed,
});
function diffEvents(old, m, out) {
  const ev = (type) => out.push(Object.assign({ type: type }, m));
  if (!old) {
    if (m.st === "1H" && (m.min == null || m.min <= 5)) ev("start");
  } else {
    if ((m.hg || 0) + (m.ag || 0) > (old.hg || 0) + (old.ag || 0)) ev("goal");
    if (m.st === "HT" && old.st !== "HT") ev("ht");
    if (m.st === "ET" && old.st !== "ET") ev("et");
    if (m.st === "P" && old.st !== "P") ev("pen");
  }
  if (["FT", "AET", "PEN"].includes(m.st) && (!old || old.st !== m.st)) ev("ft");
  if (["PST", "CANC", "ABD", "SUSP"].includes(m.st) && (!old || old.st !== m.st)) ev("status");
}
function evId(e) {
  return "fb:" + e.id + ":" + e.type + (e.type === "goal" ? ":" + (e.hg || 0) + "-" + (e.ag || 0) : e.type === "status" ? ":" + e.st : "");
}
async function emit(env, st, e) {
  const key = "evt:" + evId(e);
  if (await st.get(key)) return false; // usitume mara mbili
  await st.put(key, "1", 172800);
  const score = e.h + " " + (e.hg || 0) + "-" + (e.ag || 0) + " " + e.a;
  const titles = { goal: "GOAL! " + score, start: "Kick-off: " + e.h + " vs " + e.a, ht: "Half-time: " + score,
    ft: "Full-time: " + score, et: "Extra time: " + score, pen: "Penalties: " + score, status: e.h + " vs " + e.a + ": " + e.st };
  const data = { id: evId(e), type: "football", event: e.type, match_id: e.id, lg: e.lg, h: e.h, a: e.a,
    hg: e.hg == null ? 0 : e.hg, ag: e.ag == null ? 0 : e.ag, min: e.min == null ? "" : e.min, st: e.st,
    title: titles[e.type], body: e.lg };
  await sendTopic(env, "m" + e.id + "_" + e.type, Object.assign({ scope: "match" }, data));
  const top = new Set((env.LEAGUES_TOP || TOP_DEFAULT).split(",").map((s) => s.trim()));
  if (top.has(String(e.lgid))) await sendTopic(env, e.type === "goal" ? "football_goals" : "football", Object.assign({ scope: "global" }, data));
  return true;
}
async function footballTick(env) {
  if (!env.FOOTBALL_API_KEY || !env.FCM_SERVICE_ACCOUNT) return;
  const st = kv(env);
  // Andika mara MOJA kwa kila tick (KV Free ina kikomo cha writes 1,000/siku)
  const state = JSON.parse((await st.get("fb:state")) || "{}");
  const prev = state.live || {};
  const poll = Math.max(30, parseInt(env.FOOTBALL_POLL_SECS || "120", 10) || 120);
  const idle = Math.max(poll, parseInt(env.FOOTBALL_IDLE_SECS || "1800", 10) || 1800);
  const nowMs = Date.now();
  if (nowMs - (state.last || 0) < (Object.keys(prev).length ? poll : idle) * 1000) return;
  const day = new Date().toISOString().slice(0, 10);
  const budget = parseInt(env.FOOTBALL_DAILY_BUDGET || "60", 10) || 60;
  let used = state.day === day ? state.count || 0 : 0;
  if (used >= budget) return; // linda quota ya API
  used++;
  let now = prev;
  const events = [];
  try {
    const live = await apiFixtures(env, "live=all");
    if (live) {
      now = {};
      for (const r of live) now[r.fixture.id] = pack(r);
      for (const id in now) diffEvents(prev[id], now[id], events);
      const gone = Object.keys(prev).filter((id) => !(id in now)).slice(0, 20);
      if (gone.length && used < budget) {
        used++;
        const fin = await apiFixtures(env, "ids=" + gone.join("-"));
        for (const r of fin || []) { const m = pack(r); diffEvents(prev[m.id], m, events); }
      }
    }
  } finally {
    await st.put("fb:state", JSON.stringify({ last: nowMs, day: day, count: used, live: now }), 90000);
  }
  for (const e of events) await emit(env, st, e);
}

// ---------- News ----------
const NEWS = [
  { key: "breaking", topic: "news", cat: "breaking", url: "https://feeds.bbci.co.uk/news/rss.xml", src: "BBC News", max: 1, gap: 1800 },
  { key: "tz", topic: "news_tanzania", cat: "tanzania", url: "https://news.google.com/rss?hl=en-TZ&gl=TZ&ceid=TZ:en", src: "Google News", max: 2, gap: 600 },
  { key: "sports", topic: "news_sports", cat: "sports", url: "https://feeds.bbci.co.uk/sport/rss.xml", src: "BBC Sport", max: 1, gap: 900 },
  { key: "football", topic: "news_football", cat: "football", url: "https://feeds.bbci.co.uk/sport/football/rss.xml", src: "BBC Sport", max: 1, gap: 900 },
  { key: "tech", topic: "news_technology", cat: "technology", url: "https://feeds.bbci.co.uk/news/technology/rss.xml", src: "BBC News", max: 1, gap: 1800 },
];
const unxml = (s) => s.replace("<![CDATA[", "").replace("]]>", "").replace(/&amp;/g, "&").replace(/&lt;/g, "<")
  .replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();
function parseRss(xml) {
  const out = [];
  const re = /<item>([\s\S]*?)<\/item>/g;
  let m;
  while ((m = re.exec(xml))) {
    const b = m[1];
    const t = /<title>([\s\S]*?)<\/title>/.exec(b);
    const l = /<link>([\s\S]*?)<\/link>/.exec(b);
    if (!t || !l) continue;
    const s = /<source[^>]*>([\s\S]*?)<\/source>/.exec(b);
    const im = /<media:thumbnail[^>]*url=["']([^"']+)["']/.exec(b);
    let title = unxml(t[1]);
    if (s) title = title.replace(/ - [^-]+$/, "");
    const img = im ? unxml(im[1]).replace("http://", "https://").replace("/standard/240/", "/standard/464/") : "";
    out.push({ title: title, link: unxml(l[1]), src: s ? unxml(s[1]) : "", img: img });
  }
  return out;
}
async function newsTick(env) {
  if (!env.FCM_SERVICE_ACCOUNT) return;
  const st = kv(env);
  const every = Math.max(120, parseInt(env.NEWS_POLL_SECS || "600", 10) || 600);
  if (Date.now() - parseInt((await st.get("news:last")) || "0", 10) < every * 1000) return;
  await st.put("news:last", String(Date.now()), 3600);
  for (const f of NEWS) {
    try {
      const r = await fetch(f.url, { headers: { "user-agent": "Mozilla/5.0" } });
      if (!r.ok) continue;
      const items = parseRss(await r.text()).slice(0, 8);
      const init = await st.get("news:init:" + f.key);
      const fresh = [];
      for (const it of items) {
        const h = (await sha(it.link)).slice(0, 24);
        const k = "news:seen:" + f.key + ":" + h;
        if (!(await st.get(k))) fresh.push({ it: it, k: k, h: h });
      }
      for (const x of fresh) await st.put(x.k, "1", 259200);
      if (!init) await st.put("news:init:" + f.key, "1", 2592000);
      if (!init) continue; // mara ya kwanza: weka alama tu, usitume
      if (Date.now() - parseInt((await st.get("news:gap:" + f.key)) || "0", 10) < f.gap * 1000) continue;
      let sent = 0;
      for (const x of fresh) {
        if (sent >= f.max) break;
        await sendTopic(env, f.topic, { id: "news:" + x.h, type: "news", cat: f.cat, title: x.it.title,
          body: x.it.src || f.src, url: x.it.link, image: x.it.img });
        sent++;
      }
      if (sent) await st.put("news:gap:" + f.key, String(Date.now()), 7200);
    } catch (e) { /* endelea na feed inayofuata */ }
  }
}

// ---------- Admin ----------
const AUD = { all: "all_users", announcements: "announcements", football: "football", goals: "football_goals",
  news: "news", tanzania: "news_tanzania", sports: "news_sports", football_news: "news_football", technology: "news_technology" };
function okLink(l) {
  if (!l) return true;
  if (/^rlg:\/\/(match\/\d{1,12}|notifications|downloads|settings|announcement(\/[\w-]{1,40})?)$/.test(l)) return true;
  return /^https:\/\/[^\s]{3,2000}$/.test(l);
}
const ADMIN_HTML = '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>RLG Admin</title>' +
  '<style>body{font-family:sans-serif;background:#0b0b0d;color:#fff;max-width:480px;margin:auto;padding:16px}input,select,textarea,button{width:100%;box-sizing:border-box;margin:6px 0 12px;padding:12px;border-radius:10px;border:1px solid #333;background:#1a1a1e;color:#fff;font-size:16px}button{background:#ffb300;color:#000;font-weight:700;border:0}pre{white-space:pre-wrap;color:#9c9}</style>' +
  '<h2>Rahim Lux Go — Send notification</h2>' +
  '<input id=tk type=password placeholder="Admin token"><input id=ti maxlength=120 placeholder="Title"><textarea id=bo rows=3 maxlength=500 placeholder="Message"></textarea>' +
  '<input id=im placeholder="Image URL (https, optional)"><input id=li placeholder="Deep link (https://... or rlg://notifications, optional)">' +
  '<select id=au><option value=all>All users</option><option value=announcements>Announcements subscribers</option><option value=football>Football followers</option><option value=goals>Football goals followers</option><option value=news>News: breaking</option><option value=tanzania>News: Tanzania</option><option value=sports>News: Sports</option><option value=football_news>News: Football</option><option value=technology>News: Technology</option></select>' +
  '<input id=tp placeholder="Custom topic (optional, overrides audience)"><button onclick=go()>Send</button><pre id=out></pre>' +
  '<script>async function go(){var o=document.getElementById("out");o.textContent="...";try{var r=await fetch("/admin/send",{method:"POST",headers:{"content-type":"application/json",authorization:"Bearer "+document.getElementById("tk").value},body:JSON.stringify({title:document.getElementById("ti").value,message:document.getElementById("bo").value,image:document.getElementById("im").value,link:document.getElementById("li").value,audience:document.getElementById("au").value,topic:document.getElementById("tp").value})});o.textContent=r.status+" "+await r.text()}catch(e){o.textContent=e}}</script>';

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const post = request.method === "POST";
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: { "access-control-allow-origin": "*", "access-control-allow-headers": "x-app-token, authorization, content-type" } });
    }

    if (path === "/admin" && request.method === "GET") {
      return new Response(ADMIN_HTML, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
    }
    if (path === "/admin/send" && post) {
      const auth = (request.headers.get("authorization") || "").replace(/^Bearer /, "");
      if (!env.ADMIN_TOKEN || !ctEq(auth, env.ADMIN_TOKEN)) return reply({ ok: false, error: "unauthorized" }, 401);
      let b;
      try { b = await request.json(); } catch (e) { return reply({ ok: false, error: "bad_json" }, 400); }
      const title = String(b.title || "").trim().slice(0, 120);
      const message = String(b.message || "").trim().slice(0, 500);
      const link = String(b.link || "").trim();
      const image = String(b.image || "").trim();
      if (!title || !message) return reply({ ok: false, error: "title_and_message_required" }, 400);
      if (!okLink(link)) return reply({ ok: false, error: "bad_link" }, 400);
      if (image && !/^https:\/\/[^\s]{3,2000}$/.test(image)) return reply({ ok: false, error: "bad_image" }, 400);
      const custom = typeof b.topic === "string" && /^[A-Za-z0-9_.~%-]{1,100}$/.test(b.topic) ? b.topic : null;
      const topic = custom || AUD[b.audience];
      if (!topic) return reply({ ok: false, error: "bad_audience" }, 400);
      const res = await sendTopic(env, topic, { id: "adm:" + Date.now(), type: "announcement", title: title, body: message, link: link, image: image }, 86400);
      return reply({ ok: res.ok, topic: topic, status: res.status, error: res.text }, res.ok ? 200 : 502);
    }

    if (!appOk(request, env)) return reply({ ok: false, error: "unauthorized", matches: [] }, 401);

    if (path === "/health" && request.method === "GET") {
      return reply({ ok: true, version: 3, fcm: !!env.FCM_SERVICE_ACCOUNT, football: !!env.FOOTBALL_API_KEY,
        kv: !!env.STATE, admin: !!env.ADMIN_TOKEN, appToken: !!env.APP_TOKEN, time: new Date().toISOString() });
    }
    if (path === "/device" && post) {
      let b;
      try { b = await request.json(); } catch (e) { return reply({ ok: false }, 400); }
      if (typeof b.token !== "string" || !/^[\w:.-]{20,4096}$/.test(b.token)) return reply({ ok: false, error: "bad_token" }, 400);
      await kv(env).put("dev:" + (await sha(b.token)).slice(0, 32), JSON.stringify({ lang: String(b.lang || "").slice(0, 5), ts: Date.now() }), 5184000);
      return reply({ ok: true });
    }
    if (path === "/device/delete" && post) {
      let b;
      try { b = await request.json(); } catch (e) { return reply({ ok: false }, 400); }
      if (typeof b.token !== "string" || b.token.length > 4096) return reply({ ok: false }, 400);
      await kv(env).del("dev:" + (await sha(b.token)).slice(0, 32));
      return reply({ ok: true });
    }
    if (path === "/test" && post) {
      let b;
      try { b = await request.json(); } catch (e) { return reply({ ok: false }, 400); }
      if (typeof b.token !== "string" || !/^[\w:.-]{20,4096}$/.test(b.token)) return reply({ ok: false, error: "bad_token" }, 400);
      const st = kv(env);
      const rk = "test:" + (await sha(b.token)).slice(0, 24);
      if (await st.get(rk)) return reply({ ok: false, error: "rate_limited" }, 429);
      const now = Date.now();
      const title = "Rahim Lux Go";
      const body = "Push test from your server works ✅";
      // data (kwa app) + notification (Google Play services inaionyesha hata app ikiwa imefungwa/imezuiwa na OEM)
      const res = await sendFcm(env, { token: b.token },
        { id: "test:" + now, type: "test", title: title, body: body, sent_at: now }, 300,
        { channel: "test", notification: { title: title, body: body } });
      if (res.ok) await st.put(rk, "1", 60); // limiter inawekwa baada ya MAFANIKIO tu (kushindwa hakuzuii kujaribu tena)
      return reply({ ok: res.ok, status: res.status, ms: res.ms, error: res.text }, res.ok ? 200 : 502);
    }

    if (path === "/scores") {
      if (!env.FOOTBALL_API_KEY) return reply({ ok: false, error: "not_configured", matches: [] }, 503);
      const tz = env.TIMEZONE || "Africa/Dar_es_Salaam";
      const today = new Intl.DateTimeFormat("en-CA", { timeZone: tz }).format(new Date());
      let date = url.searchParams.get("date") || today;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) date = today;
      const diffDays = Math.abs((Date.parse(date + "T00:00:00Z") - Date.parse(today + "T00:00:00Z")) / 86400000);
      if (!(diffDays <= 1)) date = today;
      const r = await getScores(env, date);
      if (r.error) return reply({ ok: false, error: "upstream_error", matches: [] }, 502);
      return reply(r.body, 200, r.ttl);
    }
    return reply({ ok: false, error: "not_found" }, 404);
  },

  async scheduled(event, env, ctx) {
    ctx.waitUntil(Promise.all([footballTick(env).catch(() => {}), newsTick(env).catch(() => {})]));
  },
};

// kwa majaribio ya ndani (node)
export { footballTick, newsTick, diffEvents, parseRss, accessToken, sendFcm };
