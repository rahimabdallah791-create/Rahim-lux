RAHIM LUX GO v4 - Android browser (Kotlin + WebView)
Mpya v4: orodha ya domains zilizozuiwa (menu > Zilizozuiwa).
Android Studio: Open folda hii > Run.
