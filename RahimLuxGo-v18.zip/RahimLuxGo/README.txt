RAHIM LUX GO v18 - Android browser (Kotlin + WebView)
Mpya v18: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
