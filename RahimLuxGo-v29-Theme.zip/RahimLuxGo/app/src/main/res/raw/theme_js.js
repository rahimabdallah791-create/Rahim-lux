/* =====================================================================
   Rahim Lux Go — Theme Switcher (JavaScript, bila maktaba)
   - Inahifadhi chaguo kwenye localStorage ("rlg-theme")
   - Inatumia theme mapema (hakuna mwanga wa rangi nyingine wakati ukurasa unapakia)
   - API:  RLGTheme.get() / set(id) / next() / mount(element) / themes
   - Tukio: document.addEventListener('rlg-theme-change', e => e.detail.theme)
   ===================================================================== */
(function (global) {
  'use strict';

  var KEY = 'rlg-theme';
  var THEMES = [
    { id: 'gold',    en: 'Gold Lux',      sw: 'Dhahabu',       meta: 'dark',  sw1: '#FFB300', sw2: '#FF8F00' },
    { id: 'cyan',    en: 'Neon Cyan',     sw: 'Cyan ya Neon',  meta: 'dark',  sw1: '#00E5FF', sw2: '#00B8D4' },
    { id: 'emerald', en: 'Emerald Green', sw: 'Kijani',        meta: 'dark',  sw1: '#2ECC71', sw2: '#1FA855' },
    { id: 'light',   en: 'Light Mode',    sw: 'Mwanga',        meta: 'light', sw1: '#F6F4EF', sw2: '#E09A00' }
  ];

  var doc = global.document;
  var root = doc.documentElement;
  var current = 'gold';
  var mounted = [];

  function find(id) {
    for (var i = 0; i < THEMES.length; i++) if (THEMES[i].id === id) return THEMES[i];
    return null;
  }
  function lang() {
    return String(root.getAttribute('lang') || '').toLowerCase().indexOf('sw') === 0 ? 'sw' : 'en';
  }
  function read() { try { return global.localStorage.getItem(KEY); } catch (e) { return null; } }
  function write(id) { try { global.localStorage.setItem(KEY, id); return true; } catch (e) { return false; } }

  function setMeta(t) {
    var m = doc.querySelector('meta[name="color-scheme"]');
    if (!m) {
      m = doc.createElement('meta');
      m.setAttribute('name', 'color-scheme');
      (doc.head || root).appendChild(m);
    }
    m.setAttribute('content', t.meta === 'light' ? 'only light' : 'dark');
  }

  function fire(id) {
    try {
      doc.dispatchEvent(new global.CustomEvent('rlg-theme-change', { detail: { theme: id } }));
    } catch (e) { /* mazingira ya zamani: puuza */ }
  }

  function apply(id, animate) {
    var t = find(id) || THEMES[0];
    if (animate && root.classList) {
      root.classList.add('ts-anim');
      global.setTimeout(function () { root.classList.remove('ts-anim'); }, 400);
    }
    root.setAttribute('data-theme', t.id);
    setMeta(t);
    current = t.id;
    refresh();
    return t.id;
  }

  function set(id) {
    if (!find(id)) return false;       // thamani zisizojulikana zinakataliwa
    apply(id, true);
    write(id);
    fire(id);
    return true;
  }
  function get() { return current; }
  function next() {
    var i = 0;
    for (var k = 0; k < THEMES.length; k++) if (THEMES[k].id === current) i = k;
    return set(THEMES[(i + 1) % THEMES.length].id);
  }

  // ---------- UI ----------
  function refresh() {
    for (var i = 0; i < mounted.length; i++) {
      var btns = mounted[i].children;
      for (var j = 0; j < btns.length; j++) {
        var on = btns[j].getAttribute('data-id') === current;
        btns[j].setAttribute('aria-checked', on ? 'true' : 'false');
        btns[j].setAttribute('tabindex', on ? '0' : '-1');
      }
    }
  }

  function mount(el) {
    if (!el || el.getAttribute('data-ts-mounted')) return;
    el.setAttribute('data-ts-mounted', '1');
    el.className = (el.className ? el.className + ' ' : '') + 'ts';
    el.setAttribute('role', 'radiogroup');
    el.setAttribute('aria-label', lang() === 'sw' ? 'Mandhari' : 'Theme');
    var l = lang();
    THEMES.forEach(function (t) {
      var b = doc.createElement('button');
      b.type = 'button';
      b.className = 'ts-btn';
      b.setAttribute('role', 'radio');
      b.setAttribute('data-id', t.id);
      var dot = doc.createElement('span');
      dot.className = 'ts-dot';
      dot.style.setProperty('--sw1', t.sw1);
      dot.style.setProperty('--sw2', t.sw2);
      var label = doc.createElement('span');
      label.textContent = t[l];
      b.appendChild(dot);
      b.appendChild(label);
      b.addEventListener('click', function () { set(t.id); });
      b.addEventListener('keydown', function (e) {
        var k = e.key, d = 0;
        if (k === 'ArrowRight' || k === 'ArrowDown') d = 1;
        else if (k === 'ArrowLeft' || k === 'ArrowUp') d = -1;
        else return;
        e.preventDefault();
        var i = 0;
        for (var n = 0; n < THEMES.length; n++) if (THEMES[n].id === current) i = n;
        var nt = THEMES[(i + d + THEMES.length) % THEMES.length].id;
        set(nt);
        var btns = el.children;
        for (var m = 0; m < btns.length; m++) if (btns[m].getAttribute('data-id') === nt && btns[m].focus) btns[m].focus();
      });
      el.appendChild(b);
    });
    mounted.push(el);
    refresh();
  }

  function autoMount() {
    var list = doc.querySelectorAll('[data-theme-switcher], #theme-switcher');
    for (var i = 0; i < list.length; i++) mount(list[i]);
  }

  // ---------- Anza ----------
  var saved = read();
  if (find(saved)) apply(saved, false);       // theme iliyohifadhiwa, mapema
  else current = 'gold';                      // bila chaguo: muonekano wa awali unabaki

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', autoMount);
  else autoMount();

  // ulandanishi kati ya tabs/madirisha
  if (global.addEventListener) {
    global.addEventListener('storage', function (e) {
      if (e.key === KEY && find(e.newValue)) apply(e.newValue, true);
    });
  }

  global.RLGTheme = {
    themes: THEMES.map(function (t) { return { id: t.id, name: t.en }; }),
    get: get, set: set, next: next, mount: mount
  };
})(window);
