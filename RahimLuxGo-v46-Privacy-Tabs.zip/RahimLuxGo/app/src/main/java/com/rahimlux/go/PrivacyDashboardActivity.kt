package com.rahimlux.go

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Privacy Dashboard: trackers na maombi yaliyozuiwa (pamoja na makadirio ya data), ruhusa za tovuti na za Android,
 * na kufuta data kwa uchaguzi wako (kwa uthibitisho kabla ya kufuta).
 */
class PrivacyDashboardActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var list: LinearLayout
    private lateinit var deleteBtn: TextView
    private var sel = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0B0D"))
        root.addView(ui.header(ui.t("Privacy Dashboard", "Dashibodi ya Faragha"), listOf("↻" to { render() })))
        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(ui.dp(14), ui.dp(0), ui.dp(14), ui.dp(32))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        setResult(RESULT_OK)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun fmtBytes(b: Long): String {
        val kb = b / 1024.0
        return when {
            kb < 1024 -> String.format(Locale.US, "%.0f KB", kb)
            kb < 1024 * 1024 -> String.format(Locale.US, "%.1f MB", kb / 1024)
            else -> String.format(Locale.US, "%.2f GB", kb / (1024 * 1024))
        }
    }

    private fun render() {
        list.removeAllViews()
        statsSection()
        protectionSection()
        topSection()
        permissionSection()
        clearSection()
    }

    // ---------------- Muhtasari wa ulinzi ----------------
    private fun statsSection() {
        ui.section(list, ui.t("Protection summary", "Muhtasari wa ulinzi"))
        val card = ui.card()
        val nums = LinearLayout(this)
        nums.setPadding(ui.dp(8), ui.dp(16), ui.dp(8), ui.dp(10))
        fun cell(n: Int, label: String, color: Int) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            val v = TextView(this)
            v.text = n.toString(); v.textSize = 26f; v.setTextColor(color); v.setTypeface(null, Typeface.BOLD)
            val l = TextView(this)
            l.text = label; l.textSize = 12f; l.setTextColor(Color.parseColor("#8A8A94"))
            box.addView(v); box.addView(l)
            nums.addView(box, LinearLayout.LayoutParams(0, -2, 1f))
        }
        cell(store.blkAds, ui.t("Ads", "Matangazo"), ui.gold)
        cell(store.blkTrackers, "Trackers", Color.parseColor("#4DD0E1"))
        cell(store.blkMedia, ui.t("Heavy media", "Media nzito"), Color.parseColor("#B0B0B8"))
        card.addView(nums)
        val since = store.statsSince
        val sinceTxt = if (since > 0) SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(since)) else "—"
        ui.row(
            card, "≈ " + fmtBytes(store.estSavedBytes) + " " + ui.t("blocked", "zimezuiwa"),
            ui.t("Estimate since ", "Makadirio tangu ") + sinceTxt +
                ui.t(". Blocked requests × average size (ad ≈ 35 KB, tracker ≈ 12 KB, heavy video ≈ 1.5 MB). Not measured from your network.",
                    ". Maombi yaliyozuiwa × ukubwa wa wastani (tangazo ≈ 35 KB, tracker ≈ 12 KB, video nzito ≈ 1.5 MB). Si kipimo halisi cha mtandao wako."),
            null, null
        )
        ui.row(card, ui.t("Reset statistics", "Weka upya takwimu"), null, ui.arrow()) {
            AlertDialog.Builder(this)
                .setTitle(ui.t("Reset statistics?", "Weka upya takwimu?"))
                .setPositiveButton(ui.t("Reset", "Weka upya")) { _, _ -> store.resetPrivacyStats(); render() }
                .setNegativeButton(ui.t("Cancel", "Ghairi"), null).show()
        }
        ui.addCard(list, card)
    }

    private fun protectionSection() {
        ui.section(list, ui.t("Protection", "Ulinzi"))
        val c = ui.card()
        ui.switchRow(c, ui.t("Block ads", "Zuia matangazo"),
            ui.t("Ad networks list (${AdBlock.count} domains)", "Orodha ya mitandao ya matangazo (domains ${AdBlock.count})"), store.adblock) { store.adblock = it }
        ui.switchRow(c, ui.t("Block trackers", "Zuia trackers"),
            ui.t("Light list: analytics, session recording, attribution (${Trackers.count} domains)",
                "Orodha nyepesi: analytics, kurekodi vipindi, attribution (domains ${Trackers.count})"), store.trackerBlock) { store.trackerBlock = it }
        ui.switchRow(c, ui.t("Third-party cookies", "Cookies za third-party"),
            ui.t("Allow cookies set by other sites inside pages", "Ruhusu cookies kutoka tovuti nyingine ndani ya kurasa"), store.thirdCookies) { store.thirdCookies = it }
        ui.switchRow(c, "Data saver", ui.t("Block images and heavy video", "Zuia picha na video nzito"), store.dataSaver) { store.dataSaver = it }
        ui.addCard(list, c)
    }

    private fun topSection() {
        ui.section(list, ui.t("Most blocked", "Zilizozuiwa zaidi"))
        val c = ui.card()
        val top = BlockLog.top(8)
        if (top.isEmpty()) {
            ui.row(c, ui.t("Nothing blocked yet", "Hakuna kilichozuiwa bado"), ui.t("Browse a few sites and check back.", "Vinjari tovuti chache kisha rudi."), null, null)
        } else {
            for ((k, n) in top) {
                val tv = TextView(this)
                tv.text = n.toString(); tv.textSize = 15f; tv.setTextColor(ui.gold); tv.setTypeface(null, Typeface.BOLD)
                ui.row(c, k, null, tv, null)
            }
        }
        ui.addCard(list, c)
    }

    // ---------------- Ruhusa ----------------
    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun androidOk(kind: Int): Boolean = when (kind) {
        SitePerms.GEO -> granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        SitePerms.CAM -> granted(Manifest.permission.CAMERA)
        else -> granted(Manifest.permission.RECORD_AUDIO)
    }

    private fun stateText(v: Int) = when (v) {
        SitePerms.ALLOW -> ui.t("Allowed", "Imeruhusiwa")
        SitePerms.BLOCK -> ui.t("Blocked", "Imezuiwa")
        else -> ui.t("Ask", "Uliza")
    }

    private fun permissionSection() {
        ui.section(list, ui.t("Permissions", "Ruhusa"))
        val c = ui.card()
        ui.row(
            c, ui.t("Android permissions for this app", "Ruhusa za Android za app hii"),
            ui.t("A site can use these only if Android allows them for this app AND you allow the site.",
                "Tovuti inaweza kuzitumia tu kama Android imeruhusu kwa app hii NA wewe umeiruhusu tovuti."), null, null
        )
        for (kind in SitePerms.KINDS) {
            val ok = androidOk(kind)
            val detail = if (kind == SitePerms.GEO && ok && !granted(Manifest.permission.ACCESS_FINE_LOCATION))
                ui.t("Allowed (approximate only)", "Imeruhusiwa (takriban tu)") else if (ok) ui.t("Allowed", "Imeruhusiwa") else ui.t("Not allowed", "Haijaruhusiwa")
            ui.row(c, SitePerms.icon(kind) + " " + SitePerms.label(kind, store.lang == "sw"), detail, null, null)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            val n = granted(Manifest.permission.POST_NOTIFICATIONS)
            ui.row(c, "🔔 " + ui.t("App notifications", "Arifa za app"), if (n) ui.t("Allowed", "Imeruhusiwa") else ui.t("Not allowed", "Haijaruhusiwa"), null, null)
        }
        ui.row(c, ui.t("Open Android app settings", "Fungua mipangilio ya app kwenye Android"), null, ui.arrow()) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
            } catch (e: Exception) {
                toast(ui.t("Open Settings > Apps > Rahim Lux Go", "Fungua Settings > Apps > Rahim Lux Go"))
            }
        }
        ui.row(
            c, ui.t("Not supported in WebView", "Hazitumiki kwenye WebView"),
            ui.t("Website push notifications and background location are never granted.", "Arifa za tovuti (push) na mahali kwa nyuma hazitolewi kamwe."), null, null
        )
        ui.addCard(list, c)

        // Chaguo-msingi tovuti inapoomba
        ui.section(list, ui.t("When a site asks", "Tovuti inapoomba"))
        val d = ui.card()
        for (kind in SitePerms.KINDS) {
            val cur = SitePerms.default(store, kind)
            ui.row(d, SitePerms.icon(kind) + " " + SitePerms.label(kind, store.lang == "sw"),
                if (cur == SitePerms.BLOCK) ui.t("Always block", "Zuia kila mara") else ui.t("Ask each time", "Uliza kila mara"), ui.arrow()) {
                val opts = arrayOf(ui.t("Ask each time", "Uliza kila mara"), ui.t("Always block", "Zuia kila mara"))
                AlertDialog.Builder(this).setTitle(SitePerms.label(kind, store.lang == "sw"))
                    .setSingleChoiceItems(opts, if (cur == SitePerms.BLOCK) 1 else 0) { dlg, i ->
                        val v = if (i == 1) SitePerms.BLOCK else SitePerms.ASK
                        when (kind) {
                            SitePerms.GEO -> store.permDefGeo = v
                            SitePerms.CAM -> store.permDefCam = v
                            else -> store.permDefMic = v
                        }
                        dlg.dismiss()
                        render()
                    }.show()
            }
        }
        ui.addCard(list, d)

        // Tovuti zenye uamuzi uliohifadhiwa
        ui.section(list, ui.t("Saved site permissions", "Ruhusa za tovuti zilizohifadhiwa"))
        val s = ui.card()
        val sites = SitePerms.all(store)
        if (sites.isEmpty()) {
            ui.row(
                s, ui.t("No saved decisions", "Hakuna maamuzi yaliyohifadhiwa"),
                ui.t("When a site asks for location, camera or microphone, choose \"Remember for this site\" to see it here.",
                    "Tovuti ikiomba mahali, kamera au kipaza sauti, chagua \"Kumbuka kwa tovuti hii\" ili ionekane hapa."), null, null
            )
        } else {
            for ((origin, v) in sites) {
                val parts = SitePerms.KINDS.filter { v[it] != SitePerms.ASK }.map { k ->
                    var x = SitePerms.icon(k) + " " + stateText(v[k])
                    if (v[k] == SitePerms.ALLOW && !androidOk(k)) x += " (" + ui.t("Android permission is off", "ruhusa ya Android imezimwa") + ")"
                    x
                }
                val del = TextView(this)
                del.text = "🗑"; del.textSize = 18f; del.setTextColor(Color.WHITE)
                del.setPadding(ui.dp(12), ui.dp(8), ui.dp(8), ui.dp(8))
                del.setOnClickListener { SitePerms.clearSite(store, origin); render() }
                ui.row(s, SitePerms.host(origin), parts.joinToString(" · "), del) { editSite(origin) }
            }
        }
        ui.addCard(list, s)
    }

    /** Kila kubonyeza kunabadilisha: Uliza -> Ruhusu -> Zuia. */
    private fun editSite(origin: String) {
        val kinds = SitePerms.KINDS
        val labels = kinds.map { SitePerms.icon(it) + " " + SitePerms.label(it, store.lang == "sw") + ": " + stateText(SitePerms.get(store, origin, it)) }
        AlertDialog.Builder(this)
            .setTitle(SitePerms.host(origin))
            .setItems(labels.toTypedArray()) { _, i ->
                val k = kinds[i]
                val next = when (SitePerms.get(store, origin, k)) {
                    SitePerms.ASK -> SitePerms.ALLOW
                    SitePerms.ALLOW -> SitePerms.BLOCK
                    else -> SitePerms.ASK
                }
                SitePerms.set(store, origin, k, next)
                editSite(origin)
            }
            .setNegativeButton(ui.t("Done", "Maliza"), null)
            .setOnDismissListener { render() }
            .show()
    }

    // ---------------- Kufuta data ----------------
    private class Opt(val mask: Int, val label: String, val sub: String)

    private fun options(): List<Opt> {
        val hist = try { store.history().size } catch (e: Exception) { 0 }
        val srch = try { store.searches().size } catch (e: Exception) { 0 }
        val sites = SitePerms.all(store).size
        val tabsN = TabArchive.closed(store).size + TabArchive.sessions(store).size
        val off = OfflineRepo.list(this, store).size
        return listOf(
            Opt(PrivacyData.HISTORY, ui.t("Browsing history", "History ya kuvinjari"), "$hist " + ui.t("pages", "kurasa")),
            Opt(PrivacyData.SEARCHES, ui.t("Search history", "History ya utafutaji"), "$srch " + ui.t("searches", "utafutaji")),
            Opt(PrivacyData.COOKIES, ui.t("Cookies & site data", "Cookies na data ya tovuti"), ui.t("You will be signed out of websites", "Utatolewa kwenye tovuti ulizoingia")),
            Opt(PrivacyData.CACHE, ui.t("Cache & form data", "Cache na data ya fomu"), ui.t("Saved images and files from websites", "Picha na faili zilizohifadhiwa za tovuti")),
            Opt(PrivacyData.PERMS, ui.t("Site permissions", "Ruhusa za tovuti"), "$sites " + ui.t("sites", "tovuti")),
            Opt(PrivacyData.STATS, ui.t("Blocking statistics", "Takwimu za kuzuia"), ui.t("Counters and most-blocked list", "Hesabu na orodha ya zilizozuiwa zaidi")),
            Opt(PrivacyData.TABS, ui.t("Closed tabs & saved sessions", "Tab zilizofungwa na vipindi"), "$tabsN " + ui.t("items", "vitu")),
            Opt(PrivacyData.OFFLINE, ui.t("Offline pages", "Kurasa za offline"), "$off " + ui.t("pages saved on this phone", "kurasa zilizohifadhiwa kwenye simu hii"))
        )
    }

    private fun clearSection() {
        ui.section(list, ui.t("Clear data", "Futa data"))
        val c = ui.card()
        for (o in options()) {
            val cb = CheckBox(this)
            cb.isChecked = (sel and o.mask) != 0
            cb.setOnCheckedChangeListener { _, on ->
                sel = if (on) sel or o.mask else sel and o.mask.inv()
                refreshButton()
            }
            ui.row(c, o.label, o.sub, cb) { cb.toggle() }
        }
        ui.row(c, ui.t("Select all / none", "Chagua zote / hakuna"), null, null) {
            sel = if (sel == PrivacyData.ALL) 0 else PrivacyData.ALL
            render()
        }
        ui.addCard(list, c)

        deleteBtn = TextView(this)
        deleteBtn.text = "🗑  " + ui.t("Delete selected data", "Futa data iliyochaguliwa")
        deleteBtn.textSize = 15f; deleteBtn.setTextColor(Color.WHITE); deleteBtn.setTypeface(null, Typeface.BOLD)
        deleteBtn.gravity = Gravity.CENTER
        deleteBtn.setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
        val bg = GradientDrawable()
        bg.cornerRadius = ui.dp(16).toFloat(); bg.setColor(Color.parseColor("#D32F2F"))
        deleteBtn.background = bg
        deleteBtn.setOnClickListener { confirmDelete() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = ui.dp(14)
        list.addView(deleteBtn, lp)
        refreshButton()
    }

    private fun refreshButton() {
        if (::deleteBtn.isInitialized) deleteBtn.alpha = if (sel == 0) 0.4f else 1f
    }

    private fun confirmDelete() {
        if (sel == 0) { toast(ui.t("Choose what to delete first", "Chagua cha kufuta kwanza")); return }
        val chosen = options().filter { (sel and it.mask) != 0 }
        val msg = chosen.joinToString("\n") { "• " + it.label } +
            (if ((sel and PrivacyData.COOKIES) != 0) "\n\n" + ui.t("You will be signed out of websites.", "Utatolewa kwenye tovuti ulizoingia.") else "") +
            "\n\n" + ui.t("This cannot be undone.", "Hili haliwezi kutenduliwa.")
        AlertDialog.Builder(this)
            .setTitle(ui.t("Delete selected data?", "Futa data iliyochaguliwa?"))
            .setMessage(msg)
            .setPositiveButton(ui.t("Delete", "Futa")) { _, _ ->
                PrivacyData.clear(this, store, sel)
                sel = 0
                toast(ui.t("Selected data deleted", "Data iliyochaguliwa imefutwa"))
                render()
            }
            .setNegativeButton(ui.t("Cancel", "Ghairi"), null)
            .show()
    }
}
