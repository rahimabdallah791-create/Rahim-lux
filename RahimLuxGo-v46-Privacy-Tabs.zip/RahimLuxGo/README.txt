RAHIM LUX GO v29 - Android browser (Kotlin + WebView)
Mpya v29: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.


WEATHER AS A SEPARATE WORKER
- Deploy backend/weather-worker.js as a NEW Cloudflare Worker; do not replace backend/worker.js or your current Live Scores Worker.
- Add OPENWEATHER_API_KEY as a secret on the new Weather Worker.
- Optionally add APP_TOKEN as a secret; if set, enter the same value in the app's Weather access token setting.
- In app Settings > Weather, set Weather server URL to the new Worker URL. Live Scores keeps using its existing Scores server URL.
- Optional: bind a KV namespace named STATE for weather/geocoding cache.


STANDINGS SEPARATE WORKER (v32 source update)
- Default Standings Worker URL: https://standings.rahimabdallah791.workers.dev
- App requests /standings?league=epl, /standings?league=nbc, etc. Do not add /standings to the URL saved in Settings.
- In Settings > Standings server, edit the URL or enter Standings access token if APP_TOKEN is configured on that Worker.
- Live Scores continues using its own Scores server URL and is not changed by this setting.
- This ZIP is Android source code; build a new APK to install the updated Settings screen.


STANDINGS RESPONSE COMPATIBILITY (v34)
- Home standings UI supports both legacy rows and the Worker response format groups[].table with rank/played/win/draw/lose/goalsDiff/points.


V37 additions: estimated data-saved counter, text-focused Reader mode, save page offline, and offline pages list. Offline saves are text-focused copies and do not preserve all original images/scripts; data saved is an estimate based on blocked requests.



V44 - AI REMOVED
- Removed the in-app AI button, AI chat, Ask Page, AI summarize/explain/translate actions, selected-text AI menu and the app-side AI Worker URL.
- Browser features unrelated to AI have been preserved. Page translation via the existing browser translation feature remains available.

V45: Offline pages zimerekebishwa (zinafunguka, aya zinabaki, kufuta, kufuli), Read aloud (vipande + sauti), TTS queries. Angalia docs/v45.

V46: Privacy Dashboard + Smart Tab Manager (tab zinaundwa inapohitajika, zinalala). Angalia docs/v46.
