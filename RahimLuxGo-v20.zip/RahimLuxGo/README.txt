RAHIM LUX GO v20 - Android browser (Kotlin + WebView)
Mpya v20: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
