/* =====================================================================
   Rahim Lux Go — Favorite Team (Timu Pendwa)
   - Inahifadhi timu kwenye localStorage ("rlg-fav-team") + kichujio ("rlg-fav-filter")
   - API: favIs(jinaLaTimu) · favGet() · favSelect(idAuJina) · favClear() · favFilterOn() · favSetFilter(bool)
   - Inaita lsRender() / stRender() (Live Scores / Standings) timu ikibadilika
   - Inajijenga ndani ya  <div id="myteam" class="myteam"></div>  (Glassmorphism, angalia fav-team.css)
   ===================================================================== */
(function (w) {
  'use strict';
  var KEY = 'rlg-fav-team', FKEY = 'rlg-fav-filter';
  var doc = w.document;

  // g = kundi, lg = ligi ya msimamo (kuruka moja kwa moja), x = majina yasiyopaswa kufanana
  var TEAMS = [
    { id: 'yanga',  n: 'Yanga SC',           g: 'Tanzania', lg: 'nbc', a: ['yanga', 'yanga sc', 'young africans', 'young africans sc', 'dar young africans'] },
    { id: 'simba',  n: 'Simba SC',           g: 'Tanzania', lg: 'nbc', a: ['simba', 'simba sc'] },
    { id: 'azam',   n: 'Azam FC',            g: 'Tanzania', lg: 'nbc', a: ['azam', 'azam fc'] },
    { id: 'singida', n: 'Singida Black Stars', g: 'Tanzania', lg: 'nbc', a: ['singida black stars', 'singida bs', 'singida'] },
    { id: 'coastal', n: 'Coastal Union',     g: 'Tanzania', lg: 'nbc', a: ['coastal union'] },
    { id: 'prisons', n: 'Tanzania Prisons',  g: 'Tanzania', lg: 'nbc', a: ['tanzania prisons', 'prisons'] },
    { id: 'namungo', n: 'Namungo FC',        g: 'Tanzania', lg: 'nbc', a: ['namungo', 'namungo fc'] },
    { id: 'arsenal', n: 'Arsenal',           g: 'England', lg: 'epl', a: ['arsenal', 'arsenal fc'] },
    { id: 'mancity', n: 'Man City',          g: 'England', lg: 'epl', a: ['manchester city', 'man city', 'manchester city fc'] },
    { id: 'manutd',  n: 'Man United',        g: 'England', lg: 'epl', a: ['manchester united', 'man united', 'man utd', 'manchester utd', 'manchester united fc'] },
    { id: 'liverpool', n: 'Liverpool',       g: 'England', lg: 'epl', a: ['liverpool', 'liverpool fc'] },
    { id: 'chelsea', n: 'Chelsea',           g: 'England', lg: 'epl', a: ['chelsea', 'chelsea fc'] },
    { id: 'spurs',   n: 'Tottenham',         g: 'England', lg: 'epl', a: ['tottenham', 'tottenham hotspur', 'spurs'] },
    { id: 'newcastle', n: 'Newcastle',       g: 'England', lg: 'epl', a: ['newcastle', 'newcastle united'] },
    { id: 'villa',   n: 'Aston Villa',       g: 'England', lg: 'epl', a: ['aston villa'] },
    { id: 'real',    n: 'Real Madrid',       g: 'Spain', lg: 'laliga', a: ['real madrid', 'real madrid cf'] },
    { id: 'barca',   n: 'Barcelona',         g: 'Spain', lg: 'laliga', a: ['barcelona', 'fc barcelona', 'barca'] },
    { id: 'atletico', n: 'Atletico Madrid',  g: 'Spain', lg: 'laliga', a: ['atletico madrid', 'atletico', 'club atletico de madrid'] },
    { id: 'juve',    n: 'Juventus',          g: 'Italy', lg: 'seriea', a: ['juventus', 'juventus fc', 'juve'] },
    { id: 'inter',   n: 'Inter',             g: 'Italy', lg: 'seriea', a: ['inter', 'inter milan', 'internazionale', 'fc internazionale milano'] },
    { id: 'acmilan', n: 'AC Milan',          g: 'Italy', lg: 'seriea', a: ['ac milan', 'milan'], x: ['inter milan', 'fc internazionale milano'] },
    { id: 'napoli',  n: 'Napoli',            g: 'Italy', lg: 'seriea', a: ['napoli', 'ssc napoli'] },
    { id: 'bayern',  n: 'Bayern Munich',     g: 'Germany', lg: 'bundesliga', a: ['bayern munich', 'bayern munchen', 'fc bayern munchen', 'bayern'] },
    { id: 'dortmund', n: 'Dortmund',         g: 'Germany', lg: 'bundesliga', a: ['borussia dortmund', 'dortmund', 'bvb'] },
    { id: 'leverkusen', n: 'Leverkusen',     g: 'Germany', lg: 'bundesliga', a: ['bayer leverkusen', 'leverkusen', 'bayer 04 leverkusen'] },
    { id: 'psg',     n: 'PSG',               g: 'France', lg: 'ligue1', a: ['paris saint germain', 'paris sg', 'psg'] }
  ];
  var GROUPS = ['Tanzania', 'England', 'Spain', 'Italy', 'Germany', 'France'];

  var I18N = {
    en: { title: 'My team', choose: 'Choose your team', change: 'Change', clear: 'Remove', only: 'Only my team', search: 'Search or type a team…',
          useName: 'Use', noMatch: 'No matches for your team.', notInTable: "Your team isn't in this table.", pos: 'Pos', pts: 'pts',
          hint: 'Your team is pinned first and highlighted in Live Scores and League tables.', close: 'Close' },
    sw: { title: 'Timu yangu', choose: 'Chagua timu yako', change: 'Badilisha', clear: 'Ondoa', only: 'Timu yangu tu', search: 'Tafuta au andika timu…',
          useName: 'Tumia', noMatch: 'Hakuna mechi za timu yako.', notInTable: 'Timu yako haipo kwenye jedwali hili.', pos: 'Nafasi', pts: 'pointi',
          hint: 'Timu yako inakaa juu na inaonekana kwa rangi ya kipekee kwenye Live Scores na Msimamo.', close: 'Funga' }
  };
  var lang = String((doc.documentElement.getAttribute('lang') || '')).toLowerCase().indexOf('sw') === 0 ? 'sw' : 'en';
  var T = I18N[lang];
  w.FAV = w.FAV || {};
  w.FAV.i = T;

  var cur = null, open = false, query = '';

  function norm(s) {
    s = String(s == null ? '' : s).toLowerCase();
    try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) { /* ICU ya zamani */ }
    return s.replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').replace(/^\s+|\s+$/g, '');
  }
  function byId(id) { for (var i = 0; i < TEAMS.length; i++) if (TEAMS[i].id === id) return TEAMS[i]; return null; }
  function read(k) { try { return w.localStorage.getItem(k); } catch (e) { return null; } }
  function write(k, v) { try { w.localStorage.setItem(k, v); return true; } catch (e) { return false; } }

  function load() {
    cur = null;
    var raw = read(KEY);
    if (!raw) return;
    try {
      var o = JSON.parse(raw);
      if (!o || typeof o.id !== 'string' || typeof o.n !== 'string' || o.id.length > 30 || o.n.length > 40) return;
      var known = byId(o.id);
      if (known) cur = { id: known.id, n: known.n, a: known.a.slice(), x: (known.x || []).slice(), lg: known.lg };
      else if (o.id === 'custom') { var nn = norm(o.n); if (nn.length >= 2) cur = { id: 'custom', n: o.n.replace(/[<>]/g, '').slice(0, 40), a: [nn], x: [], lg: '' }; }
    } catch (e) { cur = null; }
  }

  /** Je, jina hili la timu ni timu pendwa? (linalingana na majina ya watoa data tofauti) */
  function favIs(name) {
    if (!cur) return false;
    var n = norm(name);
    if (!n) return false;
    var i;
    for (i = 0; i < cur.x.length; i++) if (n === cur.x[i]) return false;
    var padded = ' ' + n + ' ';
    for (i = 0; i < cur.a.length; i++) {
      var a = cur.a[i];
      if (!a || a.length < 3) continue;
      if (n === a || padded.indexOf(' ' + a + ' ') >= 0) return true;
    }
    return false;
  }
  function favGet() { return cur ? { id: cur.id, name: cur.n } : null; }
  function favFilterOn() { return !!cur && read(FKEY) === '1'; }
  function favSetFilter(on) { write(FKEY, on ? '1' : '0'); changed(false); }

  function changed(jump) {
    try { doc.dispatchEvent(new w.CustomEvent('rlg-fav-change', { detail: { team: cur ? cur.id : null } })); } catch (e) { /* ok */ }
    if (typeof w.lsRender === 'function') w.lsRender();
    if (typeof w.stRender === 'function') w.stRender();
    if (jump && cur && cur.lg && w.STD && w.STD.leagues && typeof w.stSelect === 'function') {
      for (var i = 0; i < w.STD.leagues.length; i++) if (w.STD.leagues[i].k === cur.lg) { w.stSelect(cur.lg); break; }
    }
    render();
  }

  /** Inaarifu app (Android) timu ilipobadilika ili ijiandikishe kwa arifa za timu (rlg://fav/<id>). */
  function tellApp() {
    if (!w.RLG_APP) return;
    try { w.location.href = 'rlg://fav/' + encodeURIComponent(cur ? cur.id : 'none') + (cur ? '?n=' + encodeURIComponent(cur.n) : ''); } catch (e) { /* ok */ }
  }

  function favSelect(idOrName) {
    var t = byId(idOrName), name = String(idOrName || '').replace(/[<>]/g, '').replace(/^\s+|\s+$/g, '').slice(0, 40);
    if (t) write(KEY, JSON.stringify({ id: t.id, n: t.n }));
    else if (norm(name).length >= 2) write(KEY, JSON.stringify({ id: 'custom', n: name }));
    else return false;
    load(); open = false; query = '';
    changed(true);
    tellApp();
    return true;
  }
  function favClear() { try { w.localStorage.removeItem(KEY); w.localStorage.removeItem(FKEY); } catch (e) { /* ok */ } cur = null; open = false; changed(false); tellApp(); }

  // ---------------- UI (Glassmorphism) ----------------
  function el(tag, cls, txt) {
    var e = doc.createElement(tag);
    if (cls) e.className = cls;
    if (txt !== undefined && txt !== null) e.textContent = txt;
    return e;
  }
  var root = null, chipsBox = null;

  function renderChips() {
    if (!chipsBox) return;
    chipsBox.innerHTML = '';
    var q = norm(query), any = false;
    GROUPS.forEach(function (g) {
      var items = TEAMS.filter(function (t) { return t.g === g && (!q || norm(t.n).indexOf(q) >= 0 || t.a.some(function (a) { return a.indexOf(q) >= 0; })); });
      if (!items.length) return;
      any = true;
      chipsBox.appendChild(el('div', 'mt-g', g));
      var row = el('div', 'mt-row');
      items.forEach(function (t) {
        var c = el('button', 'mt-chip' + (cur && cur.id === t.id ? ' on' : ''), t.n);
        c.type = 'button';
        c.addEventListener('click', function () { favSelect(t.id); });
        row.appendChild(c);
      });
      chipsBox.appendChild(row);
    });
    var typed = String(query).replace(/^\s+|\s+$/g, '');
    if (typed.length >= 2) {
      var u = el('button', 'mt-chip mt-custom', T.useName + ' "' + typed.slice(0, 40) + '"');
      u.type = 'button';
      u.addEventListener('click', function () { favSelect(typed); });
      chipsBox.appendChild(u);
    } else if (!any) chipsBox.appendChild(el('div', 'mt-empty', T.search));
  }

  function render() {
    if (!root) return;
    root.innerHTML = '';
    var head = el('div', 'mt-head');
    head.appendChild(el('span', 'mt-star', '\u2605'));
    head.appendChild(el('b', '', T.title));
    root.appendChild(head);

    if (cur) {
      var line = el('div', 'mt-cur');
      line.appendChild(el('span', 'mt-badge', cur.n.charAt(0).toUpperCase()));
      var nm = el('div', 'mt-name');
      nm.appendChild(el('b', '', cur.n));
      nm.appendChild(el('span', '', T.hint));
      line.appendChild(nm);
      root.appendChild(line);

      var acts = el('div', 'mt-acts');
      var ch = el('button', 'mt-btn', open ? T.close : T.change); ch.type = 'button';
      ch.addEventListener('click', function () { open = !open; render(); });
      var cl = el('button', 'mt-btn ghost', T.clear); cl.type = 'button';
      cl.addEventListener('click', favClear);
      acts.appendChild(ch); acts.appendChild(cl);
      root.appendChild(acts);

      var sw = el('label', 'mt-sw');
      var cb = el('input'); cb.type = 'checkbox'; cb.checked = favFilterOn();
      cb.addEventListener('change', function () { favSetFilter(cb.checked); });
      sw.appendChild(cb); sw.appendChild(el('i')); sw.appendChild(el('span', '', T.only));
      root.appendChild(sw);
    } else {
      var go = el('button', 'mt-btn big', '\u2605 ' + T.choose); go.type = 'button';
      go.addEventListener('click', function () { open = !open; render(); });
      root.appendChild(go);
    }

    if (open) {
      var panel = el('div', 'mt-panel');
      var inp = el('input', 'mt-search'); inp.type = 'text'; inp.placeholder = T.search; inp.value = query; inp.maxLength = 40;
      inp.setAttribute('autocomplete', 'off');
      inp.addEventListener('input', function () { query = inp.value; renderChips(); });
      panel.appendChild(inp);
      chipsBox = el('div', 'mt-chips');
      panel.appendChild(chipsBox);
      root.appendChild(panel);
      renderChips();
    }
  }

  function mount() {
    root = doc.getElementById('myteam');
    if (root) render();
  }

  load();
  w.favIs = favIs; w.favGet = favGet; w.favSelect = favSelect; w.favClear = favClear;
  w.favFilterOn = favFilterOn; w.favSetFilter = favSetFilter;
  w.RLGFav = { teams: TEAMS.map(function (t) { return { id: t.id, name: t.n, group: t.g }; }), norm: norm };
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', mount); else mount();
  if (w.addEventListener) w.addEventListener('storage', function (e) { if (e.key === KEY || e.key === FKEY) { load(); changed(false); } });
})(window);
