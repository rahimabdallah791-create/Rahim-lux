package com.rahimlux.go

import android.content.Context
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** Kufuli ya alama ya kidole / uso (Android 11+: pia PIN au pattern ya simu). Hakuna data inayoondoka kwenye simu. */
object AppLock {
    private fun auth(): Int =
        if (Build.VERSION.SDK_INT >= 30) Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL else Authenticators.BIOMETRIC_WEAK

    /** Je, simu ina alama ya kidole/uso (au kufuli ya skrini kwa Android 11+) iliyowekwa? */
    fun canAuth(ctx: Context): Boolean = try {
        BiometricManager.from(ctx).canAuthenticate(auth()) == BiometricManager.BIOMETRIC_SUCCESS
    } catch (e: Exception) {
        false
    }

    fun prompt(act: FragmentActivity, title: String, subtitle: String, cancel: String, done: (Boolean) -> Unit) {
        var finished = false
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                if (!finished) { finished = true; done(true) }
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (!finished) { finished = true; done(false) }
            }
        }
        val info = BiometricPrompt.PromptInfo.Builder().setTitle(title).setSubtitle(subtitle).setAllowedAuthenticators(auth())
        if (Build.VERSION.SDK_INT < 30) info.setNegativeButtonText(cancel) // inahitajika kama DEVICE_CREDENTIAL haipo
        try {
            BiometricPrompt(act, ContextCompat.getMainExecutor(act), cb).authenticate(info.build())
        } catch (e: Exception) {
            if (!finished) { finished = true; done(false) }
        }
    }
}
