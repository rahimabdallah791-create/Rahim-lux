package com.rahimlux.go

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Kurasa zilizohifadhiwa offline: fungua, fungua ukurasa asili, futa moja au zote. */
class OfflinePagesActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#07070F"))
        root.addView(ui.header(ui.t("Offline pages", "Kurasa za offline"), listOf("🗑" to { confirmAll() })))
        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(ui.dp(14), ui.dp(4), ui.dp(14), ui.dp(24))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun small(label: String, click: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 18f
        b.setTextColor(Color.WHITE)
        b.setPadding(ui.dp(12), ui.dp(8), ui.dp(12), ui.dp(8))
        b.setOnClickListener { click() }
        return b
    }

    private fun render() {
        list.removeAllViews()
        val pages = OfflineRepo.list(this, store)
        if (pages.isEmpty()) {
            val tv = TextView(this)
            tv.text = ui.t(
                "No pages saved yet. Open an article, then choose Menu > Save offline.",
                "Bado hakuna ukurasa. Fungua habari, kisha chagua Menu > Hifadhi offline."
            )
            tv.setTextColor(Color.parseColor("#D0CEEA"))
            tv.textSize = 14f
            tv.gravity = Gravity.CENTER
            tv.setPadding(ui.dp(24), ui.dp(60), ui.dp(24), ui.dp(24))
            list.addView(tv)
            return
        }
        val sum = TextView(this)
        sum.text = ui.t("${pages.size} pages · ${pages.sumOf { it.size } / 1024} KB", "Kurasa ${pages.size} · ${pages.sumOf { it.size } / 1024} KB")
        sum.setTextColor(Color.parseColor("#9C9ABF"))
        sum.textSize = 12f
        sum.setPadding(ui.dp(4), ui.dp(8), 0, ui.dp(8))
        list.addView(sum)
        val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())
        val card = ui.card()
        for (p in pages) {
            val host = try { Uri.parse(p.url).host?.removePrefix("www.") } catch (e: Exception) { null }
            val sub = listOfNotNull(host, fmt.format(Date(p.ts)), (p.size / 1024).toString() + " KB").joinToString(" · ")
            val trailing = LinearLayout(this)
            trailing.gravity = Gravity.CENTER_VERTICAL
            if (p.url.startsWith("http")) trailing.addView(small("🌐") { openOriginal(p) })
            trailing.addView(small("🗑") { confirmOne(p) })
            ui.row(card, p.title, sub, trailing) { openOffline(p) }
        }
        ui.addCard(list, card)
    }

    private fun openOffline(p: OfflineRepo.Page) {
        setResult(RESULT_OK, Intent().putExtra("file", p.file))
        finish()
    }

    private fun openOriginal(p: OfflineRepo.Page) {
        setResult(RESULT_OK, Intent().putExtra("url", p.url))
        finish()
    }

    private fun confirmOne(p: OfflineRepo.Page) {
        AlertDialog.Builder(this)
            .setTitle(ui.t("Delete this saved page?", "Futa ukurasa huu uliohifadhiwa?"))
            .setMessage(p.title)
            .setPositiveButton(ui.t("Delete", "Futa")) { _, _ -> OfflineRepo.delete(this, store, p.file); render() }
            .setNegativeButton(ui.t("Cancel", "Ghairi"), null)
            .show()
    }

    private fun confirmAll() {
        if (OfflineRepo.list(this, store).isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(ui.t("Delete all saved pages?", "Futa kurasa zote zilizohifadhiwa?"))
            .setPositiveButton(ui.t("Delete all", "Futa zote")) { _, _ -> OfflineRepo.deleteAll(this, store); render() }
            .setNegativeButton(ui.t("Cancel", "Ghairi"), null)
            .show()
    }
}
