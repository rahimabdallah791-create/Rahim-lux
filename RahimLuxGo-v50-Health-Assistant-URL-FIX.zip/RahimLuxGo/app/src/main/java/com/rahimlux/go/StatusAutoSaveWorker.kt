package com.rahimlux.go

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Inahifadhi status mpya nyuma ya pazia (kila ~30 dakika) kama "Auto-save" imewashwa. Android inaweza kuchelewesha kulingana na betri. */
class StatusAutoSaveWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        if (Store(applicationContext).ssAuto) {
            try { StatusRepo.autoSave(applicationContext) } catch (e: Exception) { /* jaribu tena mzunguko ujao */ }
        }
        return Result.success()
    }

    companion object {
        private const val NAME = "rlg_status_autosave"

        fun schedule(ctx: Context, on: Boolean) {
            val wm = WorkManager.getInstance(ctx.applicationContext)
            if (!on) { wm.cancelUniqueWork(NAME); return }
            val req = PeriodicWorkRequest.Builder(StatusAutoSaveWorker::class.java, 30, TimeUnit.MINUTES).build()
            wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun runNow(ctx: Context) {
            WorkManager.getInstance(ctx.applicationContext).enqueue(OneTimeWorkRequest.from(StatusAutoSaveWorker::class.java))
        }
    }
}
