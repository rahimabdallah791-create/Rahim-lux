package com.rahimlux.go

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * WhatsApp Status Saver — msingi.
 * WhatsApp inaweka status ulizoziona kwenye folda ya ".Statuses" ndani ya simu yako. Tunasoma folda hiyo TU baada ya wewe kuruhusu
 * (Storage Access Framework), tunaonyesha picha/video, na kuhifadhi nakala kwenye Gallery. Hakuna kinachopakiwa mtandaoni.
 */
object StatusRepo {
    const val SRC_WA = "wa"
    const val SRC_WAB = "wab"
    private const val AUTH = "com.android.externalstorage.documents"
    private const val ALBUM = "Rahim Lux Go Status"

    class Item(val uri: Uri, val name: String, val mime: String, val modified: Long, val size: Long) {
        val isVideo get() = mime.startsWith("video")
        val key get() = "$name:$size"
    }

    class Saved(val uri: Uri, val name: String, val mime: String, val time: Long, val key: String = "") {
        val isVideo get() = mime.startsWith("video")
    }

    private class Row(val id: String, val name: String, val mime: String, val modified: Long, val size: Long)

    private val dirCache = ConcurrentHashMap<String, String>()

    fun invalidate() = dirCache.clear()

    fun pkgOf(src: String) = if (src == SRC_WAB) "com.whatsapp.w4b" else "com.whatsapp"

    fun treeOf(s: Store, src: String): Uri? {
        val v = if (src == SRC_WAB) s.ssTreeWab else s.ssTreeWa
        return if (v.isEmpty()) null else Uri.parse(v)
    }

    /** Intent ya kuchagua folda: mchaguzi wa faili unaanzia moja kwa moja kwenye ".Statuses". */
    fun pickIntent(src: String): Intent {
        val pkg = pkgOf(src)
        val folder = if (src == SRC_WAB) "WhatsApp Business" else "WhatsApp"
        val rel = if (Build.VERSION.SDK_INT >= 30) "Android/media/$pkg/$folder/Media/.Statuses" else "$folder/Media/.Statuses"
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildDocumentUri(AUTH, "primary:$rel"))
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        return i
    }

    // ---------------- kusoma folda ----------------
    private fun children(ctx: Context, tree: Uri, parentId: String): List<Row> {
        val out = ArrayList<Row>()
        try {
            val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                DocumentsContract.Document.COLUMN_SIZE
            )
            ctx.contentResolver.query(uri, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    out.add(Row(id, c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), c.getLong(4)))
                }
            }
        } catch (e: Exception) {
            // ruhusa imeondolewa au folda haipo
        }
        return out
    }

    private fun nameOf(ctx: Context, tree: Uri, id: String): String {
        try {
            val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
            ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (e: Exception) {
            // ignore
        }
        return ""
    }

    /** Inapata folda ya ".Statuses" ndani ya folda aliyochagua mtumiaji (hata akichagua folda ya juu zaidi). */
    fun resolveFolder(ctx: Context, tree: Uri): String? {
        val key = tree.toString()
        dirCache[key]?.let { return it }
        val rootId = try { DocumentsContract.getTreeDocumentId(tree) } catch (e: Exception) { return null }
        if (nameOf(ctx, tree, rootId) == ".Statuses") { dirCache[key] = rootId; return rootId }
        val queue = ArrayDeque<Pair<String, Int>>()
        queue.add(rootId to 0)
        var visited = 0
        while (queue.isNotEmpty() && visited < 300) {
            val (id, depth) = queue.removeFirst()
            visited++
            for (r in children(ctx, tree, id)) {
                if (r.mime != DocumentsContract.Document.MIME_TYPE_DIR) continue
                if (r.name == ".Statuses") { dirCache[key] = r.id; return r.id }
                if (depth < 6) queue.add(r.id to depth + 1)
            }
        }
        return null
    }

    /** Status zilizopo sasa (picha na video), mpya kwanza. */
    fun list(ctx: Context, tree: Uri): List<Item> {
        val dir = resolveFolder(ctx, tree) ?: return emptyList()
        return children(ctx, tree, dir)
            .filter { !it.name.startsWith(".") && (it.mime.startsWith("image/") || it.mime.startsWith("video/")) }
            .map { Item(DocumentsContract.buildDocumentUriUsingTree(tree, it.id), it.name, it.mime, it.modified, it.size) }
            .sortedByDescending { it.modified }
    }

    // ---------------- kuhifadhi / orodha ya zilizohifadhiwa ----------------
    @Synchronized fun savedList(s: Store): List<Saved> {
        val out = ArrayList<Saved>()
        try {
            val a = JSONArray(s.ssSavedJson)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Saved(Uri.parse(o.getString("u")), o.optString("n"), o.optString("m"), o.optLong("t"), o.optString("k")))
            }
        } catch (e: Exception) {
            // orodha mbovu: anza upya
        }
        return out
    }

    @Synchronized private fun writeSaved(s: Store, list: List<Saved>) {
        val a = JSONArray()
        for (v in list.take(500)) a.put(JSONObject().put("u", v.uri.toString()).put("n", v.name).put("m", v.mime).put("t", v.time).put("k", v.key))
        s.ssSavedJson = a.toString()
    }

    @Synchronized fun seenSet(s: Store): Set<String> {
        val out = HashSet<String>()
        try {
            val a = JSONArray(s.ssSeenJson)
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
            // ignore
        }
        return out
    }

    @Synchronized fun addSaved(s: Store, v: Saved, seenKey: String) {
        writeSaved(s, listOf(Saved(v.uri, v.name, v.mime, v.time, seenKey)) + savedList(s))
        val seen = ArrayList(seenSet(s))
        if (!seen.contains(seenKey)) seen.add(seenKey)
        val a = JSONArray()
        for (k in seen.takeLast(1000)) a.put(k)
        s.ssSeenJson = a.toString()
    }

    @Synchronized fun removeSaved(s: Store, uri: Uri) {
        writeSaved(s, savedList(s).filter { it.uri != uri })
    }

    fun exists(ctx: Context, uri: Uri): Boolean {
        return try {
            if (uri.scheme == "file") File(uri.path ?: return false).exists()
            else { ctx.contentResolver.openFileDescriptor(uri, "r")?.close(); true }
        } catch (e: Exception) { false }
    }

    fun deleteSaved(ctx: Context, s: Store, v: Saved) {
        try {
            if (v.uri.scheme == "file") {
                val f = File(v.uri.path ?: "")
                f.delete()
                MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
            } else ctx.contentResolver.delete(v.uri, null, null)
        } catch (e: Exception) {
            // faili inaweza kuwa tayari imefutwa kutoka Gallery
        }
        removeSaved(s, v.uri)
    }

    /** Inahifadhi nakala kwenye Gallery (Pictures / Movies > Rahim Lux Go Status). Tumia background thread. */
    fun save(ctx: Context, item: Item): Saved? {
        return try {
            val isVideo = item.isVideo
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val ext = item.name.substringAfterLast('.', if (isVideo) "mp4" else "jpg").lowercase(Locale.US).take(5)
            val display = "RLG_Status_" + stamp + "_" + Integer.toHexString(item.name.hashCode()).takeLast(4) + "." + ext
            val uri: Uri
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, display)
                values.put(MediaStore.MediaColumns.MIME_TYPE, item.mime)
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, (if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES) + "/" + ALBUM)
                values.put(MediaStore.MediaColumns.IS_PENDING, 1)
                val coll = if (isVideo) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                uri = ctx.contentResolver.insert(coll, values) ?: return null
                val ok = ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    ctx.contentResolver.openInputStream(item.uri)?.use { it.copyTo(out); true }
                } ?: false
                if (!ok) { ctx.contentResolver.delete(uri, null, null); return null }
                val done = ContentValues()
                done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                ctx.contentResolver.update(uri, done, null, null)
            } else {
                @Suppress("DEPRECATION")
                val base = Environment.getExternalStoragePublicDirectory(if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES)
                val dir = File(base, ALBUM)
                if (!dir.exists() && !dir.mkdirs()) return null
                val f = File(dir, display)
                val ok = ctx.contentResolver.openInputStream(item.uri)?.use { i -> FileOutputStream(f).use { o -> i.copyTo(o); true } } ?: false
                if (!ok) return null
                MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf(item.mime), null)
                uri = Uri.fromFile(f)
            }
            Saved(uri, display, item.mime, System.currentTimeMillis())
        } catch (e: Throwable) {
            null
        }
    }

    /** Inahifadhi status mpya zote ambazo hazijahifadhiwa bado. Inarudisha idadi. Tumia background thread. */
    @Synchronized fun autoSave(ctx: Context): Int {
        val s = Store(ctx)
        var n = 0
        for (src in listOf(SRC_WA, SRC_WAB)) {
            val tree = treeOf(s, src) ?: continue
            for (item in list(ctx, tree)) {
                val key = src + ":" + item.key
                if (seenSet(s).contains(key)) continue
                val v = save(ctx, item) ?: continue
                addSaved(s, v, key)
                n++
            }
        }
        return n
    }

    // ---------------- picha ndogo na picha kubwa ----------------
    private fun scaleDown(b: Bitmap, side: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= side) return b
        val f = side.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }

    fun decode(ctx: Context, uri: Uri, side: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > side * 2) sample *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            val b = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
            scaleDown(b, side)
        } catch (e: Throwable) {
            null
        }
    }

    fun thumb(ctx: Context, uri: Uri, isVideo: Boolean, side: Int): Bitmap? {
        if (!isVideo) return decode(ctx, uri, side)
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val b = r.getFrameAtTime(0) ?: return null
            scaleDown(b, side)
        } catch (e: Throwable) {
            null
        } finally {
            try { r.release() } catch (e: Exception) { /* ignore */ }
        }
    }
}
