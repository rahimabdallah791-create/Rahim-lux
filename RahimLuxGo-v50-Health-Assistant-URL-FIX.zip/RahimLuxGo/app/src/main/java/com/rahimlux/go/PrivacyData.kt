package com.rahimlux.go

import android.content.Context
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebStorage
import android.webkit.WebView

/** Aina za vitu vilivyozuiwa na makadirio ya ukubwa wa wastani (makadirio tu; hayajapimwa kwenye mtandao). */
object Blk {
    const val AD = 0
    const val TRACKER = 1
    const val MEDIA = 2
    val bytes = longArrayOf(35L * 1024, 12L * 1024, 1536L * 1024)
}

/** Kufuta data kwa uchaguzi wa mtumiaji. */
object PrivacyData {
    const val HISTORY = 1
    const val SEARCHES = 2
    const val COOKIES = 4
    const val CACHE = 8
    const val PERMS = 16
    const val STATS = 32
    const val TABS = 64
    const val OFFLINE = 128
    const val ALL = HISTORY or SEARCHES or COOKIES or CACHE or PERMS or STATS or TABS or OFFLINE

    /** Tumia kwenye main thread (inatengeneza WebView ya muda kufuta cache). */
    fun clear(ctx: Context, store: Store, mask: Int) {
        if ((mask and HISTORY) != 0) store.clearHistory()
        if ((mask and SEARCHES) != 0) store.clearSearches()
        if ((mask and COOKIES) != 0) {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
        }
        if ((mask and CACHE) != 0) {
            try {
                val w = WebView(ctx.applicationContext)
                w.clearCache(true)
                w.clearFormData()
                w.destroy()
            } catch (e: Exception) {
                // endelea na vingine
            }
        }
        if ((mask and PERMS) != 0) {
            SitePerms.clearAll(store)
            try { GeolocationPermissions.getInstance().clearAll() } catch (e: Exception) { /* ignore */ }
        }
        if ((mask and STATS) != 0) store.resetPrivacyStats()
        if ((mask and TABS) != 0) { TabArchive.clearClosed(store); TabArchive.clearSessions(store) }
        if ((mask and OFFLINE) != 0) OfflineRepo.deleteAll(ctx, store)
        // MainActivity itasafisha history/cache ya tab zilizo wazi inaporudi mbele
        if ((mask and (HISTORY or CACHE or COOKIES)) != 0) store.webClearPending = true
    }
}
