package com.rahimlux.go

import android.net.Uri
import java.util.Locale

/** Tafsiri ya ukurasa kupitia Google Translate (translate.goog) bila API key. Anwani ya ukurasa inatumwa kwa Google. */
object PageTranslate {
    val langs = listOf(
        "sw" to "Kiswahili", "en" to "English", "fr" to "Français", "ar" to "العربية", "es" to "Español",
        "pt" to "Português", "de" to "Deutsch", "zh-CN" to "中文", "hi" to "हिन्दी", "tr" to "Türkçe"
    )
    private const val SUFFIX = ".translate.goog"

    fun isTranslated(url: String): Boolean = try { Uri.parse(url).host?.endsWith(SUFFIX) == true } catch (e: Exception) { false }

    /** https://www.bbc.com/a?x=1  ->  https://www-bbc-com.translate.goog/a?x=1&_x_tr_sl=auto&_x_tr_tl=sw... (null ikiwa haiwezekani) */
    fun translate(url: String, lang: String): String? {
        val u = try { Uri.parse(url) } catch (e: Exception) { return null }
        if (u.scheme != "https" && u.scheme != "http") return null
        val host = u.host?.lowercase(Locale.US) ?: return null
        if (host.endsWith(SUFFIX) || u.port != -1) return null
        val gh = host.replace("-", "--").replace(".", "-") + SUFFIX
        val path = (u.encodedPath ?: "").ifEmpty { "/" }
        val q = u.encodedQuery
        var out = "https://$gh$path?" + (if (q.isNullOrEmpty()) "" else "$q&") +
            "_x_tr_sl=auto&_x_tr_tl=$lang&_x_tr_hl=$lang&_x_tr_pto=wapp"
        u.encodedFragment?.let { out += "#$it" }
        return out
    }

    /** Rudi kwenye anwani asili. */
    fun original(url: String): String? {
        val u = try { Uri.parse(url) } catch (e: Exception) { return null }
        val host = u.host ?: return null
        if (!host.endsWith(SUFFIX)) return null
        val orig = host.removeSuffix(SUFFIX).replace("--", "\u0000").replace("-", ".").replace("\u0000", "-")
        val keep = (u.encodedQuery ?: "").split("&").filter { it.isNotEmpty() && !it.startsWith("_x_tr_") }
        var out = "https://$orig" + (u.encodedPath ?: "").ifEmpty { "/" }
        if (keep.isNotEmpty()) out += "?" + keep.joinToString("&")
        u.encodedFragment?.let { out += "#$it" }
        return out
    }
}
