package com.rahimlux.go

import android.net.Uri
import org.json.JSONObject

/**
 * Maamuzi ya ruhusa za tovuti (mahali, kamera, kipaza sauti), yanayohifadhiwa na app yenyewe.
 * Android WebView haikumbuki kamera/kipaza sauti yenyewe, na haitumii web notifications; kwa hiyo tunadhibiti hapa.
 */
object SitePerms {
    const val ASK = 0
    const val ALLOW = 1
    const val BLOCK = -1

    const val GEO = 0
    const val CAM = 1
    const val MIC = 2
    val KINDS = intArrayOf(GEO, CAM, MIC)
    private val KEYS = arrayOf("geo", "cam", "mic")

    fun icon(kind: Int) = when (kind) { GEO -> "📍"; CAM -> "📷"; else -> "🎤" }

    fun label(kind: Int, sw: Boolean) = when (kind) {
        GEO -> if (sw) "Mahali" else "Location"
        CAM -> if (sw) "Kamera" else "Camera"
        else -> if (sw) "Kipaza sauti" else "Microphone"
    }

    /** https://Example.com:443/path -> https://example.com (bandari isiyo ya kawaida inabaki). */
    fun origin(raw: String): String? = try {
        val u = Uri.parse(raw)
        val scheme = (u.scheme ?: "").lowercase()
        val host = (u.host ?: "").lowercase()
        if ((scheme != "https" && scheme != "http") || host.isEmpty()) null
        else {
            val port = u.port
            val def = (scheme == "https" && port == 443) || (scheme == "http" && port == 80)
            if (port == -1 || def) "$scheme://$host" else "$scheme://$host:$port"
        }
    } catch (e: Exception) {
        null
    }

    fun host(origin: String): String = try { Uri.parse(origin).host ?: origin } catch (e: Exception) { origin }

    fun default(s: Store, kind: Int): Int = when (kind) {
        GEO -> s.permDefGeo
        CAM -> s.permDefCam
        else -> s.permDefMic
    }

    private fun readAll(s: Store): JSONObject = try { JSONObject(s.sitePermsJson) } catch (e: Exception) { JSONObject() }

    @Synchronized fun get(s: Store, origin: String, kind: Int): Int = readAll(s).optJSONObject(origin)?.optInt(KEYS[kind], ASK) ?: ASK

    /** Uamuzi wa mwisho: uliohifadhiwa kwa tovuti, la sivyo chaguo-msingi (ASK au BLOCK). */
    fun effective(s: Store, origin: String, kind: Int): Int {
        val v = get(s, origin, kind)
        return if (v != ASK) v else default(s, kind)
    }

    @Synchronized fun set(s: Store, origin: String, kind: Int, value: Int) {
        val all = readAll(s)
        val o = all.optJSONObject(origin) ?: JSONObject()
        if (value == ASK) o.remove(KEYS[kind]) else o.put(KEYS[kind], value)
        if (o.length() == 0) all.remove(origin) else all.put(origin, o)
        // Weka kikomo ili orodha isikue bila mwisho
        while (all.length() > 200) { val k = all.keys().next(); all.remove(k) }
        s.sitePermsJson = all.toString()
    }

    /** origin -> [geo, cam, mic] kwa tovuti zenye uamuzi uliohifadhiwa. */
    @Synchronized fun all(s: Store): List<Pair<String, IntArray>> {
        val a = readAll(s)
        val out = ArrayList<Pair<String, IntArray>>()
        for (k in a.keys()) {
            val o = a.optJSONObject(k) ?: continue
            out.add(k to IntArray(3) { o.optInt(KEYS[it], ASK) })
        }
        return out.sortedBy { it.first }
    }

    @Synchronized fun clearSite(s: Store, origin: String) {
        val a = readAll(s)
        a.remove(origin)
        s.sitePermsJson = a.toString()
    }

    @Synchronized fun clearAll(s: Store) { s.sitePermsJson = "{}" }
}
