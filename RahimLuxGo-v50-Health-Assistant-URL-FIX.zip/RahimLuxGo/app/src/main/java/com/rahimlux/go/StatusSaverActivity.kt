package com.rahimlux.go

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/**
 * WhatsApp Status Saver: status ulizoziona kwenye WhatsApp zinaonekana hapa; unaweza kuzihifadhi kwenye Gallery, kuzishiriki au kuwasha
 * "Auto-save". Tunasoma tu folda ya ".Statuses" uliyoruhusu; hakuna kinachopakiwa mtandaoni.
 */
class StatusSaverActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var srcRow: LinearLayout
    private lateinit var tabRow: LinearLayout
    private lateinit var grid: GridView
    private lateinit var infoBox: LinearLayout
    private lateinit var infoText: TextView
    private lateinit var infoBtn: TextView
    private lateinit var infoBtn2: TextView
    private lateinit var summaryText: TextView
    private lateinit var selBar: LinearLayout
    private lateinit var selText: TextView
    private val adapter = Adapter()

    private var src = StatusRepo.SRC_WA
    private var tab = "img" // img | vid | saved
    private var cells: List<Cell> = emptyList()
    private var seen: Set<String> = emptySet()
    private val selected = LinkedHashSet<String>()
    private var cellSize = 0
    private var pickSrc = StatusRepo.SRC_WA
    private var pendingSave: (() -> Unit)? = null
    private val pool = Executors.newFixedThreadPool(3)
    private val cache = object : LruCache<String, Bitmap>(maxOf(4 * 1024 * 1024, (Runtime.getRuntime().maxMemory() / 16).toInt())) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private class Cell(
        val key: String, val uri: Uri, val isVideo: Boolean, val mime: String,
        val item: StatusRepo.Item?, val saved: StatusRepo.Saved?, val seenKey: String?
    )

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r -> onPicked(r.data?.data) }
    private val writePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val run = pendingSave
        pendingSave = null
        if (ok && run != null) run() else toast(ui.t("Storage permission is needed to save.", "Ruhusa ya hifadhi inahitajika ili kuhifadhi."))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)
        src = store.ssSrc

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#07070F"))
        root.addView(ui.header("Status Saver", listOf("↻" to { reload() }, "⚙" to { autoDialog() })))

        // Polished black-and-gold overview card
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.HORIZONTAL
        hero.gravity = Gravity.CENTER_VERTICAL
        hero.setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
        val heroBg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#252016"), Color.parseColor("#151519")))
        heroBg.cornerRadius = ui.dp(18).toFloat()
        heroBg.setStroke(ui.dp(1), Color.parseColor("#558B5CF6"))
        hero.background = heroBg
        val heroIcon = TextView(this)
        heroIcon.text = "▣"
        heroIcon.textSize = 25f
        heroIcon.gravity = Gravity.CENTER
        heroIcon.setTextColor(ui.gold)
        val iconBg = GradientDrawable()
        iconBg.shape = GradientDrawable.OVAL
        iconBg.setColor(Color.parseColor("#2A2150"))
        heroIcon.background = iconBg
        hero.addView(heroIcon, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        val heroCopy = LinearLayout(this)
        heroCopy.orientation = LinearLayout.VERTICAL
        heroCopy.setPadding(ui.dp(12), 0, ui.dp(8), 0)
        val heroTitle = TextView(this)
        heroTitle.text = ui.t("Your statuses, one place", "Status zako sehemu moja")
        heroTitle.textSize = 16f
        heroTitle.setTextColor(Color.WHITE)
        heroTitle.setTypeface(null, Typeface.BOLD)
        val heroSub = TextView(this)
        heroSub.text = ui.t("Preview · save · share", "Angalia · hifadhi · shiriki")
        heroSub.textSize = 12f
        heroSub.setTextColor(Color.parseColor("#BDB8AC"))
        heroSub.setPadding(0, ui.dp(3), 0, 0)
        heroCopy.addView(heroTitle)
        heroCopy.addView(heroSub)
        hero.addView(heroCopy, LinearLayout.LayoutParams(0, -2, 1f))
        summaryText = TextView(this)
        summaryText.text = "0"
        summaryText.textSize = 18f
        summaryText.setTypeface(null, Typeface.BOLD)
        summaryText.setTextColor(ui.gold)
        summaryText.gravity = Gravity.CENTER
        val countBg = GradientDrawable()
        countBg.cornerRadius = ui.dp(12).toFloat()
        countBg.setColor(Color.parseColor("#2A2150"))
        summaryText.background = countBg
        hero.addView(summaryText, LinearLayout.LayoutParams(ui.dp(48), ui.dp(42)))
        root.addView(hero, LinearLayout.LayoutParams(-1, -2).also {
            it.setMargins(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(12))
        })

        srcRow = LinearLayout(this)
        srcRow.gravity = Gravity.CENTER_VERTICAL
        srcRow.setPadding(ui.dp(14), 0, ui.dp(14), ui.dp(8))
        root.addView(srcRow)
        tabRow = LinearLayout(this)
        tabRow.gravity = Gravity.CENTER_VERTICAL
        tabRow.setPadding(ui.dp(14), 0, ui.dp(14), ui.dp(10))
        root.addView(tabRow)

        val frame = FrameLayout(this)
        grid = GridView(this)
        grid.numColumns = 3
        grid.horizontalSpacing = ui.dp(7)
        grid.verticalSpacing = ui.dp(7)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.setPadding(ui.dp(14), ui.dp(4), ui.dp(14), ui.dp(14))
        grid.clipToPadding = false
        grid.selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> if (pos < cells.size) onTap(cells[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ -> if (pos < cells.size) toggleSelect(cells[pos]); true }
        frame.addView(grid, FrameLayout.LayoutParams(-1, -1))

        infoBox = LinearLayout(this)
        infoBox.orientation = LinearLayout.VERTICAL
        infoBox.gravity = Gravity.CENTER
        infoBox.setPadding(ui.dp(28), ui.dp(20), ui.dp(28), ui.dp(20))
        infoText = TextView(this)
        infoText.setTextColor(Color.parseColor("#D0CEEA")); infoText.textSize = 14f; infoText.gravity = Gravity.CENTER
        infoText.setLineSpacing(0f, 1.2f)
        infoBtn = bigButton()
        infoBtn2 = bigButton()
        infoBox.addView(infoText)
        infoBox.addView(infoBtn, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ui.dp(16) })
        infoBox.addView(infoBtn2, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ui.dp(10) })
        frame.addView(infoBox, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        selBar = LinearLayout(this)
        selBar.gravity = Gravity.CENTER_VERTICAL
        selBar.setBackgroundColor(Color.parseColor("#17171C"))
        selBar.setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(10))
        selText = TextView(this)
        selText.setTextColor(Color.WHITE); selText.textSize = 14f
        selBar.addView(selText, LinearLayout.LayoutParams(0, -2, 1f))
        val saveSel = bigButton()
        saveSel.text = ui.t("💾 Save", "💾 Hifadhi")
        saveSel.setOnClickListener { saveCells(cells.filter { it.key in selected }) }
        val cancelSel = bigButton()
        cancelSel.text = ui.t("Cancel", "Ghairi")
        cancelSel.setOnClickListener { selected.clear(); updateSelBar(); adapter.notifyDataSetChanged() }
        selBar.addView(saveSel)
        selBar.addView(cancelSel, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = ui.dp(8) })
        selBar.visibility = View.GONE
        root.addView(selBar)
        setContentView(root)

        cellSize = (resources.displayMetrics.widthPixels - ui.dp(14) * 2 - ui.dp(7) * 2) / 3
        buildChips()
        if (!store.ssIntro) introDialog()
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    override fun onDestroy() {
        super.onDestroy()
        pool.shutdownNow()
    }

    // ---------------- UI ndogo ----------------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun bigButton(): TextView {
        val b = TextView(this)
        b.textSize = 14f; b.setTypeface(null, Typeface.BOLD); b.setTextColor(Color.BLACK)
        b.setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(10))
        val bg = GradientDrawable()
        bg.cornerRadius = ui.dp(14).toFloat(); bg.setColor(ui.gold)
        b.background = bg
        b.gravity = Gravity.CENTER
        return b
    }

    private fun barBtn(label: String): TextView {
        val b = TextView(this)
        b.text = label; b.textSize = 14f; b.setTextColor(Color.WHITE)
        b.setPadding(ui.dp(14), ui.dp(9), ui.dp(14), ui.dp(9))
        val bg = GradientDrawable()
        bg.cornerRadius = ui.dp(16).toFloat(); bg.setColor(Color.parseColor("#66000000")); bg.setStroke(1, Color.parseColor("#55FFFFFF"))
        b.background = bg
        return b
    }

    private fun chip(parent: LinearLayout, label: String, on: Boolean, click: () -> Unit) {
        val tv = TextView(this)
        tv.text = label; tv.textSize = 13f
        tv.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8))
        val bg = GradientDrawable()
        bg.cornerRadius = ui.dp(18).toFloat()
        if (on) { bg.setColor(ui.gold); tv.setTextColor(Color.BLACK); tv.setTypeface(null, Typeface.BOLD) }
        else { bg.setColor(Color.parseColor("#171730")); tv.setTextColor(Color.WHITE) }
        tv.background = bg
        tv.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.rightMargin = ui.dp(8)
        parent.addView(tv, lp)
    }

    private fun buildChips() {
        srcRow.removeAllViews(); tabRow.removeAllViews()
        chip(srcRow, "WhatsApp", src == StatusRepo.SRC_WA) { switchSrc(StatusRepo.SRC_WA) }
        chip(srcRow, "WhatsApp Business", src == StatusRepo.SRC_WAB) { switchSrc(StatusRepo.SRC_WAB) }
        chip(tabRow, ui.t("Images", "Picha"), tab == "img") { switchTab("img") }
        chip(tabRow, "Video", tab == "vid") { switchTab("vid") }
        chip(tabRow, ui.t("Saved", "Zilizohifadhiwa"), tab == "saved") { switchTab("saved") }
        srcRow.visibility = if (tab == "saved") View.GONE else View.VISIBLE
    }

    private fun switchSrc(s: String) { src = s; store.ssSrc = s; buildChips(); reload() }
    private fun switchTab(t: String) { tab = t; buildChips(); reload() }

    private fun showInfo(text: String, b1: Pair<String, () -> Unit>?, b2: Pair<String, () -> Unit>? = null) {
        infoBox.visibility = View.VISIBLE
        infoText.text = text
        infoBtn.visibility = if (b1 == null) View.GONE else View.VISIBLE
        if (b1 != null) { infoBtn.text = b1.first; infoBtn.setOnClickListener { b1.second() } }
        infoBtn2.visibility = if (b2 == null) View.GONE else View.VISIBLE
        if (b2 != null) { infoBtn2.text = b2.first; infoBtn2.setOnClickListener { b2.second() } }
    }

    private fun updateSelBar() {
        selBar.visibility = if (selected.isEmpty()) View.GONE else View.VISIBLE
        selText.text = ui.t("${selected.size} selected", "${selected.size} zimechaguliwa")
    }

    private fun introDialog() {
        AlertDialog.Builder(this)
            .setTitle("Status Saver")
            .setMessage(
                ui.t(
                    "This shows statuses that WhatsApp has already stored on your phone (the ones you viewed) so you can keep a copy.\n\nOnly keep statuses you have permission to keep, and respect other people's privacy and copyright. Rahim Lux Go only reads the folder you allow and uploads nothing. It is not affiliated with WhatsApp.",
                    "Hii inaonyesha status ambazo WhatsApp tayari imezihifadhi kwenye simu yako (ulizoziona) ili uweke nakala.\n\nHifadhi tu status unazoruhusiwa kuzihifadhi, na uheshimu faragha na haki miliki za wengine. Rahim Lux Go inasoma tu folda unayoruhusu na haipakii chochote mtandaoni. Haihusiani na WhatsApp."
                )
            )
            .setCancelable(false)
            .setPositiveButton(ui.t("I understand", "Nimeelewa")) { _, _ -> store.ssIntro = true }
            .setNegativeButton(ui.t("Close", "Funga")) { _, _ -> finish() }
            .show()
    }

    // ---------------- kupakia orodha ----------------
    private fun reload() {
        if (!::grid.isInitialized) return
        selected.clear(); updateSelBar()
        StatusRepo.invalidate()
        val tabNow = tab
        val srcNow = src
        if (tabNow == "saved") {
            Thread {
                val list = StatusRepo.savedList(store)
                val ok = list.filter { StatusRepo.exists(this, it.uri) }
                list.filter { v -> ok.none { it.uri == v.uri } }.forEach { StatusRepo.removeSaved(store, it.uri) }
                val cs = ok.map { Cell("s:" + it.uri, it.uri, it.isVideo, it.mime, null, it, null) }
                runOnUiThread { if (tab == tabNow) showCells(cs, true) }
            }.start()
            return
        }
        val tree = StatusRepo.treeOf(store, srcNow)
        if (tree == null) { showCells(emptyList(), false); return }
        Thread {
            val permOk = contentResolver.persistedUriPermissions.any { it.uri == tree && it.isReadPermission }
            val folderOk = permOk && StatusRepo.resolveFolder(this, tree) != null
            val items = if (folderOk) StatusRepo.list(this, tree) else emptyList()
            val seenNow = StatusRepo.seenSet(store)
            val cs = items.filter { if (tabNow == "vid") it.isVideo else !it.isVideo }
                .map { Cell(it.uri.toString(), it.uri, it.isVideo, it.mime, it, null, srcNow + ":" + it.key) }
            runOnUiThread {
                if (tab == tabNow && src == srcNow) { seen = seenNow; showCells(cs, folderOk) }
            }
        }.start()
    }

    private fun showCells(cs: List<Cell>, accessOk: Boolean) {
        cells = cs
        summaryText.text = cs.size.toString()
        adapter.notifyDataSetChanged()
        when {
            tab == "saved" -> {
                if (cs.isEmpty()) showInfo(ui.t("Nothing saved yet. Open a status and tap Save.", "Hakuna kilichohifadhiwa bado. Fungua status kisha bonyeza Hifadhi."), null)
                else infoBox.visibility = View.GONE
            }
            !accessOk -> showInfo(
                ui.t(
                    "To show the statuses you viewed in WhatsApp, allow access to the WhatsApp Statuses folder once. On the next screen tap \"Use this folder\". Only that folder is read; nothing is uploaded.",
                    "Ili kuonyesha status ulizoziona kwenye WhatsApp, ruhusu ufikiaji wa folda ya Statuses mara moja. Kwenye skrini inayofuata bonyeza \"Use this folder\". Folda hiyo tu ndiyo inasomwa; hakuna kinachopakiwa."
                ),
                ui.t("Allow access", "Ruhusu ufikiaji") to { pickSrc = src; launchPicker() }
            )
            cs.isEmpty() -> showInfo(
                ui.t(
                    "No statuses found yet. Open WhatsApp > Status, view a status, then come back and tap ↻.",
                    "Hakuna status bado. Fungua WhatsApp > Status, tazama status, kisha rudi hapa na ubonyeze ↻."
                ),
                ui.t("Open WhatsApp", "Fungua WhatsApp") to { openWhatsApp() },
                ui.t("Change folder", "Badilisha folda") to { pickSrc = src; launchPicker() }
            )
            else -> infoBox.visibility = View.GONE
        }
    }

    private fun launchPicker() {
        try { picker.launch(StatusRepo.pickIntent(pickSrc)) } catch (e: Exception) {
            toast(ui.t("Cannot open the folder picker on this phone.", "Haiwezi kufungua kichaguzi cha folda kwenye simu hii."))
        }
    }

    private fun openWhatsApp() {
        val i = packageManager.getLaunchIntentForPackage(StatusRepo.pkgOf(src))
        if (i != null) startActivity(i) else toast(ui.t("This WhatsApp is not installed.", "WhatsApp hii haijasakinishwa."))
    }

    private fun onPicked(uri: Uri?) {
        if (uri == null) return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { /* ignore */ }
        val which = pickSrc
        Thread {
            StatusRepo.invalidate()
            val ok = StatusRepo.resolveFolder(this, uri) != null
            runOnUiThread {
                if (ok) {
                    if (which == StatusRepo.SRC_WAB) store.ssTreeWab = uri.toString() else store.ssTreeWa = uri.toString()
                    src = which; store.ssSrc = which
                    buildChips()
                    toast(ui.t("Access granted", "Ufikiaji umeruhusiwa"))
                    reload()
                } else toast(
                    ui.t(
                        "That is not the WhatsApp \".Statuses\" folder. Try again and choose it.",
                        "Hiyo si folda ya \".Statuses\" ya WhatsApp. Jaribu tena na uichague."
                    )
                )
            }
        }.start()
    }

    // ---------------- kugusa, kuchagua, kuhifadhi ----------------
    private fun onTap(c: Cell) { if (selected.isNotEmpty()) toggleSelect(c) else openViewer(c) }

    private fun toggleSelect(c: Cell) {
        if (c.item == null) return
        if (!selected.add(c.key)) selected.remove(c.key)
        updateSelBar()
        adapter.notifyDataSetChanged()
    }

    private fun saveCells(list: List<Cell>, after: ((Int) -> Unit)? = null) {
        val todo = list.filter { it.item != null && it.seenKey != null && it.seenKey !in seen }
        if (todo.isEmpty()) { toast(ui.t("Already saved", "Tayari imehifadhiwa")); after?.invoke(0); return }
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingSave = { saveCells(list, after) }
            writePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        toast(ui.t("Saving…", "Inahifadhi…"))
        Thread {
            var n = 0
            for (c in todo) {
                val v = StatusRepo.save(this, c.item!!) ?: continue
                StatusRepo.addSaved(store, v, c.seenKey!!)
                n++
            }
            val seenNow = StatusRepo.seenSet(store)
            runOnUiThread {
                seen = seenNow
                selected.clear(); updateSelBar()
                adapter.notifyDataSetChanged()
                toast(
                    if (n > 0) ui.t("Saved $n to Gallery (Rahim Lux Go Status)", "Imehifadhiwa $n kwenye Gallery (Rahim Lux Go Status)")
                    else ui.t("Could not save", "Imeshindwa kuhifadhi")
                )
                after?.invoke(n)
            }
        }.start()
    }

    private fun shareCell(c: Cell) {
        val sv = c.saved
        if (sv != null) { shareUri(sv.uri, sv.mime); return }
        val item = c.item ?: return
        val existing = StatusRepo.savedList(store).firstOrNull { it.key == c.seenKey }
        if (existing != null && StatusRepo.exists(this, existing.uri)) { shareUri(existing.uri, existing.mime); return }
        saveCells(listOf(c)) {
            val v = StatusRepo.savedList(store).firstOrNull { it.key == c.seenKey }
            if (v != null) shareUri(v.uri, item.mime)
        }
    }

    private fun shareUri(uri: Uri, mime: String) {
        if (uri.scheme == "file") {
            val path = uri.path ?: return
            MediaScannerConnection.scanFile(this, arrayOf(path), arrayOf(mime)) { _, u -> if (u != null) runOnUiThread { sendShare(u, mime) } }
        } else sendShare(uri, mime)
    }

    private fun sendShare(uri: Uri, mime: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = mime
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, ui.t("Share", "Shiriki")))
    }

    // ---------------- mtazamaji (picha / video) ----------------
    private fun openViewer(c: Cell) {
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        var player: VideoView? = null
        if (c.isVideo) {
            val vv = VideoView(this)
            val mc = MediaController(this)
            mc.setAnchorView(vv)
            vv.setMediaController(mc)
            vv.setVideoURI(c.uri)
            vv.setOnPreparedListener { mp -> mp.isLooping = true; vv.start() }
            vv.setOnErrorListener { _, _, _ -> toast(ui.t("Cannot play this video", "Video hii haichezi")); true }
            root.addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            player = vv
        } else {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            root.addView(iv, FrameLayout.LayoutParams(-1, -1))
            if (!pool.isShutdown) pool.execute {
                val b = StatusRepo.decode(this, c.uri, 1600)
                runOnUiThread { if (b != null) iv.setImageBitmap(b) else toast(ui.t("Cannot open this image", "Picha hii haifunguki")) }
            }
        }
        val bar = LinearLayout(this)
        bar.gravity = Gravity.END
        bar.setPadding(ui.dp(10), ui.dp(28), ui.dp(10), ui.dp(6))
        fun add(b: TextView) { bar.addView(b, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = ui.dp(8) }) }
        if (c.item != null) {
            val sv = barBtn(if (c.seenKey in seen) ui.t("✓ Saved", "✓ Imehifadhiwa") else ui.t("💾 Save", "💾 Hifadhi"))
            sv.setOnClickListener { saveCells(listOf(c)) { n -> if (n > 0) sv.text = ui.t("✓ Saved", "✓ Imehifadhiwa") } }
            add(sv)
        }
        val sh = barBtn("📤 " + ui.t("Share", "Shiriki"))
        sh.setOnClickListener { shareCell(c) }
        add(sh)
        val saved = c.saved
        if (saved != null) {
            val del = barBtn("🗑")
            del.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle(ui.t("Delete this saved status?", "Futa status hii iliyohifadhiwa?"))
                    .setPositiveButton(ui.t("Delete", "Futa")) { _, _ ->
                        Thread {
                            StatusRepo.deleteSaved(this, store, saved)
                            runOnUiThread { d.dismiss(); reload() }
                        }.start()
                    }
                    .setNegativeButton(ui.t("Cancel", "Ghairi"), null)
                    .show()
            }
            add(del)
        }
        val x = barBtn("✕")
        x.setOnClickListener { d.dismiss() }
        add(x)
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        d.setContentView(root)
        d.setOnDismissListener { player?.stopPlayback() }
        d.show()
    }

    // ---------------- Auto-save ----------------
    private fun autoDialog() {
        val items = arrayOf(ui.t("Auto-save new statuses (about every 30 min)", "Hifadhi status mpya kiotomatiki (takriban kila dakika 30)"))
        val checked = booleanArrayOf(store.ssAuto)
        AlertDialog.Builder(this)
            .setTitle("⚙ Status Saver")
            .setMultiChoiceItems(items, checked) { _, _, v -> checked[0] = v }
            .setPositiveButton("OK") { _, _ -> setAuto(checked[0]) }
            .setNegativeButton(ui.t("Cancel", "Ghairi"), null)
            .show()
    }

    private fun setAuto(on: Boolean) {
        if (on && StatusRepo.treeOf(store, StatusRepo.SRC_WA) == null && StatusRepo.treeOf(store, StatusRepo.SRC_WAB) == null) {
            toast(ui.t("Allow access to the Statuses folder first.", "Ruhusu ufikiaji wa folda ya Statuses kwanza."))
            return
        }
        if (on && Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingSave = { setAuto(true) }
            writePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        store.ssAuto = on
        StatusAutoSaveWorker.schedule(this, on)
        if (on) StatusAutoSaveWorker.runNow(this)
        toast(if (on) ui.t("Auto-save is on", "Auto-save imewashwa") else ui.t("Auto-save is off", "Auto-save imezimwa"))
    }

    // ---------------- adapter ya gridi ----------------
    private class Holder(val iv: ImageView, val play: TextView, val badge: TextView, val check: TextView, val dim: View)

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = cells.size
        override fun getItem(i: Int): Any = cells[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
            val c = cells[i]
            val ctx = this@StatusSaverActivity
            val v: FrameLayout
            val h: Holder
            if (convert == null) {
                v = FrameLayout(ctx)
                v.layoutParams = AbsListView.LayoutParams(cellSize, cellSize)
                val tileBg = GradientDrawable()
                tileBg.cornerRadius = ui.dp(12).toFloat()
                tileBg.setColor(Color.parseColor("#171730"))
                tileBg.setStroke(ui.dp(1), Color.parseColor("#2AFFFFFF"))
                v.background = tileBg
                v.clipToOutline = true
                val iv = ImageView(ctx)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                iv.setBackgroundColor(Color.parseColor("#171730"))
                v.addView(iv, FrameLayout.LayoutParams(-1, -1))
                val dim = View(ctx)
                dim.setBackgroundColor(Color.parseColor("#667C3AED"))
                v.addView(dim, FrameLayout.LayoutParams(-1, -1))
                val play = TextView(ctx)
                play.text = "▶"; play.textSize = 22f; play.setTextColor(Color.WHITE)
                play.setShadowLayer(6f, 0f, 0f, Color.BLACK)
                v.addView(play, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
                val badge = TextView(ctx)
                badge.text = "✓"; badge.textSize = 11f; badge.setTextColor(Color.BLACK); badge.setTypeface(null, Typeface.BOLD)
                badge.setPadding(ui.dp(6), ui.dp(2), ui.dp(6), ui.dp(2))
                val bb = GradientDrawable(); bb.cornerRadius = ui.dp(8).toFloat(); bb.setColor(ui.gold)
                badge.background = bb
                val blp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
                blp.setMargins(0, ui.dp(4), ui.dp(4), 0)
                v.addView(badge, blp)
                val check = TextView(ctx)
                check.text = "✔"; check.textSize = 26f; check.setTextColor(Color.WHITE)
                check.setShadowLayer(6f, 0f, 0f, Color.BLACK)
                v.addView(check, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
                h = Holder(iv, play, badge, check, dim)
                v.tag = h
            } else {
                v = convert as FrameLayout
                h = v.tag as Holder
            }
            h.play.visibility = if (c.isVideo) View.VISIBLE else View.GONE
            h.badge.visibility = if (c.item != null && c.seenKey in seen) View.VISIBLE else View.GONE
            val sel = c.key in selected
            h.dim.visibility = if (sel) View.VISIBLE else View.GONE
            h.check.visibility = if (sel) View.VISIBLE else View.GONE
            h.iv.tag = c.key
            val bm = cache.get(c.key)
            if (bm != null) h.iv.setImageBitmap(bm)
            else {
                h.iv.setImageDrawable(null)
                if (!pool.isShutdown) pool.execute {
                    val b = StatusRepo.thumb(ctx, c.uri, c.isVideo, 320)
                    if (b != null) {
                        cache.put(c.key, b)
                        runOnUiThread { if (h.iv.tag == c.key) h.iv.setImageBitmap(b) }
                    }
                }
            }
            return v
        }
    }
}
