package com.rahimlux.go

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * Msaidizi wa afya (MedGemma): taarifa za afya kwa ujumla. SI daktari na haitambui magonjwa.
 * Usalama: ridhaa ya mara ya kwanza, onyo la kudumu, safu ya ndani ya dharura/kujidhuru (MedSafety), na mazungumzo hayahifadhiwi popote.
 */
class HealthAiActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var attachRow: LinearLayout
    private lateinit var sendBtn: TextView
    private val history = ArrayList<MedAi.Msg>()
    private var pendingImage: String? = null
    private var busy = false
    private val pool = Executors.newSingleThreadExecutor()
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) attach(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#07070F"))
        root.addView(ui.header(ui.t("Health assistant", "Msaidizi wa afya"), listOf("🗑" to { clearChat() })))

        val note = TextView(this)
        note.text = ui.t(
            "Information only — not a doctor. In an emergency call your local emergency number.",
            "Taarifa tu — si daktari. Wakati wa dharura piga simu ya dharura ya eneo lako."
        )
        note.textSize = 11.5f
        note.setTextColor(Color.parseColor("#FFD580"))
        note.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8))
        note.background = round("#26FFB300", "#44FFB300", 1, 12)
        root.addView(note, LinearLayout.LayoutParams(-1, -2).also { it.setMargins(ui.dp(14), 0, ui.dp(14), ui.dp(6)) })

        scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(12))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        attachRow = LinearLayout(this)
        attachRow.gravity = Gravity.CENTER_VERTICAL
        attachRow.setPadding(ui.dp(14), ui.dp(4), ui.dp(14), ui.dp(4))
        attachRow.visibility = View.GONE
        root.addView(attachRow)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(ui.dp(10), ui.dp(8), ui.dp(10), ui.dp(12))
        bar.setBackgroundColor(Color.parseColor("#0E0E22"))
        val clip = circle("📎", false)
        clip.setOnClickListener {
            try { picker.launch("image/*") } catch (e: Exception) { toast(ui.t("No gallery app found", "Hakuna app ya picha")) }
        }
        bar.addView(clip, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)))
        input = EditText(this)
        input.hint = ui.t("Ask a health question…", "Uliza swali la afya…")
        input.setHintTextColor(Color.parseColor("#8F8DB5"))
        input.setTextColor(Color.WHITE)
        input.textSize = 15f
        input.maxLines = 4
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.filters = arrayOf(InputFilter.LengthFilter(1000))
        input.setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(10))
        input.background = round("#14142B", "#33FFFFFF", 1, 24)
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(ui.dp(8), 0, ui.dp(8), 0) })
        sendBtn = circle("➤", true)
        sendBtn.setOnClickListener { send() }
        bar.addView(sendBtn, LinearLayout.LayoutParams(ui.dp(46), ui.dp(46)))
        root.addView(bar)
        setContentView(root)

        addWelcome()
        if (!store.medConsent) consentDialog()
    }

    override fun onDestroy() {
        super.onDestroy()
        pool.shutdownNow()
    }

    // ---------------- vifaa vidogo ----------------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun round(fill: String, stroke: String, strokeDp: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(fill))
        g.setStroke(ui.dp(strokeDp), Color.parseColor(stroke))
        g.cornerRadius = ui.dp(radiusDp).toFloat()
        return g
    }

    private fun circle(label: String, primary: Boolean): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 18f
        t.gravity = Gravity.CENTER
        t.setTextColor(if (primary) Color.parseColor("#1A1200") else Color.WHITE)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        if (primary) g.setColor(Color.parseColor("#FFB300")) else { g.setColor(Color.parseColor("#1B1B38")); g.setStroke(ui.dp(1), Color.parseColor("#33FFFFFF")) }
        t.background = g
        return t
    }

    private fun bubble(text: String, mine: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 15f
        tv.setLineSpacing(0f, 1.15f)
        tv.setTextColor(if (mine) Color.parseColor("#1A1200") else Color.WHITE)
        tv.setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
        tv.background = if (mine) round("#FFB300", "#FFB300", 0, 18) else round("#1B1B38", "#26FFFFFF", 1, 18)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.86).toInt()
        if (!mine) tv.setTextIsSelectable(true)
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.topMargin = ui.dp(8)
        list.addView(tv, lp)
        toBottom()
        return tv
    }

    private fun toBottom() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun dial() {
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))) } catch (e: Exception) { toast("112") }
    }

    private fun alertCard(text: String, fill: String, stroke: String) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12))
        box.background = round(fill, stroke, 1, 16)
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(Color.WHITE)
        tv.setLineSpacing(0f, 1.15f)
        box.addView(tv)
        val b = TextView(this)
        b.text = ui.t("📞  Call 112 (or your local emergency number)", "📞  Piga 112 (au namba ya dharura ya eneo lako)")
        b.textSize = 14f
        b.setTypeface(null, Typeface.BOLD)
        b.setTextColor(Color.parseColor("#1A1200"))
        b.gravity = Gravity.CENTER
        b.setPadding(ui.dp(12), ui.dp(11), ui.dp(12), ui.dp(11))
        b.background = round("#FFB300", "#FFB300", 0, 14)
        b.setOnClickListener { dial() }
        box.addView(b, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(10) })
        list.addView(box, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(10) })
        toBottom()
    }

    // ---------------- mwanzo ----------------
    private fun addWelcome() {
        bubble(
            ui.t(
                "Hello! I can explain health terms, medicine labels, and give general prevention or first-aid information. I'm not a doctor and I can't diagnose. What would you like to know?",
                "Habari! Naweza kueleza maneno ya kitabibu, maelezo ya dawa, na kutoa taarifa za jumla za kinga au huduma ya kwanza. Mimi si daktari na siwezi kutambua ugonjwa. Ungependa kujua nini?"
            ), false
        )
        val starters = listOf(
            ui.t("Explain a medical term", "Nieleze neno la kitabibu") to ui.t("Explain this medical term in simple words: ", "Nieleze kwa maneno rahisi neno hili la kitabibu: "),
            ui.t("Understand a medicine label", "Elewa maelezo ya dawa") to ui.t("Help me understand this medicine's label and warnings: ", "Nisaidie kuelewa maelezo na tahadhari za dawa hii: "),
            ui.t("Prepare questions for my doctor", "Andaa maswali kwa daktari wangu") to ui.t("Help me prepare questions for my doctor about: ", "Nisaidie kuandaa maswali kwa daktari wangu kuhusu: "),
            ui.t("Prevention tips", "Vidokezo vya kujikinga") to ui.t("Give me practical prevention tips for: ", "Nipe vidokezo vya vitendo vya kujikinga na: ")
        )
        for ((label, prefill) in starters) {
            val p = TextView(this)
            p.text = label
            p.textSize = 14f
            p.setTextColor(Color.WHITE)
            p.setPadding(ui.dp(14), ui.dp(11), ui.dp(14), ui.dp(11))
            p.background = round("#14142B", "#33FFB300", 1, 16)
            p.setOnClickListener { input.setText(prefill); input.setSelection(input.text.length); input.requestFocus() }
            list.addView(p, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ui.dp(8) })
        }
    }

    private fun consentDialog() {
        AlertDialog.Builder(this)
            .setTitle(ui.t("Before you start", "Kabla ya kuanza"))
            .setMessage(
                ui.t(
                    "• This assistant gives general health information only. It is not a doctor and cannot diagnose or prescribe.\n" +
                        "• It can make mistakes. Always check with a doctor, nurse or pharmacist.\n" +
                        "• In an emergency do not wait for the app: call your local emergency number or go to the nearest hospital.\n" +
                        "• Your questions (and any photo you attach) are sent over the internet to the app's server and an AI medical model (MedGemma). The app does not store them. Do not include names or ID numbers.\n" +
                        "• Answers in Kiswahili may be less accurate than in English.",
                    "• Msaidizi huyu anatoa taarifa za afya kwa ujumla tu. Si daktari na hawezi kutambua ugonjwa wala kuandika dawa.\n" +
                        "• Anaweza kukosea. Daima thibitisha na daktari, muuguzi au mfamasia.\n" +
                        "• Wakati wa dharura usisubiri app: piga simu ya dharura ya eneo lako au nenda hospitali iliyo karibu.\n" +
                        "• Maswali yako (na picha ukiambatanisha) yanatumwa kupitia intaneti kwenda kwenye seva ya app na modeli ya AI ya kitabibu (MedGemma). App haiyahifadhi. Usiweke majina wala namba za vitambulisho.\n" +
                        "• Majibu kwa Kiswahili yanaweza kuwa na usahihi mdogo kuliko Kiingereza."
                )
            )
            .setCancelable(false)
            .setPositiveButton(ui.t("I understand", "Nimeelewa")) { _, _ -> store.medConsent = true }
            .setNegativeButton(ui.t("Close", "Funga")) { _, _ -> finish() }
            .show()
    }

    private fun clearChat() {
        if (busy) return
        history.clear()
        clearAttachment()
        list.removeAllViews()
        addWelcome()
    }

    // ---------------- picha ----------------
    private fun attach(uri: Uri) {
        toast(ui.t("Preparing photo…", "Inaandaa picha…"))
        Thread {
            val bmp = StatusRepo.decode(this, uri, 1024)
            var data: String? = null
            if (bmp != null) {
                var q = 78
                val bos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, q, bos)
                while (bos.size() > 900_000 && q > 40) { q -= 12; bos.reset(); bmp.compress(Bitmap.CompressFormat.JPEG, q, bos) }
                // Kuhifadhi tena kama JPEG kunaondoa EXIF (pamoja na mahali pa picha)
                if (bos.size() <= 1_000_000) data = "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            }
            runOnUiThread {
                if (data == null || bmp == null) toast(ui.t("Could not use this photo", "Picha hii haikuweza kutumika"))
                else { pendingImage = data; showAttachment(bmp) }
            }
        }.start()
    }

    private fun showAttachment(b: Bitmap) {
        attachRow.removeAllViews()
        val iv = ImageView(this)
        iv.setImageBitmap(Bitmap.createScaledBitmap(b, ui.dp(56), (ui.dp(56) * b.height.toFloat() / b.width).toInt().coerceAtLeast(1), true))
        attachRow.addView(iv, LinearLayout.LayoutParams(ui.dp(56), ui.dp(56)))
        val tv = TextView(this)
        tv.text = ui.t("Photo will be sent with your next message. Location data is removed. A photo cannot confirm a diagnosis.",
            "Picha itatumwa na ujumbe wako unaofuata. Taarifa ya mahali imeondolewa. Picha haiwezi kuthibitisha utambuzi wa ugonjwa.")
        tv.textSize = 11f
        tv.setTextColor(Color.parseColor("#C9C7E6"))
        attachRow.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(ui.dp(10), 0, ui.dp(6), 0) })
        val x = TextView(this)
        x.text = "✕"
        x.textSize = 18f
        x.setTextColor(Color.WHITE)
        x.setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6))
        x.setOnClickListener { clearAttachment() }
        attachRow.addView(x)
        attachRow.visibility = View.VISIBLE
    }

    private fun clearAttachment() {
        pendingImage = null
        attachRow.removeAllViews()
        attachRow.visibility = View.GONE
    }

    // ---------------- kutuma ----------------
    private fun errorText(e: String): String = when (e) {
        "not_configured" -> ui.t("The health assistant is not set up on the server yet.", "Msaidizi wa afya bado haujawekwa kwenye seva.")
        "rate_limited" -> ui.t("Daily question limit reached. Please try again tomorrow.", "Kikomo cha maswali cha siku kimefikiwa. Jaribu tena kesho.")
        "busy" -> ui.t("The assistant is very busy today. Please try again later.", "Msaidizi ana shughuli nyingi leo. Jaribu tena baadaye.")
        "vision_disabled", "bad_image" -> ui.t("Photos are not available right now. Send your question without a photo.", "Picha hazipatikani kwa sasa. Tuma swali bila picha.")
        "too_long" -> ui.t("The conversation is too long. Tap the bin icon to start a new one.", "Mazungumzo ni marefu mno. Bonyeza kikapu cha takataka kuanza upya.")
        "unauthorized" -> ui.t("This app is not allowed to use the server.", "App hii hairuhusiwi kutumia seva.")
        "network" -> ui.t("No connection. Check your internet and try again.", "Hakuna mtandao. Angalia intaneti kisha ujaribu tena.")
        else -> ui.t("The assistant is temporarily unavailable. Please try again.", "Msaidizi hapatikani kwa muda. Jaribu tena.")
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty() || busy) return
        val img = pendingImage
        bubble(if (img != null) "📷 " + text else text, true)
        input.setText("")
        when (MedSafety.check(text)) {
            MedSafety.SELF_HARM -> {
                // Hatutumi swali hili kwa modeli: tunaonyesha ujumbe wa kusaidia mara moja
                clearAttachment()
                alertCard(
                    ui.t(
                        "I'm really sorry you are feeling this way. You are not alone. Please talk to someone you trust right now, or contact your local emergency number or a crisis line. If you are in immediate danger, call emergency services.",
                        "Pole sana kwa unayopitia. Hauko peke yako. Tafadhali ongea sasa hivi na mtu unayemwamini, au wasiliana na namba ya dharura ya eneo lako au huduma ya msaada wa dharura. Ukiwa kwenye hatari ya haraka, piga simu ya dharura."
                    ),
                    "#331B3F", "#88B388FF"
                )
                return
            }
            MedSafety.EMERGENCY -> alertCard(
                ui.t(
                    "If this is happening now, it may be an emergency. Do not wait for an app: call your local emergency number or go to the nearest hospital now.",
                    "Kama hili linatokea sasa, linaweza kuwa dharura. Usisubiri app: piga simu ya dharura ya eneo lako au nenda hospitali iliyo karibu sasa."
                ),
                "#3A1717", "#88FF5252"
            )
            else -> {}
        }
        history.add(MedAi.Msg("user", text))
        clearAttachment()
        busy = true
        sendBtn.alpha = 0.4f
        val typing = bubble("…", false)
        val snapshot = ArrayList(history)
        pool.execute {
            val r = MedAi.ask(store, snapshot, store.lang, img)
            runOnUiThread {
                busy = false
                sendBtn.alpha = 1f
                list.removeView(typing)
                if (r.ok) {
                    history.add(MedAi.Msg("assistant", r.reply))
                    bubble(MedSafety.plain(r.reply), false)
                } else {
                    history.removeAt(history.size - 1)
                    input.setText(text)
                    input.setSelection(input.text.length)
                    bubble(errorText(r.error), false)
                }
            }
        }
    }
}
