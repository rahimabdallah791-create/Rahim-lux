package com.rahimlux.go

import android.webkit.WebView
import java.net.URI

/** Tab moja. wv = null maana tab imelala: hakuna WebView, ukurasa unapakiwa ukifunguliwa (hii inaokoa kumbukumbu). */
class Tab(var wv: WebView?, var url: String, var title: String, val incognito: Boolean) {
    /** URL ya kupakia tab ikiamka */
    var pending: String? = null
    var lastUsed: Long = System.currentTimeMillis()

    fun currentUrl(): String {
        val live = wv?.url
        if (!live.isNullOrEmpty() && live != "about:blank") return live
        return pending ?: url
    }
}

/** Makundi ya tab kwenye Tab Manager. */
object TabGroups {
    const val NOW = 0
    const val RECENT = 1
    const val EARLIER = 2
    const val PRIVATE = 3
    private const val RECENT_MS = 60 * 60_000L

    fun of(now: Long, lastUsed: Long, incognito: Boolean, isCurrent: Boolean): Int = when {
        incognito -> PRIVATE
        isCurrent -> NOW
        now - lastUsed < RECENT_MS -> RECENT
        else -> EARLIER
    }
}

/** Sheria za kulaza tab za nyuma (kazi safi, inayoweza kupimwa). */
object TabPolicy {
    class Cand(val index: Int, val lastUsed: Long, val live: Boolean, val busy: Boolean)

    /**
     * Inarudisha namba za tab za nyuma za kulaza:
     *  - zilizokaa bila kutumika kwa idleMs au zaidi, na
     *  - zinazozidi "cap" (tab za nyuma zilizo hai); zilizotumika zamani zaidi huanza, kwa sharti zimekaa angalau minIdleMs.
     * Tab ya sasa na tab zinazopakia hazilazwi kamwe.
     */
    fun toSleep(c: List<Cand>, cur: Int, now: Long, cap: Int, idleMs: Long, minIdleMs: Long): List<Int> {
        val bg = c.filter { it.index != cur && it.live && !it.busy }
        val out = LinkedHashSet<Int>()
        for (x in bg) if (now - x.lastUsed >= idleMs) out.add(x.index)
        val rest = bg.filter { it.index !in out }.sortedByDescending { it.lastUsed }
        for (x in rest.drop(cap)) if (now - x.lastUsed >= minIdleMs) out.add(x.index)
        return out.toList()
    }

    /** Ufunguo wa kutambua tab zinazorudiwa (bila www, fragment na "/" ya mwisho). null = usiihesabu. */
    fun dupKey(url: String, homeHost: String): String? {
        if (!url.startsWith("http", true)) return null
        return try {
            val u = URI(url)
            val h = (u.host ?: return null).lowercase()
            if (h == homeHost) return null
            val path = (u.rawPath ?: "").trimEnd('/')
            val q = u.rawQuery?.let { "?$it" } ?: ""
            h.removePrefix("www.") + path + q
        } catch (e: Exception) {
            null
        }
    }
}
