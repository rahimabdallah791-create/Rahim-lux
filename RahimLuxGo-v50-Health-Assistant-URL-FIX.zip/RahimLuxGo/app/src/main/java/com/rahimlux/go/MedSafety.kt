package com.rahimlux.go

/**
 * Safu ya usalama ya ndani ya simu kwa Msaidizi wa afya. Haitegemei modeli: inagundua dharura na mawazo ya kujidhuru kabla ya swali kutumwa,
 * ili mtumiaji aone ushauri sahihi mara moja. (Maneno yanalinganishwa kwa herufi ndogo; Kiingereza na Kiswahili.)
 */
object MedSafety {
    const val NONE = 0
    const val EMERGENCY = 1
    const val SELF_HARM = 2

    private val selfHarm = listOf(
        "kill myself", "suicid", "end my life", "want to die", "take my own life", "hurt myself", "harm myself",
        "najiua", "kujiua", "nataka kufa", "kujiumiza", "nijiue", "sitaki kuishi"
    )

    private val emergency = listOf(
        "chest pain", "pain in my chest", "can't breathe", "cannot breathe", "hard to breathe", "difficulty breathing",
        "trouble breathing", "shortness of breath", "not breathing", "unconscious", "passed out", "seizure", "convulsion",
        "stroke", "face drooping", "slurred speech", "severe bleeding", "bleeding heavily", "won't stop bleeding",
        "bleeding a lot", "overdose", "poison", "anaphyla", "throat is closing",
        "maumivu ya kifua", "siwezi kupumua", "nashindwa kupumua", "kushindwa kupumua", "amezimia", "nimezimia",
        "kifafa", "degedege", "kiharusi", "kutokwa na damu nyingi", "damu nyingi", "hapumui", "sumu"
    )

    private fun norm(s: String) = s.lowercase().replace('’', '\'').replace(Regex("\\s+"), " ")

    fun check(raw: String): Int {
        val t = norm(raw)
        if (selfHarm.any { t.contains(it) }) return SELF_HARM
        if (emergency.any { t.contains(it) }) return EMERGENCY
        if ((t.contains("pregnan") && t.contains("bleed")) || (t.contains("mimba") && t.contains("damu"))) return EMERGENCY
        val newborn = t.contains("newborn") || t.contains("mtoto mchanga")
        if (newborn && (t.contains("fever") || t.contains("homa") || t.contains("not feeding") || t.contains("hanyonyi") || t.contains("not breathing"))) return EMERGENCY
        return NONE
    }

    /** Majibu ya modeli yanakuwa maandishi wazi: inaondoa alama za markdown (**, #) na kubadilisha "* " kuwa "• ". */
    fun plain(text: String): String {
        val lines = text.replace("\r", "").split("\n").map { l ->
            var x = l.trimEnd()
            x = x.replace(Regex("^\\s{0,3}#{1,6}\\s*"), "")
            x = x.replace(Regex("^(\\s*)[*-]\\s+"), "\$1• ")
            x.replace("**", "").replace("__", "")
        }
        return lines.joinToString("\n").replace(Regex("\n{3,}"), "\n\n").trim()
    }
}
