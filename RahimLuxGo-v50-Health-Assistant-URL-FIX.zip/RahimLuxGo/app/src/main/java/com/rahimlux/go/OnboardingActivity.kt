package com.rahimlux.go

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/**
 * Skrini ya kuanzia (mara ya kwanza): lugha, muonekano, timu pendwa, faragha na arifa, kisha kivinjari chaguomsingi.
 * Chaguo zinahifadhiwa kwenye Store; MainActivity inazitumia kwenye Home (theme na timu) baada ya kurudi.
 */
class OnboardingActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var dots: LinearLayout
    private lateinit var next: TextView
    private lateinit var back: TextView
    private val perm = PermHelper(this)

    private var step = 0
    private val last = 4
    private var pickedTheme = "aurora"
    private var team = ""
    private var teamName = ""
    private var crash = true

    private class Th(val id: String, val name: String, val c1: String, val c2: String)

    private val themes = listOf(
        Th("aurora", "Lux Aurora", "#8B5CF6", "#22D3EE"), Th("gold", "Gold Lux", "#FFB300", "#FF8F00"),
        Th("cyan", "Neon Cyan", "#22D3EE", "#0EA5E9"), Th("emerald", "Emerald Green", "#34D399", "#10B981"),
        Th("light", "Light Mode", "#F3EEFF", "#8B5CF6")
    )

    // Majina ya id yanafanana na orodha ya TEAMS kwenye fav-team.js
    private val teams = listOf(
        "yanga" to "Yanga SC", "simba" to "Simba SC", "azam" to "Azam FC", "arsenal" to "Arsenal",
        "mancity" to "Man City", "manutd" to "Man United", "liverpool" to "Liverpool", "chelsea" to "Chelsea",
        "real" to "Real Madrid", "barca" to "Barcelona", "bayern" to "Bayern Munich", "psg" to "PSG"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)
        crash = store.crashReports

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = resources.getDrawable(R.drawable.bg_onboard, getTheme())
        scroll = ScrollView(this)
        scroll.isFillViewport = true
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.dp(24), ui.dp(48), ui.dp(24), ui.dp(16))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        dots = LinearLayout(this)
        dots.gravity = Gravity.CENTER
        dots.setPadding(0, ui.dp(8), 0, ui.dp(10))
        root.addView(dots)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(ui.dp(20), 0, ui.dp(20), ui.dp(22))
        back = TextView(this)
        back.textSize = 15f
        back.setTextColor(Color.parseColor("#B7B5D6"))
        back.setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(14))
        back.setOnClickListener { if (step > 0) { step--; render() } }
        bar.addView(back)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        next = TextView(this)
        next.textSize = 16f
        next.setTypeface(null, Typeface.BOLD)
        next.setTextColor(Color.parseColor("#1A1200"))
        next.gravity = Gravity.CENTER
        next.setPadding(ui.dp(34), ui.dp(14), ui.dp(34), ui.dp(14))
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor("#FFE082"), Color.parseColor("#FFB300"), Color.parseColor("#FF8F00")))
        g.cornerRadius = ui.dp(28).toFloat()
        next.background = g
        next.setOnClickListener { if (step < last) { step++; render() } else finishFlow(true) }
        bar.addView(next)
        root.addView(bar)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (step > 0) { step--; render() } else finishFlow(false)
            }
        })
        render()
    }

    // ---------------- vifaa vidogo ----------------
    private fun txt(text: String, size: Float, color: String, bold: Boolean = false, center: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(Color.parseColor(color))
        if (bold) t.setTypeface(null, Typeface.BOLD)
        if (center) t.gravity = Gravity.CENTER
        t.setLineSpacing(0f, 1.15f)
        return t
    }

    private fun roundBg(fill: String, stroke: String, strokeDp: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(fill))
        g.setStroke(ui.dp(strokeDp), Color.parseColor(stroke))
        g.cornerRadius = ui.dp(radiusDp).toFloat()
        return g
    }

    private fun pill(label: String, on: Boolean, click: () -> Unit): TextView {
        val p = txt(label, 14f, if (on) "#1A1200" else "#FFFFFF", on, true)
        p.setPadding(ui.dp(10), ui.dp(13), ui.dp(10), ui.dp(13))
        p.background = if (on) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor("#FFE082"), Color.parseColor("#FFB300")))
            g.cornerRadius = ui.dp(16).toFloat(); g
        } else roundBg("#16162E", "#33FFFFFF", 1, 16)
        p.setOnClickListener { click() }
        return p
    }

    private fun twoCols(a: View, b: View?): LinearLayout {
        val row = LinearLayout(this)
        val m = ui.dp(5)
        val la = LinearLayout.LayoutParams(0, -2, 1f); la.setMargins(m, m, m, m)
        row.addView(a, la)
        val lb = LinearLayout.LayoutParams(0, -2, 1f); lb.setMargins(m, m, m, m)
        row.addView(b ?: View(this), lb)
        return row
    }

    private fun render() {
        content.removeAllViews()
        when (step) {
            0 -> stepWelcome()
            1 -> stepLook()
            2 -> stepTeam()
            3 -> stepPrivacy()
            else -> stepFinish()
        }
        dots.removeAllViews()
        for (i in 0..last) {
            val d = View(this)
            val on = i == step
            d.background = roundBg(if (on) "#FFB300" else "#44FFFFFF", if (on) "#FFB300" else "#44FFFFFF", 0, 6)
            val lp = LinearLayout.LayoutParams(ui.dp(if (on) 22 else 8), ui.dp(8))
            lp.setMargins(ui.dp(4), 0, ui.dp(4), 0)
            dots.addView(d, lp)
        }
        back.text = if (step > 0) ui.t("Back", "Rudi") else ""
        next.text = if (step < last) ui.t("Next", "Endelea") else ui.t("Start", "Anza")
        scroll.scrollTo(0, 0)
    }

    // ---------------- hatua ----------------
    private fun stepWelcome() {
        val logo = ImageView(this)
        try { logo.setImageBitmap(BitmapFactory.decodeStream(resources.openRawResource(R.raw.logo))) } catch (e: Exception) { /* bila nembo */ }
        content.addView(logo, LinearLayout.LayoutParams(ui.dp(112), ui.dp(112)).also { it.gravity = Gravity.CENTER_HORIZONTAL; it.topMargin = ui.dp(16) })
        content.addView(txt(ui.t("Welcome to Rahim Lux Go", "Karibu Rahim Lux Go"), 26f, "#FFFFFF", true, true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(24) })
        content.addView(txt(ui.t("A fast, private and smart browser made for you.", "Kivinjari cha haraka, cha faragha na chenye akili, kilichotengenezwa kwa ajili yako."), 15f, "#C9C7E6", false, true),
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(10) })
        content.addView(txt(ui.t("Choose your language", "Chagua lugha yako"), 12f, "#FFB300", true, true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(36) })
        val en = pill("English", store.lang != "sw") { store.lang = "en"; render() }
        val sw = pill("Kiswahili", store.lang == "sw") { store.lang = "sw"; render() }
        content.addView(twoCols(en, sw))
    }

    private fun stepLook() {
        content.addView(txt(ui.t("Pick your look", "Chagua muonekano wako"), 24f, "#FFFFFF", true), LinearLayout.LayoutParams(-1, -2))
        content.addView(txt(ui.t("You can change it any time at the bottom of the Home page.", "Unaweza kuubadilisha wakati wowote chini ya ukurasa wa Home."), 14f, "#C9C7E6"),
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(8); it.bottomMargin = ui.dp(14) })
        val cards = themes.map { th ->
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.setPadding(ui.dp(8), ui.dp(16), ui.dp(8), ui.dp(14))
            box.background = roundBg("#14142B", if (th.id == pickedTheme) "#FFB300" else "#26FFFFFF", if (th.id == pickedTheme) 2 else 1, 20)
            val sw = View(this)
            val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor(th.c1), Color.parseColor(th.c2)))
            g.shape = GradientDrawable.OVAL
            sw.background = g
            box.addView(sw, LinearLayout.LayoutParams(ui.dp(46), ui.dp(46)))
            box.addView(txt(th.name, 13f, "#FFFFFF", true, true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(10) })
            box.setOnClickListener { pickedTheme = th.id; render() }
            box as View
        }
        var i = 0
        while (i < cards.size) { content.addView(twoCols(cards[i], cards.getOrNull(i + 1))); i += 2 }
    }

    private fun stepTeam() {
        content.addView(txt(ui.t("Your favourite team", "Timu yako pendwa"), 24f, "#FFFFFF", true), LinearLayout.LayoutParams(-1, -2))
        content.addView(
            txt(ui.t("We pin it first in Live Scores and League tables, and send you goal and match alerts. You can skip this.",
                "Tutaiweka juu kwenye Live Scores na Msimamo, na kukutumia arifa za magoli na mechi. Unaweza kuruka hatua hii."), 14f, "#C9C7E6"),
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(8); it.bottomMargin = ui.dp(12) }
        )
        val pills = teams.map { (id, name) ->
            pill(name, id == team) { if (team == id) { team = ""; teamName = "" } else { team = id; teamName = name }; render() } as View
        }
        var i = 0
        while (i < pills.size) { content.addView(twoCols(pills[i], pills.getOrNull(i + 1))); i += 2 }
        content.addView(txt(ui.t("Other teams can be added later from the Home page.", "Timu nyingine unaweza kuziongeza baadaye kutoka kwenye Home."), 12f, "#8F8DB5", false, true),
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(10) })
    }

    private fun stepPrivacy() {
        content.addView(txt(ui.t("Your privacy, your control", "Faragha yako, uamuzi wako"), 24f, "#FFFFFF", true), LinearLayout.LayoutParams(-1, -2))
        val bullets = listOf(
            "🛡  " + ui.t("Ads and trackers are blocked by default.", "Matangazo na trackers vimezuiwa kwa chaguo-msingi."),
            "📷  " + ui.t("Camera, microphone and location are asked only when a website needs them.", "Kamera, kipaza sauti na mahali vinaombwa tu tovuti inapovihitaji."),
            "🔒  " + ui.t("History and bookmarks stay on your phone; you can lock them with your fingerprint.", "History na bookmarks vinabaki kwenye simu yako; unaweza kuvifunga kwa alama ya kidole.")
        )
        for (b in bullets) content.addView(txt(b, 14f, "#E4E2F6"), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(14) })
        val card = ui.card()
        ui.switchRow(card, ui.t("Send anonymous crash reports", "Tuma ripoti za kasoro (bila jina)"),
            ui.t("Helps us fix bugs. No pages, searches or history are sent.", "Inatusaidia kurekebisha kasoro. Hakuna kurasa, utafutaji wala history vinavyotumwa."), crash) { crash = it }
        ui.addCard(content, card)
        if (Build.VERSION.SDK_INT >= 33 && !perm.granted()) {
            content.addView(
                pill(ui.t("🔔  Allow notifications", "🔔  Ruhusu arifa"), false) {
                    perm.ensure { ok -> if (ok) Toast.makeText(this, ui.t("Notifications on", "Arifa zimewashwa"), Toast.LENGTH_SHORT).show(); render() }
                },
                LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(16) }
            )
        }
    }

    private fun stepFinish() {
        content.addView(txt("🎉", 48f, "#FFFFFF", false, true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(24) })
        content.addView(txt(ui.t("You're all set!", "Uko tayari!"), 26f, "#FFFFFF", true, true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(12) })
        val th = themes.first { it.id == pickedTheme }.name
        val summary = ui.t("Look: $th", "Muonekano: $th") + (if (team.isNotEmpty()) "\n" + ui.t("Team: $teamName", "Timu: $teamName") else "")
        content.addView(txt(summary, 14f, "#C9C7E6", false, true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(10) })
        content.addView(
            pill(ui.t("Make Rahim Lux Go my default browser", "Weka Rahim Lux Go kuwa kivinjari changu chaguomsingi"), false) {
                try { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
                catch (e: Exception) { Toast.makeText(this, ui.t("Open Settings > Apps > Default apps", "Fungua Settings > Apps > Default apps"), Toast.LENGTH_LONG).show() }
            },
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(28) }
        )
        content.addView(txt(ui.t("Optional: links from other apps will open here.", "Si lazima: viungo kutoka kwenye app nyingine vitafunguka hapa."), 12f, "#8F8DB5", false, true),
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ui.dp(10) })
    }

    /** applyChoices = false: mtumiaji ameruka (Back kwenye hatua ya kwanza); hatubadilishi chochote. */
    private fun finishFlow(applyChoices: Boolean) {
        if (applyChoices) {
            store.crashReports = crash
            Crash.setEnabled(crash)
            store.obTheme = pickedTheme
            store.obTeamId = team
            store.obTeamName = teamName
            store.obPending = true
            if (team.isNotEmpty()) {
                store.favTeamId = team
                store.favTeamName = teamName
                store.favAlerts = true
                Push.syncTopics(applicationContext)
            }
        }
        store.obDone = true
        setResult(RESULT_OK)
        finish()
    }
}
