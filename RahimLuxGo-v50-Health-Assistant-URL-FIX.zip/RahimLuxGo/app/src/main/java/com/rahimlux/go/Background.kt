package com.rahimlux.go

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** Picha ya nyuma ya Home (kama Chrome). Picha inabaki kwenye simu yako (hifadhi ya ndani ya app), haipakiwi popote. */
object Background {
    private const val MAX_SIDE = 1280

    fun file(ctx: Context) = File(ctx.filesDir, "home_bg.jpg")
    fun exists(ctx: Context) = file(ctx).exists()
    fun remove(ctx: Context) = file(ctx).delete()

    /** Inasoma picha kwa ukubwa mdogo (inalinda RAM), inarekebisha mzunguko (EXIF) na kuhifadhi JPEG. Tumia background thread. */
    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false

            val orientation = try {
                cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
            } catch (e: Exception) { 1 }
            val deg = when (orientation) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (deg != 0f) {
                val m = Matrix().apply { postRotate(deg) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val scale = MAX_SIDE.toFloat() / maxOf(bmp.width, bmp.height)
            if (scale < 1f) {
                bmp = Bitmap.createScaledBitmap(
                    bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true
                )
            }
            val tmp = File(ctx.filesDir, "home_bg.tmp")
            FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 84, it) }
            val dst = file(ctx)
            if (dst.exists()) dst.delete()
            tmp.renameTo(dst)
        } catch (e: Throwable) {
            false // pamoja na OutOfMemoryError: app haianguki
        }
    }
}
