package com.rahimlux.go

/**
 * Orodha NYEPESI ya trackers (analytics, session recording, attribution, pixels). Imetenganishwa na orodha ya matangazo (AdBlock)
 * ili ionyeshe idadi ya trackers peke yake. Majina yamechaguliwa kuepuka kuvunja tovuti (hakuna googletagmanager, connect.facebook.net n.k.).
 */
object Trackers {
    private val list = hashSetOf(
        "google-analytics.com", "analytics.google.com", "stats.wp.com", "pixel.wp.com", "scorecardresearch.com",
        "quantserve.com", "quantcount.com", "hotjar.com", "hotjar.io", "mixpanel.com", "mxpnl.com", "segment.io",
        "segment.com", "amplitude.com", "fullstory.com", "mouseflow.com", "crazyegg.com", "clarity.ms", "bat.bing.com",
        "newrelic.com", "nr-data.net", "chartbeat.com", "chartbeat.net", "parsely.com", "pixel.facebook.com",
        "analytics.tiktok.com", "business-api.tiktok.com", "analytics.twitter.com", "ads-twitter.com",
        "px.ads.linkedin.com", "snap.licdn.com", "ct.pinterest.com", "tr.snapchat.com", "sc-static.net",
        "appsflyer.com", "adjust.com", "adjust.io", "kochava.com", "singular.net", "app-measurement.com",
        "heap.io", "heapanalytics.com", "logrocket.com", "lr-ingest.io", "smartlook.com", "inspectlet.com",
        "luckyorange.com", "statcounter.com", "histats.com", "cloudflareinsights.com", "tiqcdn.com",
        "analytics.yahoo.com", "sessioncam.com", "clicktale.net", "mc.yandex.ru"
    )

    val count: Int get() = list.size

    /** Inalinganisha host na vikoa vyake vya juu (a.b.hotjar.com -> hotjar.com). */
    fun isTracker(host: String): Boolean {
        var h = host.lowercase()
        while (true) {
            if (h in list) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }
}
