package com.rahimlux.go

import org.json.JSONArray
import org.json.JSONObject

/** Tab zilizofungwa hivi karibuni na vipindi (sessions) vilivyohifadhiwa. Tab za faragha hazihifadhiwi kamwe. */
object TabArchive {
    class Item(val url: String, val title: String, val ts: Long)
    class Session(val name: String, val ts: Long, val items: List<Item>)

    private const val MAX_CLOSED = 25
    private const val MAX_SESSIONS = 10
    private const val MAX_PER_SESSION = 40

    private fun readItems(a: JSONArray?): List<Item> {
        val out = ArrayList<Item>()
        if (a == null) return out
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val u = o.optString("u")
            if (u.startsWith("http")) out.add(Item(u, o.optString("t"), o.optLong("ts")))
        }
        return out
    }

    private fun items(list: List<Item>): JSONArray {
        val a = JSONArray()
        for (x in list) a.put(JSONObject().put("u", x.url).put("t", x.title.take(200)).put("ts", x.ts))
        return a
    }

    @Synchronized fun closed(s: Store): List<Item> = try { readItems(JSONArray(s.closedJson)) } catch (e: Exception) { emptyList() }

    @Synchronized fun pushClosed(s: Store, url: String, title: String) {
        val now = System.currentTimeMillis()
        val list = listOf(Item(url, title, now)) + closed(s).filter { it.url != url }
        s.closedJson = items(list.take(MAX_CLOSED)).toString()
    }

    @Synchronized fun removeClosed(s: Store, url: String, ts: Long) {
        s.closedJson = items(closed(s).filter { !(it.url == url && it.ts == ts) }).toString()
    }

    @Synchronized fun clearClosed(s: Store) { s.closedJson = "[]" }

    @Synchronized fun sessions(s: Store): List<Session> {
        val out = ArrayList<Session>()
        try {
            val a = JSONArray(s.sessionsJson)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Session(o.optString("n"), o.optLong("ts"), readItems(o.optJSONArray("i"))))
            }
        } catch (e: Exception) {
            // orodha mbovu: anza upya
        }
        return out
    }

    private fun writeSessions(s: Store, list: List<Session>) {
        val a = JSONArray()
        for (x in list) a.put(JSONObject().put("n", x.name).put("ts", x.ts).put("i", items(x.items)))
        s.sessionsJson = a.toString()
    }

    @Synchronized fun saveSession(s: Store, name: String, tabs: List<Item>) {
        val me = Session(name.take(40), System.currentTimeMillis(), tabs.take(MAX_PER_SESSION))
        writeSessions(s, (listOf(me) + sessions(s)).take(MAX_SESSIONS))
    }

    @Synchronized fun deleteSession(s: Store, ts: Long) { writeSessions(s, sessions(s).filter { it.ts != ts }) }

    @Synchronized fun clearSessions(s: Store) { s.sessionsJson = "[]" }
}
