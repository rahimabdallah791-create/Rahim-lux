package com.rahimlux.go

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Kurasa zilizohifadhiwa offline (nakala za maandishi). Zinafunguliwa kupitia https://home.rahimlux.go/offline/<jina>, bila kuwasha file access ya WebView. */
object OfflineRepo {
    class Page(val file: String, val title: String, val url: String, val ts: Long, val size: Long)

    private val NAME = Regex("^[0-9]{10,16}_[A-Za-z0-9._-]{1,60}\\.html$")
    private const val MAX_PAGES = 200

    /** Majina salama tu (hakuna "/" wala ".."): inazuia kusoma faili nyingine za app. */
    fun isSafeName(n: String) = NAME.matches(n)

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "offline_pages")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun fileOf(ctx: Context, n: String): File? {
        if (!isSafeName(n)) return null
        val f = File(dir(ctx), n)
        return if (f.isFile) f else null
    }

    fun openUrl(host: String, file: String) = "https://$host/offline/$file"

    @Synchronized fun list(ctx: Context, s: Store): List<Page> {
        val out = ArrayList<Page>()
        val known = HashSet<String>()
        try {
            val a = JSONArray(s.offlineJson)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val f = fileOf(ctx, o.optString("f")) ?: continue
                known.add(f.name)
                out.add(Page(f.name, o.optString("t").ifBlank { f.name }, o.optString("u"), o.optLong("ts", f.lastModified()), f.length()))
            }
        } catch (e: Exception) {
            // orodha mbovu: tunaijenga upya kutoka kwenye faili
        }
        // Faili za toleo la zamani (v44) ambazo hazimo kwenye orodha
        dir(ctx).listFiles()?.forEach { f ->
            if (f.isFile && isSafeName(f.name) && f.name !in known) {
                out.add(Page(f.name, f.name.substringAfter('_').removeSuffix(".html").replace('_', ' '), "", f.lastModified(), f.length()))
            }
        }
        val sorted = out.sortedByDescending { it.ts }
        persist(s, sorted)
        return sorted
    }

    private fun persist(s: Store, list: List<Page>) {
        val a = JSONArray()
        for (p in list.take(MAX_PAGES + 50)) a.put(JSONObject().put("f", p.file).put("t", p.title).put("u", p.url).put("ts", p.ts))
        s.offlineJson = a.toString()
    }

    @Synchronized fun add(ctx: Context, s: Store, file: String, title: String, url: String) {
        val rest = list(ctx, s).filter { it.file != file }
        val me = Page(file, title.take(200), url.take(1000), System.currentTimeMillis(), File(dir(ctx), file).length())
        val all = listOf(me) + rest
        // Futa zilizo za zamani zaidi ya kikomo
        all.drop(MAX_PAGES).forEach { fileOf(ctx, it.file)?.delete() }
        persist(s, all.take(MAX_PAGES))
    }

    @Synchronized fun delete(ctx: Context, s: Store, file: String) {
        fileOf(ctx, file)?.delete()
        list(ctx, s)
    }

    @Synchronized fun deleteAll(ctx: Context, s: Store) {
        dir(ctx).listFiles()?.forEach { if (isSafeName(it.name)) it.delete() }
        persist(s, emptyList())
    }
}
