package com.rahimlux.go

import com.google.firebase.crashlytics.FirebaseCrashlytics

/**
 * Ripoti za kasoro (Crashlytics). Hazina URL, historia wala maudhui ya kurasa: funguo ndogo tu zisizo za kibinafsi (idadi ya tab n.k.).
 * Kila simu imefungwa try/catch, kwa hiyo app haivunjiki ikiwa Firebase haijawekwa.
 */
object Crash {
    private fun c(): FirebaseCrashlytics? = try { FirebaseCrashlytics.getInstance() } catch (e: Throwable) { null }

    fun setEnabled(on: Boolean) { try { c()?.setCrashlyticsCollectionEnabled(on) } catch (e: Throwable) { /* ignore */ } }
    fun key(k: String, v: Int) { try { c()?.setCustomKey(k, v) } catch (e: Throwable) { /* ignore */ } }
    fun log(msg: String) { try { c()?.log(msg.take(200)) } catch (e: Throwable) { /* ignore */ } }

    /** Kasoro isiyovunja app (imeshikwa) lakini tunataka kuiona. */
    fun nonFatal(e: Throwable, where: String) {
        try {
            c()?.log("nonfatal: $where")
            c()?.recordException(e)
        } catch (t: Throwable) { /* ignore */ }
    }
}
