package com.rahimlux.go

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Mteja wa Msaidizi wa afya: anaongea na Worker yako (/medai); funguo za modeli ziko kwenye Worker tu, si kwenye app. */
object MedAi {
    class Msg(val role: String, val text: String)
    class Result(val ok: Boolean, val reply: String, val error: String)

    /** Tumia kwenye background thread. imageDataUrl = "data:image/jpeg;base64,..." (hiari). */
    fun ask(store: Store, history: List<Msg>, lang: String, imageDataUrl: String?): Result {
        val base = store.medUrl.trim().trimEnd('/')
        if (base.isEmpty()) return Result(false, "", "not_configured")
        var c: HttpURLConnection? = null
        return try {
            val arr = JSONArray()
            for (m in history.takeLast(12)) arr.put(JSONObject().put("role", m.role).put("content", m.text))
            val body = JSONObject().put("messages", arr).put("lang", lang)
            if (imageDataUrl != null) body.put("image", imageDataUrl)
            c = URL("$base/medai").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 70000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            val j = JSONObject(if (txt.isEmpty()) "{}" else txt)
            if (j.optBoolean("ok")) Result(true, j.optString("reply"), "") else Result(false, "", j.optString("error", "http_$code"))
        } catch (e: Exception) {
            Result(false, "", "network")
        } finally {
            try { c?.disconnect() } catch (e: Exception) { /* ignore */ }
        }
    }
}
