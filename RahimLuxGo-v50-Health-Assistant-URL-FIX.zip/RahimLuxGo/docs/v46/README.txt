RAHIM LUX GO v46 — Privacy Dashboard + Smart Tab Manager
========================================================
PRIVACY DASHBOARD (Menu > 🛡 Privacy, au Settings > Faragha na usalama > Privacy dashboard)
 - Muhtasari: matangazo, trackers na media nzito vilivyozuiwa + MAKADIRIO ya data (tangazo ~35 KB, tracker ~12 KB, video nzito ~1.5 MB).
   Ni makadirio, si kipimo halisi cha mtandao.
 - Trackers: orodha NYEPESI (Trackers.kt, vikoa ~55: analytics, session recording, attribution). Inaweza kuzimwa kando na ad-block.
   Maombi ya ukurasa mkuu hayazuiwi, na tovuti ikizimiwa ad-block (per-site) trackers pia hazizuiwi.
 - Ruhusa:
     * Android: kamera, kipaza sauti, mahali, arifa (hali halisi kupitia checkSelfPermission) + kitufe cha mipangilio ya app.
     * Tovuti: zinaomba mahali/kamera/kipaza sauti; chagua Ruhusu/Zuia na "Kumbuka kwa tovuti hii". Maamuzi yanaonekana hapa
       (gusa kubadilisha, 🗑 kufuta). Chaguo-msingi: Uliza kila mara au Zuia.
     * Tab za faragha hazihifadhi maamuzi.
     * WebView haitumii arifa za tovuti (push) wala mahali kwa nyuma: hazitolewi kamwe.
 - Kufuta data kwa uchaguzi: history, utafutaji, cookies, cache, ruhusa za tovuti, takwimu, tab zilizofungwa/vipindi, kurasa za offline.
   Kuna uthibitisho unaoorodhesha unachofuta kabla ya kufuta.

SMART TAB MANAGER (kitufe cha tabs)
 - Tab zinapangwa: Sasa / Hivi karibuni (chini ya saa 1) / Zamani / Faragha; kila moja ina "ilitumika lini" na 💤 ikiwa imelala.
 - 🧹 Safisha: funga zisizotumika saa 1+, zinazorudiwa, zote isipokuwa hii, za faragha, au zote (kwa uthibitisho).
 - 💾 Vipindi: hifadhi tab zote kama kipindi na uzifungue baadaye. ↩ Zilizofungwa: rudisha tab ulizofunga (hadi 25; za faragha hazihifadhiwi).
 - WebView zinaundwa INAPOHITAJIKA: ukifungua app, tab ya sasa tu ndiyo inaundwa; zilizobaki ni "zimelala" (jina na URL tu).
 - Settings > Smart tab saver: Off / Wastani (tab 3 za nyuma, zinalala baada ya dakika 15) / Kali (tab 1 ya nyuma, dakika 3).
   Tab iliyolala inapakia upya ukiifungua (data ya fomu ambayo haijatumwa inapotea). Tab zinazopakia hazilazwi.
 - Tab za nyuma zinasimamishwa (onPause) na zinakaguliwa kila dakika moja.

MAPUNGUFU: haijajengwa wala kujaribiwa kwenye simu. Manifest imeongezwa ruhusa CAMERA, RECORD_AUDIO, MODIFY_AUDIO_SETTINGS,
ACCESS_COARSE/FINE_LOCATION (zote hazihitajiki na uses-feature required=false): sasisha Data Safety ya Google Play.
