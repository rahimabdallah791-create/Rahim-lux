RAHIM LUX GO v50 — MSAIDIZI WA AFYA (MedGemma)
==============================================
Ni msaidizi wa TAARIFA za afya kwa ujumla (kueleza maneno ya kitabibu, maelezo ya dawa, kinga, huduma ya kwanza, kuandaa maswali kwa daktari).
SI daktari: hatambui ugonjwa, hapendekezi dozi binafsi, wala hasimamishi/kuanzisha dawa ulizoandikiwa.

MAHALI: Home > kadi "Msaidizi wa afya"  |  Menyu > Maktaba > 🩺  |  Settings > Faragha na usalama > swichi ya "Health assistant" (kuzima).

JINSI INAVYOFANYA KAZI
  App  ->  Worker yako (/medai)  ->  seva ya MedGemma (API ya aina ya OpenAI: chat/completions)
  Funguo za modeli ziko kwenye Worker tu (Secrets), si kwenye app wala GitHub. Hakuna maudhui ya mazungumzo yanayohifadhiwa au kurekodiwa
  kwenye Worker (KV inahifadhi hesabu za matumizi tu). App haihifadhi mazungumzo (yanapotea ukifunga skrini).

HATUA ZA KUWASHA (Worker)
  1) Pata seva ya MedGemma inayotoa API ya aina ya OpenAI (URL kamili inayoishia /v1/chat/completions). MedGemma ni modeli ya wazi (Hugging Face / Vertex AI);
     wewe ndiye unayeiendesha (au kuikodi) kwenye GPU. Soma Health AI Developer Foundations Terms of Use na Prohibited Use Policy kabla.
  2) Cloudflare > Worker > Settings > Variables and Secrets:
       MEDAI_URL    = URL ya chat/completions (Secret au Text)
       MEDAI_KEY    = ufunguo wa seva hiyo (Secret)
       MEDAI_MODEL  = jina la modeli kama seva inavyolitaka, mf. google/medgemma-1.5-4b-it
     Hiari: MEDAI_DAILY_LIMIT (maswali kwa IP kwa siku, chaguo-msingi 25), MEDAI_GLOBAL_LIMIT (jumla kwa siku, 400 — DHIBITI GHARAMA),
            MEDAI_MAX_TOKENS (600), MEDAI_VISION=0 (kuzima picha).
  3) Deploy worker.js mpya. Fungua  <worker>/health  -> lazima uone  "medai": true.
  4) Fungua app > Msaidizi wa afya > uliza swali la majaribio.
  Bila MEDAI_URL na MEDAI_KEY, app inaonyesha "bado haujawekwa kwenye seva" (haivunjiki).

USALAMA (kimejengwa ndani)
  - Ridhaa ya mara ya kwanza + onyo la kudumu juu ya mazungumzo.
  - Safu ya ndani ya simu (MedSafety.kt), isiyotegemea modeli: dalili za dharura (maumivu ya kifua, kushindwa kupumua, kiharusi, kutokwa na damu nyingi,
    kifafa, sumu/overdose, ujauzito+damu, mtoto mchanga mgonjwa...) zinaonyesha kadi nyekundu yenye kitufe cha kupiga 112; maneno ya kujidhuru
    HAYATUMWI kwa modeli: yanaonyesha ujumbe wa kusaidia na kitufe cha kupiga simu ya dharura. (Kiingereza na Kiswahili.)
  - Worker: system prompt ya kudumu (mteja hawezi kuibadilisha), ujumbe wa "system" kutoka kwa mteja unapuuzwa, urefu na idadi ya ujumbe vimewekewa kikomo,
    picha lazima iwe data URL ya jpeg/png/webp (hakuna URL za nje), na kuna kikomo kwa IP na kikomo cha jumla kwa siku.
  - Picha: inapunguzwa na kuhifadhiwa upya kama JPEG (EXIF/mahali vinaondolewa); inatumwa tu pamoja na ujumbe unaofuata.

MAPUNGUFU NA MAMBO YA KUZINGATIA
  - MedGemma ni modeli ya msingi kwa watengenezaji; Google inasema haijathibitishwa kwa matumizi ya kliniki na matokeo yanahitaji uhakiki.
    Kiswahili kinaweza kuwa na usahihi mdogo kuliko Kiingereza. Usiseme kwenye maelezo ya app kuwa "inatambua magonjwa" au "inabadilisha daktari".
  - Gharama: seva ya GPU inalipiwa kwa muda wa kompyuta. Anza na MEDAI_GLOBAL_LIMIT ndogo na ufuatilie bili.
  - Google Play: tangaza "Health apps" kwenye Play Console, sasisha Data Safety (maswali ya afya yanatumwa kwenye seva) na Privacy Policy,
    na weka tahadhari kwenye maelezo ya app. Haijajengwa wala kujaribiwa kwenye simu.
