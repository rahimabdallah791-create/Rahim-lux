RAHIM LUX GO v38 — source update

Version metadata: versionCode 38, versionName 38.0.

Included in this source:
- Existing v37 Reader Mode and saved offline text pages retained.
- Existing Android DownloadManager-based downloads screen retained. Resume behavior depends on Android DownloadManager and server support; not all downloads can resume.
- Existing PageTranslate flow retained, including Kiswahili target language. Translation requires network access and sends the page URL/content through Google Translate proxy service.
- Added Read Aloud menu action using Android TextToSpeech, with a 12,000-character cap to limit memory/time use. Language quality depends on installed TTS voices.
- Existing tab system, ad-block/data saver, scores, standings, notifications and settings source retained.

Important validation note: this archive contains source code; it has not been successfully built or device-tested in this environment. Build and test before distributing an APK. Verify all existing flows, particularly LIVE SCORES, standings URL, FCM notifications, download completion, private tabs and clear-data behavior.
