WHATSAPP STATUS SAVER (v35)
===========================
Faili: StatusSaverActivity.kt (skrini), StatusRepo.kt (kusoma folda, kuhifadhi, picha ndogo), StatusAutoSaveWorker.kt (Auto-save).
Mahali: Menu > "Status Saver"  |  kadi ya "WhatsApp Status Saver" juu kwenye Home.

JINSI INAVYOFANYA KAZI
 1) WhatsApp inaweka status ulizoziona kwenye folda ya ".Statuses" ndani ya simu.
 2) Mara ya kwanza unabonyeza "Allow access" > "Use this folder" (Android 11+ inahitaji hatua hii; ni folda hiyo tu inasomwa).
    - WhatsApp:          Android/media/com.whatsapp/WhatsApp/Media/.Statuses
    - WhatsApp Business: Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses
 3) Picha/Video zinaonekana kwenye gridi. Gusa = tazama; bonyeza-kwa-muda = chagua nyingi; Hifadhi / Shiriki / Futa.
 4) Nakala zinahifadhiwa kwenye Gallery: Pictures/Rahim Lux Go Status na Movies/Rahim Lux Go Status.
 5) Auto-save (⚙): inahifadhi status mpya kiotomatiki takriban kila dakika 30 (WorkManager) na ukifungua app.

MAPUNGUFU
 - Inaonyesha status ambazo WhatsApp tayari imezipakua kwenye simu (ulizoziona au zilizopakuliwa kiotomatiki).
 - WhatsApp hufuta status baada ya saa 24; Auto-save ikizimwa au Android ikichelewesha kazi ya nyuma, unaweza kukosa baadhi.
 - Kama simu yako inazuia kuchagua folda ya Android/media, mbinu hii haitafanya kazi (hakuna njia mbadala bila ruhusa kubwa).
 - Hifadhi tu status unazoruhusiwa kuzihifadhi (faragha na haki miliki). Haihusiani na WhatsApp.
