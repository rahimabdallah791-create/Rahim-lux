RAHIM LUX GO v48 — MPANGILIO MPYA (hakuna kilichoondolewa wala kubadilishwa kiutendaji)
=======================================================================================
Vitu vilevile, vimepangwa upya ili kurahisisha kuona na kutumia.

HOME (ukurasa wa mwanzo), kutoka juu hadi chini:
 1. Kichwa (hero): nembo kushoto; kulia salamu, "Rahim Lux Go" na maelezo mafupi. Inaokoa nafasi, maudhui yanaanza juu zaidi.
 2. Search box.
 3. Kamba ya ulinzi (Blocked / Data saver / Ad-block): ilikuwa chini kabisa, sasa iko chini ya search ili ionekane mara moja.
 4. Favorites.
 5. WhatsApp Status Saver.
 6. Weather.
 7. Paneli ya MPIRA: Timu yangu + Live Scores + Msimamo wa ligi, vyote ndani ya paneli moja (zinahusiana).
 8. Sports & betting 18+.
 9. News.
10. Paneli ya CUSTOMIZE: Theme + Badilisha picha ya nyuma, vimekusanywa chini.
 Paneli zinaonekana tu kama kuna kilichomo ndani yake (mfano ukizima Timu yangu na Scores, paneli ya Mpira haionekani).
 Tab ya faragha: mpangilio uleule, rangi ya zambarau.

MENYU (kitufe cha menyu) sasa ina makundi 5 yenye vichwa, badala ya orodha moja ya cell 34:
 TAB .................. Tab mpya, Faragha, Funga tab, Pakia upya
 UKURASA HUU .......... Tafuta, Tafsiri, Hifadhi PDF, Hali ya kusoma, Soma kwa sauti, Hifadhi offline, Share
 MAKTABA .............. Bookmark, Bookmarks, History, Vipakuliwa, Kurasa za offline, Status Saver, Arifa
 FARAGHA NA ULINZI .... Faragha (dashboard), Ad-block, Tovuti hii, Data saver, 3rd-party cookies, Zilizozuiwa, Sasisha list, Futa data
 MWONEKANO NA MIPANGILIO Dark web, Desktop site, Sauti, Injini ya kutafuta, Lugha, Ongeza Home, Dhibiti Home, Mipangilio
 Kila cell ina kazi ileile; zimehamishwa tu. Kama hazijaonekana vizuri kwenye simu yako, niambie.

Haijabadilika: rangi na themes za v47, mantiki yote ya app, na maudhui yote.
