RAHIM LUX GO v45 — marekebisho ya v44
=====================================
1) Offline pages sasa zinafunguka: zinatolewa na app yenyewe kupitia https://home.rahimlux.go/offline/<jina> (file access ya WebView
   haijawashwa). Ukurasa wa offline una CSP inayozuia script na rasilimali za nje.
2) Offline page sasa inaweka aya (<p>) badala ya mistari tu.
3) Read aloud: maandishi yanagawanywa vipande (Android inakataa >~4000), kuna ukaguzi wa sauti ya Kiswahili (na njia ya kusakinisha),
   na kubonyeza tena kunasimamisha. Inasimama pia ukihama ukurasa au tab.
4) Manifest: TTS_SERVICE imeongezwa kwenye <queries> (Android 11+).
5) Kurasa za offline: skrini mpya ya kufuta moja/zote na kufungua ukurasa asili; hazihifadhiwi kutoka tab za faragha;
   zinafunguliwa kwa kufuli ya bookmarks (ikiwa imewashwa). Faili za v44 zinaingizwa kiotomatiki kwenye orodha.
Haijajengwa wala kujaribiwa kwenye simu: jenga na ujaribu kabla ya kusambaza.
