v36 — Translate, Save PDF, Kufuli ya fingerprint, Futa data ukiondoka
=====================================================================
Find in page: tayari ipo (Menu > 🔍 Tafuta ukurasani).

🌍 Translate (Menu): tafsiri ukurasa kupitia Google Translate (translate.goog), bila API key. Anwani ya ukurasa inatumwa kwa Google.
   Haifanyi kazi kwa kurasa za login/binafsi au tovuti zinazozuia Google. "Show original" inarudisha ukurasa asili.
🖨 Save PDF (Menu): inafungua dirisha la kuchapisha la Android; chagua "Save as PDF".
🔒 Settings > Faragha na usalama:
   - Lock private tabs: tab ya faragha inafunguka baada ya alama ya kidole/uso (Android 11+: pia PIN/pattern). Inajifunga app ikitoka mbele
     na sekunde 45 baada ya kufungua. Skrini ya tab ya faragha haipigwi screenshot na haionekani kwenye Recents wakati kufuli imewashwa.
   - Lock bookmarks: orodha ya Bookmarks inahitaji kufunguliwa vivyo hivyo.
   - Kuwasha/kuzima kufuli kunahitaji kuthibitisha kwa alama ya kidole.
   - Android 10 na chini: inahitaji alama ya kidole/uso iliyowekwa (PIN peke yake haitoshi).
🧹 Clear data on exit: chagua cha kufuta (history, cookies, cache, tab zilizo wazi). Inafanya kazi ukifunga app kwa Back au
   ukiiondoa kwenye Recents (inafuta app ikifunguliwa tena). Android ikiifunga yenyewe nyuma ya pazia, haifuti.
