RAHIM LUX GO — FAVORITE TEAM (TIMU PENDWA)
==========================================
Faili:
  fav-team.js    kuhifadhi timu (localStorage), kutambua jina la timu, kadi ya kuchagua timu, API
  fav-team.css   muundo wa Glassmorphism + rangi ya kipekee kwa timu pendwa
  demo.html      mfano wa pekee (fungua kwenye browser): kadi + Live Scores + Msimamo

NDANI YA APP (v34): faili hizi hizi ziko kwenye app/src/main/res/raw/ (fav_team_js.js, fav_team_css.css)
na zinatolewa kwa ukurasa wa Home kama /fav.js na /fav.css. Kadi inaonekana juu ya "Live scores".
Kuizima: Settings > "My team card on Home".

JINSI YA KUTUMIA (ukurasa wowote)
  <link rel="stylesheet" href="fav-team.css">
  <div id="myteam" class="myteam"></div>            <- kadi ya kuchagua timu inajijenga hapa
  <script src="fav-team.js"></script>

API:
  favIs("Young Africans")  -> true ikiwa ni timu pendwa (inatambua Yanga SC = Young Africans, Man City = Manchester City...)
  favGet() / favSelect("yanga" au "Jina lolote") / favClear()
  favFilterOn() / favSetFilter(true)               <- kichujio "Timu yangu tu"
  Tukio: document.addEventListener('rlg-fav-change', e => e.detail.team)
  Timu ikibadilika, fav-team.js inaita lsRender() na stRender() (ukizitengeneza kwenye ukurasa wako).

MANTIKI YA KUCHUJA / KUWEKA KWANZA
  Live Scores:  list.filter(m => favIs(m.h)||favIs(m.a))   +  panga timu pendwa kwanza  +  darasa "fav"
  Msimamo:      kadi iliyobandikwa juu (nafasi na pointi)  +  mstari wenye darasa "fav"  +  kichujio cha mstari mmoja
Orodha ya timu: hariri TEAMS ndani ya fav-team.js (id, jina, majina mbadala "a", ligi "lg"). Timu yoyote nje ya orodha inaweza
kuandikwa kwenye kisanduku cha kutafuta ("Use ...").
