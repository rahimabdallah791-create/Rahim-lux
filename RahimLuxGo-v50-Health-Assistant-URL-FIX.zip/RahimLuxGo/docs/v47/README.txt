RAHIM LUX GO v47 — "LUX AURORA" (muonekano mpya)
================================================
MUONEKANO TU: mantiki ya app (tabs, ad-block, scores, ruhusa, kufuli, n.k.) HAIJABADILIKA. Zilizobadilika ni rangi, CSS ya Home,
drawables, mitindo ya dialogs na rangi za skrini za Android.

HOME (ukurasa wa mwanzo)
 - Mandharinyuma ya "aurora": mwanga wa violet, cyan na dhahabu unaosogea polepole (haiwezi kuvuta betri: ni gradient tuli + mwendo wa transform).
 - Search box yenye mstari wa gradient (violet -> cyan -> dhahabu) na kitufe cha dhahabu chenye mng'ao.
 - Kadi za kioo (glass) zenye mpaka laini: Favorites, Weather (anga la gradient), Live Scores (alama ya LIVE inayowaka), Msimamo,
   Habari, Status Saver, Takwimu. Vichwa vya sehemu vina alama ya gradient. Nembo yako haijabadilishwa; ina mng'ao na inaelea kidogo.
 - Muonekano wa faragha (private tab) unabaki wa zambarau, ukiwa na gradient yake.
THEMES (Home > chini > Theme): 5 sasa
   Lux Aurora (mpya, default) · Gold Lux · Neon Cyan · Emerald Green · Light Mode
   Waliohifadhi Gold/Cyan/Emerald/Light wanabaki nazo. Mpya wanapata Lux Aurora.
   Kila theme ni seti ya variables 28 (res/raw/theme_css.css): ongeza theme mpya kwa kunakili kizuizi kimoja.
ANDROID (kivinjari chenyewe)
 - Rangi mpya: mandharinyuma #07070F, bar #0E0E22; violet #8B5CF6 na cyan #22D3EE pamoja na dhahabu #FFB300.
 - Address bar: mstari wa gradient; bottom bar: mstari mwembamba wa gradient juu; menyu/tab sheet: kona 30dp na mpaka wa violet.
 - Kadi ya tab ya sasa: mpaka wa dhahabu wa gradient. Kitufe cha download: gradient ya dhahabu.
 - Dialogs zote (AlertDialog): kona 26dp, mandharinyuma ya violet-giza, vitufe vya dhahabu (res/values/themes.xml: RLG.Dialog).
 - Skrini zote (Settings, Privacy, Downloads, Notifications, Status Saver, Offline, Match): rangi za maandishi na kadi zimelinganishwa.
Haijabadilika: nembo (res/raw/logo.png), icon ya app, na tabia yote ya app.
