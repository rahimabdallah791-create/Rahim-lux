RAHIM LUX GO v49 — Crashlytics, Arifa za timu pendwa, Onboarding, QR scanner
============================================================================

1) CRASHLYTICS (kuona kasoro bila kompyuta)
   - Imeongezwa plugin + SDK ya Firebase Crashlytics (inafanya kazi tu ikiwa app/google-services.json ipo, kama push).
   - HATUA YA KWANZA (mara moja): Firebase Console > mradi "rahimluxgo" > Release & Monitor > Crashlytics > "Enable Crashlytics".
   - Ripoti zinaonekana Firebase baada ya app kufunguliwa tena kufuatia kasoro. Hakuna URL, history wala maudhui ya kurasa; funguo ndogo tu
     (idadi ya tab, hali ya kulaza tab) + aina ya simu na toleo la Android.
   - Settings > Faragha: "Send crash reports" (inaweza kuzimwa) na "Send a test report" (kuthibitisha usanidi; app haifungi).

2) ARIFA ZA TIMU PENDWA
   - Ukichagua timu kwenye Home (Timu yangu) au kwenye onboarding, app inajiandikisha kwa topic team_<id> (mfano team_yanga).
   - Worker (backend/worker.js, TOLEO JIPYA) inatuma kila tukio (goli, kuanza, mapumziko, mwisho...) la mechi ya timu hiyo kwa topic yake,
     na kichwa chenye ⭐. Tukio lile lile likifika kwa njia mbili (match/global/team) linaonyeshwa mara moja (tag + dedupe).
   - Settings > Arifa > "Arifa za timu yangu" (kuwasha/kuzima). Haitegemei swichi ya jumla ya Football.
   - MUHIMU: DEPLOY worker.js mpya kwenye Cloudflare (Edit code > Deploy). Ikiwa umeweka Variable LEAGUES, hakikisha ina ligi za timu zako
     (EPL 39, NBC 567 n.k.), vinginevyo mechi hazifuatiliwi. Jaribio: /admin > "Send TEST team alert (Yanga)".
   - Timu 26 zinazojulikana (Yanga, Simba, Azam, Arsenal, Man City, Real Madrid, ...). Timu ya kuandika mwenyewe haipati arifa (haina key).

3) ONBOARDING (skrini ya kuanzia)
   - Hatua 5: lugha, muonekano (theme), timu pendwa, faragha/arifa/crash reports, kivinjari chaguomsingi.
   - Inaonekana mara ya kwanza tu (usakinishaji mpya). Waliosasisha app na viungo vinavyofunguliwa kutoka app nyingine havioneshwi.
   - Settings > Kuhusu > "Show welcome tour" inaionyesha tena (njia rahisi ya kuijaribu).
   - Theme na timu vilivyochaguliwa vinawekwa kwenye Home kiotomatiki.

4) QR SCANNER
   - Kitufe kipya cha QR kando ya mic kwenye address bar, na Menyu > Tab > "Scan QR".
   - Inatumia kichanganuzi cha Google Play services (hakihitaji ruhusa ya kamera kwenye app; mara ya kwanza kinahitaji intaneti kupakua moduli).
   - Kiungo (http/https) kinathibitishwa na kuonyeshwa kabla ya kufunguliwa; maandishi mengine yanaweza kutafutwa au kunakiliwa, hayafunguliwi yenyewe.

MAPUNGUFU: haijajengwa wala kujaribiwa kwenye simu. Google Play Data Safety: tangaza "Crash logs" na "Diagnostics" (Crashlytics).
