RAHIM LUX GO v6 - Android browser (Kotlin + WebView)
Mpya v6: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
