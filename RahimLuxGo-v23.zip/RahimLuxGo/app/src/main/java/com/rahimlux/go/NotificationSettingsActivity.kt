package com.rahimlux.go

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Mipangilio ya arifa: kuzima/kuwasha kwa kategoria, mechi unazofuata, majaribio, na hali ya push. */
class NotificationSettingsActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var ui: UiKit
    private lateinit var list: LinearLayout
    private val perm = PermHelper(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        ui = UiKit(this, store)
        Notif.ensureChannels(this, store)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0B0D"))
        root.addView(ui.header(ui.t("Notification settings", "Mipangilio ya arifa")))
        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(28))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) build()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun sync() = Push.syncTopics(this)

    private fun onMaster(on: Boolean) {
        if (on) {
            perm.ensure { ok ->
                store.nAll = ok
                if (ok) { Notif.ensureChannels(this, store); Push.refreshToken(this) }
                sync()
                build()
            }
        } else {
            store.nAll = false
            sync()
            build()
        }
    }

    private fun systemSettings() {
        try {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun channelSettings() {
        val ids = Notif.CHANNELS
        AlertDialog.Builder(this).setTitle(ui.t("Sound & vibration", "Sauti na mtetemo"))
            .setItems(ids.map { Notif.channelName(store, it) }.toTypedArray()) { _, i ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            .putExtra(Settings.EXTRA_CHANNEL_ID, ids[i])
                    )
                } catch (e: Exception) { systemSettings() }
            }.show()
    }

    private fun followedDialog() {
        val f = store.follows().entries.toList()
        if (f.isEmpty()) { toast(ui.t("You are not following any match", "Hujafuata mechi yoyote")); return }
        AlertDialog.Builder(this)
            .setTitle(ui.t("Tap a match to stop following", "Gusa mechi ili uache kuifuata"))
            .setItems(f.map { it.value.label.ifEmpty { it.key } }.toTypedArray()) { _, i ->
                store.unfollow(f[i].key)
                sync()
                build()
            }.show()
    }

    private fun testServer() {
        Push.sendTest(this) { ok, msg ->
            runOnUiThread {
                toast(
                    when {
                        ok -> ui.t("Sent. It should arrive in a few seconds.", "Imetumwa. Inapaswa kufika baada ya sekunde chache.")
                        msg == "no_firebase" -> ui.t("Firebase is not set up in this build.", "Firebase haijawekwa kwenye build hii.")
                        msg == "no_token" -> ui.t("Push token not ready yet. Try again in a minute.", "Token ya push bado. Jaribu tena baada ya dakika.")
                        msg == "no_server" -> ui.t("Set the server URL in Settings > Live scores.", "Weka anwani ya seva kwenye Settings > Live scores.")
                        else -> ui.t("Server could not send the test push.", "Seva imeshindwa kutuma push ya majaribio.")
                    }
                )
            }
        }
    }

    private fun build() {
        list.removeAllViews()
        val allowed = perm.granted()
        val pushOk = Push.configured(this)

        // ---- Hali
        ui.section(list, ui.t("Status", "Hali"))
        var c = ui.card()
        ui.switchRow(
            c, ui.t("Enable notifications", "Washa arifa"),
            ui.t("Master switch for all Rahim Lux Go notifications", "Kitufe kikuu cha arifa zote za Rahim Lux Go"),
            store.nAll && allowed
        ) { onMaster(it) }
        ui.row(
            c, ui.t("System permission", "Ruhusa ya mfumo"),
            if (allowed) ui.t("Allowed", "Imeruhusiwa") else ui.t("Blocked. Tap to fix.", "Imezuiwa. Bonyeza kurekebisha."),
            ui.arrow()
        ) { if (allowed) systemSettings() else perm.ensure { build() } }
        ui.row(
            c, "Push (FCM)",
            when {
                !pushOk -> ui.t("Not set up in this build (Firebase config missing)", "Haijawekwa kwenye build hii (Firebase config haipo)")
                store.fcmToken.isEmpty() -> ui.t("Connecting…", "Inaunganisha…")
                else -> ui.t("Connected", "Imeunganishwa")
            },
            null, null
        )
        ui.addCard(list, c)

        // ---- Football
        ui.section(list, ui.t("Football", "Mpira"))
        c = ui.card()
        ui.switchRow(c, ui.t("Football notifications", "Arifa za mpira"),
            ui.t("Match start, half-time, full-time and results", "Mechi kuanza, mapumziko, mwisho na matokeo"), store.nFootball) {
            store.nFootball = it; sync()
        }
        ui.switchRow(c, ui.t("Football goals", "Magoli"), ui.t("Goal alerts", "Arifa za magoli"), store.nGoals) {
            store.nGoals = it; sync()
        }
        ui.row(c, ui.t("Followed matches", "Mechi unazofuata"), store.follows().size.toString(), ui.arrow()) { followedDialog() }
        ui.addCard(list, c)

        // ---- News
        ui.section(list, ui.t("News", "Habari"))
        c = ui.card()
        ui.switchRow(c, ui.t("News notifications", "Arifa za habari"), null, store.nNews) { store.nNews = it; sync() }
        ui.switchRow(c, ui.t("Breaking news", "Habari za haraka"), null, store.nNewsBreaking) { store.nNewsBreaking = it; sync() }
        ui.switchRow(c, "Tanzania", null, store.nNewsTz) { store.nNewsTz = it; sync() }
        ui.switchRow(c, ui.t("Sports", "Michezo"), null, store.nNewsSports) { store.nNewsSports = it; sync() }
        ui.switchRow(c, ui.t("Football news", "Habari za mpira"), null, store.nNewsFootball) { store.nNewsFootball = it; sync() }
        ui.switchRow(c, ui.t("Technology", "Teknolojia"), null, store.nNewsTech) { store.nNewsTech = it; sync() }
        ui.addCard(list, c)

        // ---- Mengine
        ui.section(list, ui.t("Other", "Mengineyo"))
        c = ui.card()
        ui.switchRow(c, ui.t("Download notifications", "Arifa za vipakuliwa"),
            ui.t("Progress and completion (shown by Android)", "Progress na kukamilika (zinaonyeshwa na Android)"), store.nDownloads) { store.nDownloads = it }
        ui.switchRow(c, ui.t("Announcements", "Matangazo ya app"),
            ui.t("New features, updates, maintenance", "Vipengele vipya, masasisho, matengenezo"), store.nAnnounce) { store.nAnnounce = it; sync() }
        ui.switchRow(c, ui.t("Account & security", "Akaunti na usalama"),
            ui.t("Reserved. Rahim Lux Go has no accounts yet.", "Imehifadhiwa. Rahim Lux Go haina akaunti bado."), store.nSecurity) { store.nSecurity = it }
        ui.addCard(list, c)

        // ---- Zana
        ui.section(list, ui.t("Tools", "Zana"))
        c = ui.card()
        ui.row(c, ui.t("Notification center", "Kituo cha arifa"),
            ui.t("Unread: ", "Hazijasomwa: ") + Notif.unread(store), ui.arrow()) {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }
        ui.row(c, ui.t("Sound & vibration", "Sauti na mtetemo"), ui.t("Per-channel settings in Android", "Mipangilio ya kila channel kwenye Android"), ui.arrow()) { channelSettings() }
        ui.row(c, ui.t("Send test notification", "Tuma arifa ya majaribio"), ui.t("On this phone", "Kwenye simu hii"), ui.arrow()) {
            perm.ensure { ok -> if (ok) Notif.test(this) else toast(ui.t("Allow notifications first", "Ruhusu arifa kwanza")) }
        }
        ui.row(c, ui.t("Send test push", "Tuma push ya majaribio"), ui.t("Through your server (checks FCM end to end)", "Kupitia seva yako (inajaribu FCM yote)"), ui.arrow()) { testServer() }
        ui.row(c, ui.t("Reset push registration", "Weka upya usajili wa push"), ui.t("Deletes the token and subscriptions", "Inafuta token na usajili"), ui.arrow()) {
            AlertDialog.Builder(this)
                .setTitle(ui.t("Reset push registration?", "Weka upya usajili wa push?"))
                .setPositiveButton(ui.t("Reset", "Weka upya")) { _, _ ->
                    Push.reset(this) { ok -> runOnUiThread { toast(if (ok) ui.t("Done", "Imekamilika") else ui.t("Not available", "Haipatikani")); build() } }
                }
                .setNegativeButton(ui.t("Cancel", "Ghairi"), null).show()
        }
        ui.addCard(list, c)
    }
}
