package com.rahimlux.go

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Bookmarks, history, Home sites, tabs na settings — zinahifadhiwa kwenye simu. */
class Store(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("rahimluxgo", Context.MODE_PRIVATE)

    private val betting = listOf(
        "Betway" to "https://www.betway.co.tz",
        "Betpawa" to "https://www.betpawa.co.tz",
        "SportyBet" to "https://www.sportybet.com",
        "1win" to "https://1win.com"
    )

    private val defaultSites = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://m.youtube.com",
        "Facebook" to "https://m.facebook.com",
        "Instagram" to "https://www.instagram.com",
        "WhatsApp" to "https://web.whatsapp.com",
        "TikTok" to "https://www.tiktok.com",
        "Wikipedia" to "https://en.wikipedia.org",
        "Mwananchi" to "https://www.mwananchi.co.tz"
    ) + betting

    @Volatile private var adOff: Set<String> = readSet("adoff")

    init {
        if (p.getInt("sv", 1) < 2) {
            if (p.contains("sites")) {
                val cur = read("sites")
                write("sites", cur + betting.filter { b -> cur.none { it.second == b.second } })
            }
            p.edit().putInt("sv", 2).apply()
        }
    }

    var lang: String
        get() = p.getString("lang", "en") ?: "en"
        set(v) = p.edit().putString("lang", v).apply()

    /** "google" | "ddg" | "bing" | "yahoo" */
    var engine: String
        get() = p.getString("eng", "google") ?: "google"
        set(v) = p.edit().putString("eng", v).apply()

    /** Lugha ya voice search: "sw" (default) au "en" */
    var voiceLang: String
        get() = p.getString("vlang", "sw") ?: "sw"
        set(v) = p.edit().putString("vlang", v).apply()

    var desktop: Boolean
        get() = p.getBoolean("desk", false)
        set(v) = p.edit().putBoolean("desk", v).apply()

    var thirdCookies: Boolean
        get() = p.getBoolean("tc", true)
        set(v) = p.edit().putBoolean("tc", v).apply()

    var dataSaver: Boolean
        get() = p.getBoolean("ds", false)
        set(v) = p.edit().putBoolean("ds", v).apply()

    var adblock: Boolean
        get() = p.getBoolean("ab", true)
        set(v) = p.edit().putBoolean("ab", v).apply()

    var darkWeb: Boolean
        get() = p.getBoolean("dw", false)
        set(v) = p.edit().putBoolean("dw", v).apply()

    var blockLogJson: String
        get() = p.getString("blog", "{}") ?: "{}"
        set(v) = p.edit().putString("blog", v).apply()

    // ---- Live scores (data ya mpira tu; ufunguo wa API uko kwenye proxy, si kwenye app) ----
    var scoresOn: Boolean
        get() = p.getBoolean("scon", true)
        set(v) = p.edit().putBoolean("scon", v).apply()

    /** Anwani ya proxy ya scores (https://...). Chaguo-msingi inatoka BuildConfig (env var SCORES_BASE_URL). */
    var scoresUrl: String
        get() = if (p.contains("surl")) (p.getString("surl", "") ?: "") else BuildConfig.SCORES_BASE_URL.ifEmpty { ctx.getString(R.string.scores_server_url) }
        set(v) = p.edit().putString("surl", v).apply()

    var scoresToken: String
        get() = if (p.contains("stok")) (p.getString("stok", "") ?: "") else BuildConfig.SCORES_APP_TOKEN.ifEmpty { ctx.getString(R.string.scores_app_token) }
        set(v) = p.edit().putString("stok", v).apply()

    var scoresJson: String
        get() = p.getString("sjson", "[]") ?: "[]"
        set(v) = p.edit().putString("sjson", v).apply()

    var scoresAtMs: Long
        get() = p.getLong("sat", 0L)
        set(v) = p.edit().putLong("sat", v).apply()

    var scoresDate: String
        get() = p.getString("sdate", "") ?: ""
        set(v) = p.edit().putString("sdate", v).apply()

    // ---------------- Notifications ----------------
    /** Kuu: arifa zote. Chaguo-msingi ZIMEZIMWA hadi mtumiaji awashe (opt-in). */
    var nAll: Boolean
        get() = p.getBoolean("n_all", false)
        set(v) = p.edit().putBoolean("n_all", v).apply()
    var nFootball: Boolean
        get() = p.getBoolean("n_fb", true)
        set(v) = p.edit().putBoolean("n_fb", v).apply()
    var nGoals: Boolean
        get() = p.getBoolean("n_goal", true)
        set(v) = p.edit().putBoolean("n_goal", v).apply()
    var nNews: Boolean
        get() = p.getBoolean("n_news", true)
        set(v) = p.edit().putBoolean("n_news", v).apply()
    var nNewsBreaking: Boolean
        get() = p.getBoolean("n_nb", true)
        set(v) = p.edit().putBoolean("n_nb", v).apply()
    var nNewsTz: Boolean
        get() = p.getBoolean("n_nt", true)
        set(v) = p.edit().putBoolean("n_nt", v).apply()
    var nNewsSports: Boolean
        get() = p.getBoolean("n_ns", false)
        set(v) = p.edit().putBoolean("n_ns", v).apply()
    var nNewsFootball: Boolean
        get() = p.getBoolean("n_nf", false)
        set(v) = p.edit().putBoolean("n_nf", v).apply()
    var nNewsTech: Boolean
        get() = p.getBoolean("n_nx", false)
        set(v) = p.edit().putBoolean("n_nx", v).apply()
    var nDownloads: Boolean
        get() = p.getBoolean("n_dl", true)
        set(v) = p.edit().putBoolean("n_dl", v).apply()
    var nAnnounce: Boolean
        get() = p.getBoolean("n_ann", true)
        set(v) = p.edit().putBoolean("n_ann", v).apply()
    var nSecurity: Boolean
        get() = p.getBoolean("n_sec", true)
        set(v) = p.edit().putBoolean("n_sec", v).apply()
    var notifAsked: Int
        get() = p.getInt("n_asked", 0)
        set(v) = p.edit().putInt("n_asked", v).apply()
    var fcmToken: String
        get() = p.getString("fcm_tok", "") ?: ""
        set(v) = p.edit().putString("fcm_tok", v).apply()
    var nHistJson: String
        get() = p.getString("n_hist", "[]") ?: "[]"
        set(v) = p.edit().putString("n_hist", v).apply()
    var nSeenJson: String
        get() = p.getString("n_seen", "[]") ?: "[]"
        set(v) = p.edit().putString("n_seen", v).apply()
    var fcmTopics: Set<String>
        get() {
            val a = JSONArray(p.getString("fcm_topics", "[]"))
            return (0 until a.length()).map { a.getString(it) }.toSet()
        }
        set(v) = p.edit().putString("fcm_topics", JSONArray(v.toList()).toString()).apply()

    class Follow(val label: String, val ko: Long, val events: Set<String>)

    /** Mechi unazozifuata (zinazoisha baada ya saa 36 zinaondolewa zenyewe). */
    fun follows(): Map<String, Follow> {
        val out = LinkedHashMap<String, Follow>()
        try {
            val o = JSONObject(p.getString("n_follow", "{}") ?: "{}")
            val now = System.currentTimeMillis()
            for (id in o.keys()) {
                val f = o.getJSONObject(id)
                val ko = f.optLong("k", 0L)
                if (ko != 0L && now - ko > 36L * 3600 * 1000) continue
                val ev = f.optJSONArray("e")
                val set = (0 until (ev?.length() ?: 0)).map { ev!!.getString(it) }.toSet()
                out[id] = Follow(f.optString("l"), ko, set)
            }
        } catch (e: Exception) { }
        return out
    }

    fun getFollow(id: String): Follow? = follows()[id]

    private fun saveFollows(m: Map<String, Follow>) {
        val o = JSONObject()
        for ((id, f) in m) o.put(id, JSONObject().put("l", f.label).put("k", f.ko).put("e", JSONArray(f.events.toList())))
        p.edit().putString("n_follow", o.toString()).apply()
    }

    fun follow(id: String, label: String, ko: Long, events: Set<String>) {
        val m = LinkedHashMap(follows())
        m[id] = Follow(label, ko, events)
        saveFollows(m)
    }

    fun unfollow(id: String) {
        val m = LinkedHashMap(follows())
        m.remove(id)
        saveFollows(m)
    }

    var scoresSrvMs: Long
        get() = p.getLong("ssrv", 0L)
        set(v) = p.edit().putLong("ssrv", v).apply()
    var scoresStale: Boolean
        get() = p.getBoolean("sstale", false)
        set(v) = p.edit().putBoolean("sstale", v).apply()
    /** Wakati picha ya nyuma ilipowekwa (0 = hakuna). Inatumika pia kuzuia cache ya zamani. */
    var bgVersion: Long
        get() = p.getLong("bg_ver", 0L)
        set(v) = p.edit().putLong("bg_ver", v).apply()
    /** Giza juu ya picha (0..80) ili maandishi yasomeke */
    var bgDim: Int
        get() = p.getInt("bg_dim", 45)
        set(v) = p.edit().putInt("bg_dim", v.coerceIn(0, 80)).apply()

    /** Msimamo wa ligi kwenye Home (EPL na NBC Premier League ziko kila mara) */
    var standingsOn: Boolean
        get() = p.getBoolean("std_on", true)
        set(v) = p.edit().putBoolean("std_on", v).apply()

    /** URL ya Worker tofauti ya msimamo wa ligi; huru kabisa na Live Scores. */
    var standingsUrl: String
        get() = if (p.contains("std_url")) (p.getString("std_url", "") ?: "") else "https://standings.rahimabdallah791.workers.dev"
        set(v) = p.edit().putString("std_url", v).apply()

    /** Token ya hiari ya Standings Worker ikiwa APP_TOKEN imewekwa. */
    var standingsToken: String
        get() = p.getString("std_token", "") ?: ""
        set(v) = p.edit().putString("std_token", v).apply()

    /** Kadi ya "Timu yangu" (timu pendwa) kwenye Home */
    var favOn: Boolean
        get() = p.getBoolean("fav_on", true)
        set(v) = p.edit().putBoolean("fav_on", v).apply()

    // ---- WhatsApp Status Saver (folda ya .Statuses uliyoruhusu; nakala zilizohifadhiwa ziko kwenye simu yako tu) ----
    var ssTreeWa: String
        get() = p.getString("ss_tree_wa", "") ?: ""
        set(v) = p.edit().putString("ss_tree_wa", v).apply()
    var ssTreeWab: String
        get() = p.getString("ss_tree_wab", "") ?: ""
        set(v) = p.edit().putString("ss_tree_wab", v).apply()
    var ssSrc: String
        get() = p.getString("ss_src", "wa") ?: "wa"
        set(v) = p.edit().putString("ss_src", v).apply()
    var ssAuto: Boolean
        get() = p.getBoolean("ss_auto", false)
        set(v) = p.edit().putBoolean("ss_auto", v).apply()
    var ssIntro: Boolean
        get() = p.getBoolean("ss_intro", false)
        set(v) = p.edit().putBoolean("ss_intro", v).apply()
    var ssSavedJson: String
        get() = p.getString("ss_saved", "[]") ?: "[]"
        set(v) = p.edit().putString("ss_saved", v).apply()
    var ssSeenJson: String
        get() = p.getString("ss_seen", "[]") ?: "[]"
        set(v) = p.edit().putString("ss_seen", v).apply()

    // ---- Kufuli ya fingerprint + Futa data ukiondoka ----
    var lockPriv: Boolean
        get() = p.getBoolean("lock_priv", false)
        set(v) = p.edit().putBoolean("lock_priv", v).apply()
    var lockBm: Boolean
        get() = p.getBoolean("lock_bm", false)
        set(v) = p.edit().putBoolean("lock_bm", v).apply()
    var clearExit: Boolean
        get() = p.getBoolean("clear_exit", false)
        set(v) = p.edit().putBoolean("clear_exit", v).apply()
    /** bits: 1 = history+utafutaji, 2 = cookies+data ya tovuti, 4 = cache+fomu, 8 = tab zilizo wazi */
    var clearWhat: Int
        get() = p.getInt("clear_what", 7)
        set(v) = p.edit().putInt("clear_what", v).apply()
    var exitPending: Boolean
        get() = p.getBoolean("exit_pending", false)
        set(v) = p.edit().putBoolean("exit_pending", v).apply()

    /** Orodha ya kurasa zilizohifadhiwa offline (OfflineRepo) */
    var offlineJson: String
        get() = p.getString("offline_index", "[]") ?: "[]"
        set(v) = p.edit().putString("offline_index", v).apply()

    // ---- v46: Privacy Dashboard + Smart Tab Manager ----
    var trackerBlock: Boolean
        get() = p.getBoolean("trk_block", true)
        set(v) = p.edit().putBoolean("trk_block", v).apply()
    val blkAds: Int get() = p.getInt("blk_ads", 0)
    val blkTrackers: Int get() = p.getInt("blk_trk", 0)
    val blkMedia: Int get() = p.getInt("blk_media", 0)
    val savedBytes: Long get() = p.getLong("saved_bytes", 0L)
    val statsSince: Long get() = p.getLong("stats_since", 0L)

    /** Inarekodi ombi lililozuiwa (aina: Blk.AD / TRACKER / MEDIA) pamoja na makadirio ya data. */
    @Synchronized fun recordBlock(kind: Int) {
        val e = p.edit()
        e.putInt("blocked", blocked + 1)
        when (kind) {
            Blk.AD -> e.putInt("blk_ads", blkAds + 1)
            Blk.TRACKER -> e.putInt("blk_trk", blkTrackers + 1)
            else -> e.putInt("blk_media", blkMedia + 1)
        }
        e.putLong("saved_bytes", savedBytes + Blk.bytes[kind.coerceIn(0, 2)])
        if (statsSince == 0L) e.putLong("stats_since", System.currentTimeMillis())
        e.apply()
    }

    /** Makadirio ya jumla: yaliyorekodiwa + maombi ya zamani (kabla ya v46) kwa wastani wa 35 KB. */
    val estSavedBytes: Long
        get() = savedBytes + maxOf(0, blocked - blkAds - blkTrackers - blkMedia).toLong() * 35L * 1024L

    fun resetPrivacyStats() {
        p.edit().putInt("blocked", 0).putInt("blk_ads", 0).putInt("blk_trk", 0).putInt("blk_media", 0)
            .putLong("saved_bytes", 0L).putLong("stats_since", System.currentTimeMillis()).apply()
        BlockLog.clear()
        blockLogJson = "{}"
    }

    var webClearPending: Boolean
        get() = p.getBoolean("web_clear_pending", false)
        set(v) = p.edit().putBoolean("web_clear_pending", v).apply()

    /** 0 = uliza kila mara, -1 = zuia (chaguo-msingi la ruhusa za tovuti) */
    var permDefGeo: Int
        get() = p.getInt("perm_def_geo", 0)
        set(v) = p.edit().putInt("perm_def_geo", v).apply()
    var permDefCam: Int
        get() = p.getInt("perm_def_cam", 0)
        set(v) = p.edit().putInt("perm_def_cam", v).apply()
    var permDefMic: Int
        get() = p.getInt("perm_def_mic", 0)
        set(v) = p.edit().putInt("perm_def_mic", v).apply()
    var sitePermsJson: String
        get() = p.getString("site_perms", "{}") ?: "{}"
        set(v) = p.edit().putString("site_perms", v).apply()

    /** Smart tab saver: 0 = zimezimwa, 1 = wastani, 2 = kali */
    var tabSleep: Int
        get() = p.getInt("tab_sleep", 1)
        set(v) = p.edit().putInt("tab_sleep", v).apply()
    var closedJson: String
        get() = p.getString("tabs_closed", "[]") ?: "[]"
        set(v) = p.edit().putString("tabs_closed", v).apply()
    var sessionsJson: String
        get() = p.getString("tab_sessions", "[]") ?: "[]"
        set(v) = p.edit().putString("tab_sessions", v).apply()

    var weatherOn: Boolean
        get() = p.getBoolean("wx_on", true)
        set(v) = p.edit().putBoolean("wx_on", v).apply()
    /** URL ya Worker ya hali ya hewa, tofauti na Live Scores. */
    var weatherUrl: String
        get() = p.getString("wx_url", "") ?: ""
        set(v) = p.edit().putString("wx_url", v).apply()

    /** Token ya hiari ya Worker ya hali ya hewa. */
    var weatherToken: String
        get() = p.getString("wx_token", "") ?: ""
        set(v) = p.edit().putString("wx_token", v).apply()

    /** "" = otomatiki (makadirio kutoka mtandao), vinginevyo jina la mji */
    var weatherCity: String
        get() = p.getString("wx_city", "") ?: ""
        set(v) = p.edit().putString("wx_city", v).apply()
    var weatherJson: String
        get() = p.getString("wx_json", "{}") ?: "{}"
        set(v) = p.edit().putString("wx_json", v).apply()
    var weatherAtMs: Long
        get() = p.getLong("wx_at", 0L)
        set(v) = p.edit().putLong("wx_at", v).apply()

    var fcmTopicsAt: Long
        get() = p.getLong("fcm_topics_at", 0L)
        set(v) = p.edit().putLong("fcm_topics_at", v).apply()

    var newsUpdated: Long
        get() = p.getLong("newsu", 0L)
        set(v) = p.edit().putLong("newsu", v).apply()

    var newsJson: String
        get() = p.getString("news", "{}") ?: "{}"
        set(v) = p.edit().putString("news", v).apply()

    var tabsJson: String
        get() = p.getString("tabs", "{}") ?: "{}"
        set(v) = p.edit().putString("tabs", v).apply()

    fun resetBlocked() = p.edit().putInt("blocked", 0).apply()

    val blocked: Int get() = p.getInt("blocked", 0)

    @Synchronized
    fun addBlocked() = p.edit().putInt("blocked", blocked + 1).apply()

    /** Makadirio ya bando lililookolewa; si kipimo halisi cha operator. */
    val estimatedSavedMb: Double get() = blocked.toLong() * 35.0 / 1024.0

    /** Ad-block imezimwa kwa tovuti hii? (thread-safe, inatumika kwenye background thread) */
    fun isAdOff(host: String?): Boolean = host != null && adOff.contains(host.removePrefix("www."))

    /** Rudisha true ikiwa sasa ad-block IMEZIMWA kwa tovuti hii. */
    fun toggleAdOff(host: String): Boolean {
        val h = host.removePrefix("www.")
        val nowOff = h !in adOff
        adOff = if (nowOff) adOff + h else adOff - h
        p.edit().putString("adoff", JSONArray(adOff.toList()).toString()).apply()
        return nowOff
    }

    fun searches(): List<String> {
        val a = JSONArray(p.getString("srch", "[]"))
        return (0 until a.length()).map { a.getString(it) }
    }

    fun addSearch(q: String) {
        val l = listOf(q) + searches().filter { !it.equals(q, ignoreCase = true) }
        p.edit().putString("srch", JSONArray(l.take(100)).toString()).apply()
    }

    fun removeSearch(q: String) {
        val l = searches().filter { !it.equals(q, ignoreCase = true) }
        p.edit().putString("srch", JSONArray(l).toString()).apply()
    }

    fun clearSearches() = p.edit().remove("srch").apply()

    fun bookmarks() = read("bm")
    fun history() = read("hi")
    fun sites(): List<Pair<String, String>> = if (p.contains("sites")) read("sites") else defaultSites

    fun addBookmark(title: String, url: String) =
        write("bm", listOf(title to url) + read("bm").filter { it.second != url })

    fun addHistory(title: String, url: String) =
        write("hi", (listOf(title to url) + read("hi").filter { it.second != url }).take(200))

    fun addSite(name: String, url: String) =
        write("sites", sites().filter { it.second != url } + (name to url))

    fun removeSite(url: String) = write("sites", sites().filter { it.second != url })

    fun clearHistory() = p.edit().remove("hi").apply()

    private fun readSet(k: String): Set<String> {
        val a = JSONArray(p.getString(k, "[]"))
        return (0 until a.length()).map { a.getString(it) }.toSet()
    }

    private fun read(k: String): List<Pair<String, String>> {
        val a = JSONArray(p.getString(k, "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            o.getString("t") to o.getString("u")
        }
    }

    private fun write(k: String, l: List<Pair<String, String>>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.first).put("u", it.second)) }
        p.edit().putString(k, a.toString()).apply()
    }
}
