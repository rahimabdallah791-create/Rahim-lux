RAHIM LUX GO v8 - Android browser (Kotlin + WebView)
Mpya v8: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.
