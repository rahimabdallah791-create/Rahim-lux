plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
// Firebase: google-services.json (kutoka Firebase console) ikiwekwa kwenye ROOT ya repo au kwenye app/, plugin inawashwa.
// Bila faili hiyo build inaendelea kufanya kazi na push zinakaa "not set up" (app haivunjiki).
val repoJson = rootProject.file("../google-services.json")
val appJson = file("google-services.json")
if (!appJson.exists() && repoJson.exists()) repoJson.copyTo(appJson)
if (appJson.exists()) apply(plugin = "com.google.gms.google-services")

android {
    namespace = "com.rahimlux.go"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.rahimlux.go"
        minSdk = 26
        targetSdk = 34
        versionCode = 27
        versionName = "27.0"
        // Anwani ya proxy ya scores (si siri). Weka kupitia env var wakati wa build, au ndani ya app: Settings > Live scores.
        buildConfigField("String", "SCORES_BASE_URL", "\"" + (System.getenv("SCORES_BASE_URL") ?: "").replace("\"", "") + "\"")
        buildConfigField("String", "SCORES_APP_TOKEN", "\"" + (System.getenv("SCORES_APP_TOKEN") ?: "").replace("\"", "") + "\"")
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildFeatures { buildConfig = true }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-messaging")
    testImplementation("junit:junit:4.13.2")
    implementation("com.google.android.gms:play-services-ads:23.3.0")
}
