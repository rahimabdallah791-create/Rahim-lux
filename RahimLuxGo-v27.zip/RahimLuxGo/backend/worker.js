// Rahim Lux Go — Server (Cloudflare Worker)  v4
// 1) GET  /scores                      Live scores (API-Football) kwa app — inalinda quota na inaonyesha data ya zamani kwa uwazi
// 2) POST /device, /device/delete, /test   usajili wa push (hash tu) + test push
// 3) scheduled (Cron)                  football events + news -> FCM topics (server-side, app haihitaji kuwa wazi)
// 4) GET  /admin, POST /admin/send, /admin/run   kutuma announcements + kuendesha news/football mara moja kwa ukaguzi
// 5) GET  /health                      hali ya seva (cron, KV, quota)
//
// Secrets / variables:
//   FOOTBALL_API_KEY (secret)  FCM_SERVICE_ACCOUNT (secret)  ADMIN_TOKEN (secret)  APP_TOKEN (hiari)
//   API_DAILY_LIMIT (90)       maombi yote ya API-Football kwa siku (scores + cron). Free = 100. Paid: weka juu (mfano 7000)
//   FOOTBALL_DAILY_BUDGET (40) sehemu ya API_DAILY_LIMIT ambayo cron ya mpira inaruhusiwa kutumia
//   LIVE_TTL (60) IDLE_TTL (600)  cache ya chini kabisa; seva huongeza muda yenyewe ili quota ya siku nzima ifike mwisho wa siku
//   FOOTBALL_POLL_SECS (120) FOOTBALL_IDLE_SECS (1800) NEWS_POLL_SECS (600) LEAGUES LEAGUES_TOP TIMEZONE
// Binding: KV namespace STATE.   Cron Trigger: "* * * * *"

const LIVE = new Set(["1H", "HT", "2H", "ET", "BT", "P", "LIVE", "INT"]);
const memo = new Map();
const mem = new Map();
const enc = new TextEncoder();
const TOP_DEFAULT = "39,140,135,78,61,2,3,848,12,6,1,4,5,567"; // thibitisha id za ligi unazotaka kupitia API-Football
let hbLast = 0;

function reply(obj, status, ttl) {
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": ttl ? "public, max-age=" + ttl : "no-store",
      "access-control-allow-origin": "*",
      "x-content-type-options": "nosniff",
    },
  });
}
const kv = (env) => ({
  async get(k) {
    if (env.STATE) return env.STATE.get(k);
    const e = mem.get(k);
    return e && e.exp > Date.now() ? e.v : null;
  },
  async put(k, v, ttl) {
    const t = Math.max(60, ttl || 604800);
    if (env.STATE) return env.STATE.put(k, v, { expirationTtl: t });
    mem.set(k, { v: v, exp: Date.now() + t * 1000 });
  },
  async del(k) {
    if (env.STATE) return env.STATE.delete(k);
    mem.delete(k);
  },
});
function ctEq(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
const appOk = (request, env) => !env.APP_TOKEN || ctEq(request.headers.get("X-App-Token") || "", env.APP_TOKEN);
async function sha(s) {
  const d = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function b64url(bytes) {
  const u = new Uint8Array(bytes);
  let s = "";
  for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function pemToDer(pem) {
  const s = atob(pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, ""));
  const u = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
  return u.buffer;
}

// ---------- FCM (HTTP v1) ----------
let tokCache = { v: "", exp: 0 };
async function accessToken(sa) {
  if (tokCache.v && tokCache.exp > Date.now() + 60000) return tokCache.v;
  const now = Math.floor(Date.now() / 1000);
  const head = b64url(enc.encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const claim = b64url(enc.encode(JSON.stringify({
    iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600,
  })));
  const key = await crypto.subtle.importKey("pkcs8", pemToDer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(head + "." + claim));
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: "grant_type=" + encodeURIComponent("urn:ietf:params:oauth:grant-type:jwt-bearer") + "&assertion=" + head + "." + claim + "." + b64url(sig),
  });
  if (!r.ok) throw new Error("oauth " + r.status);
  const j = await r.json();
  tokCache = { v: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return tokCache.v;
}
// opts: { notification: {title, body, image}, channel, tag }
// "notification message" + data: Google Play services inaionyesha hata app ikiwa imefungwa au simu (OEM) inazuia data-only messages.
// tag = id ya tukio, ili ujumbe ule ule ukija kwa topics mbili ujibadilishe badala ya kujirudia.
async function sendFcm(env, target, data, ttl, opts) {
  const t0 = Date.now();
  if (!env.FCM_SERVICE_ACCOUNT) return { ok: false, status: 0, text: "fcm_not_configured", ms: { total: 0 } };
  try {
    const sa = JSON.parse(env.FCM_SERVICE_ACCOUNT);
    const at = await accessToken(sa);
    const t1 = Date.now();
    const dd = {};
    for (const k in data) if (data[k] !== undefined && data[k] !== null) dd[k] = String(data[k]);
    const android = { priority: "HIGH", ttl: (ttl || 3600) + "s" };
    if (opts && (opts.channel || opts.tag)) {
      android.notification = {};
      if (opts.channel) android.notification.channel_id = opts.channel;
      if (opts.tag) android.notification.tag = String(opts.tag).slice(0, 100);
    }
    const message = Object.assign({}, target, { data: dd, android: android });
    if (opts && opts.notification) message.notification = opts.notification;
    const r = await fetch("https://fcm.googleapis.com/v1/projects/" + sa.project_id + "/messages:send", {
      method: "POST",
      headers: { authorization: "Bearer " + at, "content-type": "application/json" },
      body: JSON.stringify({ message: message }),
    });
    const t2 = Date.now();
    return { ok: r.ok, status: r.status, text: r.ok ? "" : (await r.text()).slice(0, 300), ms: { oauth: t1 - t0, send: t2 - t1, total: t2 - t0 } };
  } catch (e) {
    return { ok: false, status: 0, text: String(e && e.message || e).slice(0, 200), ms: { total: Date.now() - t0 } };
  }
}
const sendTopic = (env, topic, data, ttl, opts) => sendFcm(env, { topic: topic }, data, ttl, opts);

// ---------- API-Football: quota ya pamoja (scores + cron) ----------
const dayKey = () => new Date().toISOString().slice(0, 10);
function secsToMidnightUtc() {
  const n = new Date();
  return Math.max(60, Math.round((Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate() + 1) - n.getTime()) / 1000));
}
const limitOf = (env) => Math.max(10, parseInt(env.API_DAILY_LIMIT || "90", 10) || 90);
async function usage(st) {
  const day = dayKey();
  return { day: day, used: parseInt((await st.get("api:count:" + day)) || "0", 10), blocked: !!(await st.get("api:blocked:" + day)) };
}
// Simu YOTE ya API-Football inapita hapa. Inarudisha {data} | {quota:true} | {error}
async function apiCall(env, st, query, who) {
  const u = await usage(st);
  const limit = limitOf(env);
  const cap = who === "cron" ? Math.min(limit, parseInt(env.FOOTBALL_DAILY_BUDGET || "40", 10) || 40) : limit;
  if (u.blocked || u.used >= cap) return { quota: true, used: u.used, limit: cap };
  await st.put("api:count:" + u.day, String(u.used + 1), 90000);
  try {
    const tz = env.TIMEZONE || "Africa/Dar_es_Salaam";
    const r = await fetch("https://v3.football.api-sports.io/fixtures?" + query + "&timezone=" + encodeURIComponent(tz),
      { headers: { "x-apisports-key": env.FOOTBALL_API_KEY } });
    if (!r.ok) return { error: "upstream " + r.status };
    const d = await r.json();
    if (d.errors && Object.keys(d.errors).length) {
      const txt = JSON.stringify(d.errors);
      if (/request|limit|quota/i.test(txt)) { // API imesema quota imeisha: acha kuuliza hadi UTC usiku wa manane
        await st.put("api:blocked:" + u.day, "1", secsToMidnightUtc());
        return { quota: true, used: u.used + 1, limit: cap };
      }
      return { error: txt.slice(0, 200) };
    }
    return { data: d.response || [], used: u.used + 1 };
  } catch (e) {
    return { error: String(e && e.message || e).slice(0, 100) };
  }
}

// ---------- /scores ----------
async function getScores(env, date) {
  const st = kv(env);
  const liveTtl = Math.max(15, parseInt(env.LIVE_TTL || "60", 10) || 60);
  const idleTtl = Math.max(60, parseInt(env.IDLE_TTL || "600", 10) || 600);
  let cached = memo.get(date);
  if (!cached) {
    const raw = await st.get("scores:" + date);
    if (raw) { try { cached = JSON.parse(raw); memo.set(date, cached); } catch (e) { cached = null; } }
  }
  if (cached && cached.exp > Date.now()) {
    return { body: cached.body, ttl: Math.max(1, Math.round((cached.exp - Date.now()) / 1000)) };
  }
  const res = await apiCall(env, st, "date=" + date, "scores");
  if (res.data) {
    const allow = env.LEAGUES ? new Set(env.LEAGUES.split(",").map((s) => s.trim())) : null;
    const matches = res.data
      .filter((r) => !allow || allow.has(String(r.league && r.league.id)))
      .slice(0, 400)
      .map((r) => ({
        id: r.fixture.id, lg: r.league.name, co: r.league.country, h: r.teams.home.name, a: r.teams.away.name,
        hg: r.goals.home, ag: r.goals.away, st: r.fixture.status.short, min: r.fixture.status.elapsed, ko: r.fixture.date,
      }));
    const hasLive = matches.some((m) => LIVE.has(m.st));
    const body = { ok: true, updated: new Date().toISOString(), hasLive: hasLive, matches: matches };
    // Gawa maombi yaliyobaki kwa muda uliobaki wa siku, ili quota isiishe saa chache na data igande
    const spread = Math.ceil(secsToMidnightUtc() / Math.max(1, limitOf(env) - res.used));
    const ttl = Math.max(hasLive ? liveTtl : idleTtl, spread);
    const entry = { body: body, exp: Date.now() + ttl * 1000 };
    memo.set(date, entry);
    await st.put("scores:" + date, JSON.stringify(entry), 21600);
    return { body: body, ttl: ttl };
  }
  // Imeshindwa au quota imeisha: toa data ya zamani LAKINI ikiwa na alama wazi (stale / quota / age_s)
  if (cached) {
    const age = Math.round((Date.now() - Date.parse(cached.body.updated)) / 1000);
    if (res.quota || age < 1800) {
      return { body: Object.assign({}, cached.body, { stale: true, quota: !!res.quota, age_s: age }), ttl: 30 };
    }
  }
  return { error: true, quota: !!res.quota };
}

// ---------- Football events (server-side) ----------
const pack = (r) => ({
  id: r.fixture.id, lg: r.league.name, lgid: r.league.id, h: r.teams.home.name, a: r.teams.away.name,
  hg: r.goals.home, ag: r.goals.away, st: r.fixture.status.short, min: r.fixture.status.elapsed,
});
function diffEvents(old, m, out) {
  const ev = (type) => out.push(Object.assign({ type: type }, m));
  if (!old) {
    if (m.st === "1H" && (m.min == null || m.min <= 5)) ev("start");
  } else {
    if ((m.hg || 0) + (m.ag || 0) > (old.hg || 0) + (old.ag || 0)) ev("goal");
    if (m.st === "HT" && old.st !== "HT") ev("ht");
    if (m.st === "ET" && old.st !== "ET") ev("et");
    if (m.st === "P" && old.st !== "P") ev("pen");
  }
  if (["FT", "AET", "PEN"].includes(m.st) && (!old || old.st !== m.st)) ev("ft");
  if (["PST", "CANC", "ABD", "SUSP"].includes(m.st) && (!old || old.st !== m.st)) ev("status");
}
function evId(e) {
  return "fb:" + e.id + ":" + e.type + (e.type === "goal" ? ":" + (e.hg || 0) + "-" + (e.ag || 0) : e.type === "status" ? ":" + e.st : "");
}
async function emit(env, st, e) {
  const key = "evt:" + evId(e);
  if (await st.get(key)) return false; // usitume mara mbili
  await st.put(key, "1", 172800);
  const score = e.h + " " + (e.hg || 0) + "-" + (e.ag || 0) + " " + e.a;
  const titles = { goal: "GOAL! " + score, start: "Kick-off: " + e.h + " vs " + e.a, ht: "Half-time: " + score,
    ft: "Full-time: " + score, et: "Extra time: " + score, pen: "Penalties: " + score, status: e.h + " vs " + e.a + ": " + e.st };
  const data = { id: evId(e), type: "football", event: e.type, match_id: e.id, lg: e.lg, h: e.h, a: e.a,
    hg: e.hg == null ? 0 : e.hg, ag: e.ag == null ? 0 : e.ag, min: e.min == null ? "" : e.min, st: e.st,
    title: titles[e.type], body: e.lg };
  const opts = { channel: e.type === "goal" ? "football_goals" : "football_live", tag: data.id,
    notification: { title: titles[e.type], body: (e.lg || "") + (e.type === "goal" && e.min != null ? " · " + e.min + "'" : "") } };
  await sendTopic(env, "m" + e.id + "_" + e.type, Object.assign({ scope: "match" }, data), 900, opts);
  const top = new Set((env.LEAGUES_TOP || TOP_DEFAULT).split(",").map((s) => s.trim()));
  if (top.has(String(e.lgid))) await sendTopic(env, e.type === "goal" ? "football_goals" : "football", Object.assign({ scope: "global" }, data), 900, opts);
  return true;
}
async function footballTick(env, opts) {
  opts = opts || {};
  const stats = { job: "football", polled: false, live: 0, events: 0, sent: 0, note: "" };
  if (!env.FOOTBALL_API_KEY) { stats.note = "no_football_key"; return stats; }
  if (!env.FCM_SERVICE_ACCOUNT) { stats.note = "no_fcm_service_account"; return stats; }
  const st = kv(env);
  const state = JSON.parse((await st.get("fb:state")) || "{}");
  const prev = state.live || {};
  const poll = Math.max(30, parseInt(env.FOOTBALL_POLL_SECS || "120", 10) || 120);
  const idle = Math.max(poll, parseInt(env.FOOTBALL_IDLE_SECS || "1800", 10) || 1800);
  const nowMs = Date.now();
  if (!opts.force && nowMs - (state.last || 0) < (Object.keys(prev).length ? poll : idle) * 1000) { stats.note = "waiting"; return stats; }
  const live = await apiCall(env, st, "live=all", "cron");
  if (!live.data) {
    stats.note = live.quota ? "quota_reached" : "api_error: " + live.error;
    await st.put("fb:state", JSON.stringify({ last: nowMs, live: prev, note: stats.note }), 90000);
    return stats;
  }
  stats.polled = true;
  const now = {};
  for (const r of live.data) now[r.fixture.id] = pack(r);
  stats.live = Object.keys(now).length;
  const events = [];
  for (const id in now) diffEvents(prev[id], now[id], events);
  const gone = Object.keys(prev).filter((id) => !(id in now)).slice(0, 20);
  if (gone.length) {
    const fin = await apiCall(env, st, "ids=" + gone.join("-"), "cron");
    if (fin.data) for (const r of fin.data) { const m = pack(r); diffEvents(prev[m.id], m, events); }
  }
  await st.put("fb:state", JSON.stringify({ last: nowMs, live: now }), 90000);
  stats.events = events.length;
  for (const e of events) if (await emit(env, st, e)) stats.sent++;
  return stats;
}

// ---------- News ----------
const NEWS = [
  { key: "breaking", topic: "news", cat: "breaking", url: "https://feeds.bbci.co.uk/news/rss.xml", src: "BBC News", max: 1, gap: 1800 },
  { key: "tz", topic: "news_tanzania", cat: "tanzania", url: "https://news.google.com/rss?hl=en-TZ&gl=TZ&ceid=TZ:en", src: "Google News", max: 2, gap: 600 },
  { key: "sports", topic: "news_sports", cat: "sports", url: "https://feeds.bbci.co.uk/sport/rss.xml", src: "BBC Sport", max: 1, gap: 900 },
  { key: "football", topic: "news_football", cat: "football", url: "https://feeds.bbci.co.uk/sport/football/rss.xml", src: "BBC Sport", max: 1, gap: 900 },
  { key: "tech", topic: "news_technology", cat: "technology", url: "https://feeds.bbci.co.uk/news/technology/rss.xml", src: "BBC News", max: 1, gap: 1800 },
];
const unxml = (s) => s.replace("<![CDATA[", "").replace("]]>", "").replace(/&amp;/g, "&").replace(/&lt;/g, "<")
  .replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();
function parseRss(xml) {
  const out = [];
  const re = /<item>([\s\S]*?)<\/item>/g;
  let m;
  while ((m = re.exec(xml))) {
    const b = m[1];
    const t = /<title>([\s\S]*?)<\/title>/.exec(b);
    const l = /<link>([\s\S]*?)<\/link>/.exec(b);
    if (!t || !l) continue;
    const s = /<source[^>]*>([\s\S]*?)<\/source>/.exec(b);
    const im = /<media:thumbnail[^>]*url=["']([^"']+)["']/.exec(b);
    let title = unxml(t[1]);
    if (s) title = title.replace(/ - [^-]+$/, "");
    const img = im ? unxml(im[1]).replace("http://", "https://").replace("/standard/240/", "/standard/464/") : "";
    out.push({ title: title, link: unxml(l[1]), src: s ? unxml(s[1]) : "", img: img });
  }
  return out;
}
async function sendNews(env, f, it, h) {
  const data = { id: "news:" + h, type: "news", cat: f.cat, title: it.title, body: it.src || f.src, url: it.link, image: it.img };
  const notification = { title: it.title, body: it.src || f.src };
  if (it.img) notification.image = it.img;
  return sendTopic(env, f.topic, data, 21600, { channel: "news", tag: data.id, notification: notification });
}
// opts: { force: usisubiri muda, replay: tuma habari ya juu ya "breaking" hata kama imeonekana (kwa majaribio) }
async function newsTick(env, opts) {
  opts = opts || {};
  const stats = { job: "news", feeds: [], note: "" };
  if (!env.FCM_SERVICE_ACCOUNT) { stats.note = "no_fcm_service_account"; return stats; }
  const st = kv(env);
  const every = Math.max(120, parseInt(env.NEWS_POLL_SECS || "600", 10) || 600);
  if (!opts.force && Date.now() - parseInt((await st.get("news:last")) || "0", 10) < every * 1000) { stats.note = "waiting"; return stats; }
  await st.put("news:last", String(Date.now()), 3600);
  for (const f of NEWS) {
    const fs = { key: f.key, items: 0, fresh: 0, sent: 0, bootstrap: false };
    stats.feeds.push(fs);
    try {
      const r = await fetch(f.url, { headers: { "user-agent": "Mozilla/5.0" } });
      if (!r.ok) { fs.err = "http " + r.status; continue; }
      const items = parseRss(await r.text()).slice(0, 8);
      fs.items = items.length;
      const init = await st.get("news:init:" + f.key);
      const fresh = [];
      for (const it of items) {
        const h = (await sha(it.link)).slice(0, 24);
        const k = "news:seen:" + f.key + ":" + h;
        if (!(await st.get(k))) fresh.push({ it: it, k: k, h: h });
      }
      for (const x of fresh) await st.put(x.k, "1", 259200);
      fs.fresh = fresh.length;
      let toSend = fresh;
      if (!init) { await st.put("news:init:" + f.key, "1", 2592000); fs.bootstrap = true; toSend = []; } // mara ya kwanza: weka alama tu
      if (opts.replay && f.key === "breaking" && items[0]) toSend = [{ it: items[0], h: "replay" + Date.now() }];
      if (!toSend.length) continue;
      if (!opts.force && Date.now() - parseInt((await st.get("news:gap:" + f.key)) || "0", 10) < f.gap * 1000) continue;
      let sent = 0;
      for (const x of toSend) {
        if (sent >= f.max) break;
        await sendNews(env, f, x.it, x.h);
        sent++;
      }
      fs.sent = sent;
      if (sent) await st.put("news:gap:" + f.key, String(Date.now()), 7200);
    } catch (e) { fs.err = String(e && e.message || e).slice(0, 100); }
  }
  return stats;
}

// ---------- Admin ----------
const AUD = { all: "all_users", announcements: "announcements", football: "football", goals: "football_goals",
  news: "news", tanzania: "news_tanzania", sports: "news_sports", football_news: "news_football", technology: "news_technology" };
function okLink(l) {
  if (!l) return true;
  if (/^rlg:\/\/(match\/\d{1,12}|notifications|downloads|settings|announcement(\/[\w-]{1,40})?)$/.test(l)) return true;
  return /^https:\/\/[^\s]{3,2000}$/.test(l);
}
const ADMIN_HTML = '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>RLG Admin</title>' +
  '<style>body{font-family:sans-serif;background:#0b0b0d;color:#fff;max-width:480px;margin:auto;padding:16px}input,select,textarea,button{width:100%;box-sizing:border-box;margin:6px 0 12px;padding:12px;border-radius:10px;border:1px solid #333;background:#1a1a1e;color:#fff;font-size:16px}button{background:#ffb300;color:#000;font-weight:700;border:0}button.g{background:#2a2a30;color:#ffb300}pre{white-space:pre-wrap;color:#9c9}</style>' +
  '<h2>Rahim Lux Go — Admin</h2>' +
  '<input id=tk type=password placeholder="Admin token"><input id=ti maxlength=120 placeholder="Title"><textarea id=bo rows=3 maxlength=500 placeholder="Message"></textarea>' +
  '<input id=im placeholder="Image URL (https, optional)"><input id=li placeholder="Deep link (https://... or rlg://notifications, optional)">' +
  '<select id=au><option value=all>All users</option><option value=announcements>Announcements subscribers</option><option value=football>Football followers</option><option value=goals>Football goals followers</option><option value=news>News: breaking</option><option value=tanzania>News: Tanzania</option><option value=sports>News: Sports</option><option value=football_news>News: Football</option><option value=technology>News: Technology</option></select>' +
  '<input id=tp placeholder="Custom topic (optional, overrides audience)"><button onclick=go()>Send notification</button>' +
  '<h3>Diagnostics</h3><button class=g onclick="run(\'news\')">Run news check now</button><button class=g onclick="run(\'news_replay\')">Send latest BBC headline (test news push)</button>' +
  '<button class=g onclick="run(\'football\')">Run football check now</button><button class=g onclick="run(\'football_demo\')">Send TEST goal alert</button><pre id=out></pre>' +
  '<script>function H(){return{"content-type":"application/json",authorization:"Bearer "+document.getElementById("tk").value}}async function post(u,b){var o=document.getElementById("out");o.textContent="...";try{var r=await fetch(u,{method:"POST",headers:H(),body:JSON.stringify(b)});o.textContent=r.status+" "+await r.text()}catch(e){o.textContent=e}}' +
  'function go(){post("/admin/send",{title:document.getElementById("ti").value,message:document.getElementById("bo").value,image:document.getElementById("im").value,link:document.getElementById("li").value,audience:document.getElementById("au").value,topic:document.getElementById("tp").value})}function run(j){post("/admin/run",{job:j})}</script>';

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const post = request.method === "POST";
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: { "access-control-allow-origin": "*", "access-control-allow-headers": "x-app-token, authorization, content-type" } });
    }

    if (path === "/admin" && request.method === "GET") {
      return new Response(ADMIN_HTML, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
    }
    if ((path === "/admin/send" || path === "/admin/run") && post) {
      const auth = (request.headers.get("authorization") || "").replace(/^Bearer /, "");
      if (!env.ADMIN_TOKEN || !ctEq(auth, env.ADMIN_TOKEN)) return reply({ ok: false, error: "unauthorized" }, 401);
      let b;
      try { b = await request.json(); } catch (e) { return reply({ ok: false, error: "bad_json" }, 400); }
      if (path === "/admin/run") {
        if (b.job === "news") return reply(await newsTick(env, { force: true }));
        if (b.job === "news_replay") return reply(await newsTick(env, { force: true, replay: true }));
        if (b.job === "football") return reply(await footballTick(env, { force: true }));
        if (b.job === "football_demo") {
          const id = "demo" + Date.now();
          const title = "[TEST] GOAL! Test FC 1-0 Demo United";
          const res = await sendTopic(env, "football_goals", { id: "fb:" + id + ":goal:1-0", type: "football", event: "goal", match_id: "0", scope: "global",
            lg: "TEST", h: "Test FC", a: "Demo United", hg: 1, ag: 0, min: 12, st: "1H", title: title, body: "Admin test" }, 300,
          { channel: "football_goals", tag: "fb:" + id, notification: { title: title, body: "Admin test" } });
          return reply({ ok: res.ok, status: res.status, error: res.text, topic: "football_goals" }, res.ok ? 200 : 502);
        }
        return reply({ ok: false, error: "bad_job" }, 400);
      }
      const title = String(b.title || "").trim().slice(0, 120);
      const message = String(b.message || "").trim().slice(0, 500);
      const link = String(b.link || "").trim();
      const image = String(b.image || "").trim();
      if (!title || !message) return reply({ ok: false, error: "title_and_message_required" }, 400);
      if (!okLink(link)) return reply({ ok: false, error: "bad_link" }, 400);
      if (image && !/^https:\/\/[^\s]{3,2000}$/.test(image)) return reply({ ok: false, error: "bad_image" }, 400);
      const custom = typeof b.topic === "string" && /^[A-Za-z0-9_.~%-]{1,100}$/.test(b.topic) ? b.topic : null;
      const topic = custom || AUD[b.audience];
      if (!topic) return reply({ ok: false, error: "bad_audience" }, 400);
      const id = "adm:" + Date.now();
      const notification = { title: title, body: message };
      if (image) notification.image = image;
      const res = await sendTopic(env, topic, { id: id, type: "announcement", title: title, body: message, link: link, image: image }, 86400,
        { channel: "announcements", tag: id, notification: notification });
      return reply({ ok: res.ok, topic: topic, status: res.status, error: res.text }, res.ok ? 200 : 502);
    }

    if (!appOk(request, env)) return reply({ ok: false, error: "unauthorized", matches: [] }, 401);

    if (path === "/health" && request.method === "GET") {
      const st = kv(env);
      const u = await usage(st);
      const fb = JSON.parse((await st.get("fb:state")) || "{}");
      return reply({ ok: true, version: 4, fcm: !!env.FCM_SERVICE_ACCOUNT, football: !!env.FOOTBALL_API_KEY, kv: !!env.STATE,
        admin: !!env.ADMIN_TOKEN, appToken: !!env.APP_TOKEN, time: new Date().toISOString(),
        cron_last: parseInt((await st.get("cron:last")) || "0", 10) || null, cron_err: (await st.get("cron:err")) || null,
        api_used: u.used, api_limit: limitOf(env), api_blocked: u.blocked,
        fb_last: fb.last || null, fb_live: Object.keys(fb.live || {}).length, fb_note: fb.note || null,
        news_last: parseInt((await st.get("news:last")) || "0", 10) || null });
    }
    if (path === "/device" && post) {
      let b;
      try { b = await request.json(); } catch (e) { return reply({ ok: false }, 400); }
      if (typeof b.token !== "string" || !/^[\w:.-]{20,4096}$/.test(b.token)) return reply({ ok: false, error: "bad_token" }, 400);
      await kv(env).put("dev:" + (await sha(b.token)).slice(0, 32), JSON.stringify({ lang: String(b.lang || "").slice(0, 5), ts: Date.now() }), 5184000);
      return reply({ ok: true });
    }
    if (path === "/device/delete" && post) {
      let b;
      try { b = await request.json(); } catch (e) { return reply({ ok: false }, 400); }
      if (typeof b.token !== "string" || b.token.length > 4096) return reply({ ok: false }, 400);
      await kv(env).del("dev:" + (await sha(b.token)).slice(0, 32));
      return reply({ ok: true });
    }
    if (path === "/test" && post) {
      let b;
      try { b = await request.json(); } catch (e) { return reply({ ok: false }, 400); }
      if (typeof b.token !== "string" || !/^[\w:.-]{20,4096}$/.test(b.token)) return reply({ ok: false, error: "bad_token" }, 400);
      const st = kv(env);
      const rk = "test:" + (await sha(b.token)).slice(0, 24);
      if (await st.get(rk)) return reply({ ok: false, error: "rate_limited" }, 429);
      const now = Date.now();
      const title = "Rahim Lux Go";
      const body = "Push test from your server works ✅";
      const res = await sendFcm(env, { token: b.token },
        { id: "test:" + now, type: "test", title: title, body: body, sent_at: now }, 300,
        { channel: "test", notification: { title: title, body: body } });
      if (res.ok) await st.put(rk, "1", 60); // limiter inawekwa baada ya MAFANIKIO tu
      return reply({ ok: res.ok, status: res.status, ms: res.ms, error: res.text }, res.ok ? 200 : 502);
    }

    if (path === "/scores") {
      if (!env.FOOTBALL_API_KEY) return reply({ ok: false, error: "not_configured", matches: [] }, 503);
      const tz = env.TIMEZONE || "Africa/Dar_es_Salaam";
      const today = new Intl.DateTimeFormat("en-CA", { timeZone: tz }).format(new Date());
      let date = url.searchParams.get("date") || today;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) date = today;
      const diffDays = Math.abs((Date.parse(date + "T00:00:00Z") - Date.parse(today + "T00:00:00Z")) / 86400000);
      if (!(diffDays <= 1)) date = today;
      const r = await getScores(env, date);
      if (r.error) return reply({ ok: false, error: r.quota ? "quota_exhausted" : "upstream_error", matches: [] }, 502);
      const body = Object.assign({}, r.body, { age_s: Math.max(0, Math.round((Date.now() - Date.parse(r.body.updated)) / 1000)) });
      return reply(body, 200, r.ttl);
    }
    return reply({ ok: false, error: "not_found" }, 404);
  },

  async scheduled(event, env, ctx) {
    const run = async () => {
      const st = kv(env);
      let err = "";
      try { await footballTick(env); } catch (e) { err += "football: " + String(e && e.message || e).slice(0, 120) + " "; }
      try { await newsTick(env); } catch (e) { err += "news: " + String(e && e.message || e).slice(0, 120); }
      try {
        // Heartbeat: andika kila dakika ~10 tu (KV Free: writes 1,000/siku)
        if (Date.now() - hbLast > 600000) { hbLast = Date.now(); await st.put("cron:last", String(Date.now()), 86400); }
        if (err) await st.put("cron:err", err.slice(0, 300), 86400);
      } catch (e) { /* KV imejaa/imeshindwa */ }
    };
    ctx.waitUntil(run());
  },
};

// kwa majaribio ya ndani (node)
export { footballTick, newsTick, diffEvents, parseRss, accessToken, sendFcm, getScores };
export function _clearMemo() { memo.clear(); }
