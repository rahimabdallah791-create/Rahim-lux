RAHIM LUX GO — SEVA (Cloudflare Worker): live scores + push notifications

KWA NINI SEVA?
Siri zote (API-Football key, Firebase service account, admin token) zinakaa HAPA kama Secrets.
App haina siri yoyote. Football goals na news zinagunduliwa na seva (Cron), si na app kuwa wazi.

========== A. LIVE SCORES (tayari unayo) ==========
Secret: FOOTBALL_API_KEY          Endpoint: /scores

========== B. PUSH NOTIFICATIONS ==========
1) FIREBASE (console.firebase.google.com)
   a. Add project (Analytics si lazima).
   b. Add app > Android > package name:  com.rahimlux.go   (SHA-1 haihitajiki kwa FCM)
   c. Download  google-services.json
   d. Upload faili hiyo kwenye ROOT ya repo yako ya GitHub (kando ya RahimLuxGo-vXX.zip),
      "Add file > Upload files". Build inaikopi yenyewe. HAIJAWEKWA = app inajengwa bila push (haivunjiki).
   e. Project settings > Service accounts > "Generate new private key" > inashuka faili la JSON.
      Fungua faili hilo, nakili YALIYOMO YOTE. USILIWEKE kwenye app wala GitHub.

2) CLOUDFLARE
   a. Worker yako ya scores: Edit code > bandika worker.js MPYA (ya v22) > Deploy.
   b. Settings > Variables and Secrets > Add (aina Secret):
        FCM_SERVICE_ACCOUNT = (yaliyomo yote ya JSON ya hatua 1e)
        ADMIN_TOKEN         = (nenosiri refu unalolibuni mwenyewe)
      Hiari: APP_TOKEN, LEAGUES_TOP, FOOTBALL_POLL_SECS, FOOTBALL_IDLE_SECS,
             FOOTBALL_DAILY_BUDGET, NEWS_POLL_SECS
   c. Storage & Databases > KV > Create namespace "rlg-state". Kisha Worker > Settings > Bindings >
      Add > KV namespace:  Variable name = STATE , namespace = rlg-state.
      (Bila KV, dedupe ni ya muda mfupi tu: unaweza kupata arifa mara mbili baada ya Worker kuamka upya.)
   d. Worker > Settings > Triggers > Cron Triggers > Add:   * * * * *   (kila dakika)

3) APP
   Settings > Live scores > Scores server URL = anwani ya Worker (ile ile inatumika kwa push).
   Settings > Notifications > Notification settings > Enable notifications (inaomba ruhusa).
   Kisha "Send test push" kuthibitisha FCM yote.

========== C. ADMIN (kutuma announcements) ==========
Fungua  https://JINA-LAKO.workers.dev/admin  , weka ADMIN_TOKEN, Title, Message, (Image/Link hiari),
chagua Audience: All / Football followers / Goals / News (Breaking, Tanzania, Sports, Football, Technology)
/ Announcements, au Custom topic. Deep links zinazokubalika: https://...  rlg://match/ID  rlg://notifications
rlg://downloads  rlg://settings

========== TOPICS ==========
all_users, announcements, football, football_goals, news, news_tanzania, news_sports, news_football,
news_technology, na kwa kila mechi unayoifuata: m<ID>_goal/_start/_ht/_ft/_et/_pen/_status.
App inajiandikisha/inajiondoa kulingana na Settings (hakuna topic isiyounganishwa na preferences).

========== QUOTA (muhimu) ==========
API-Football Free = maombi 100/siku, na /scores inatumia quota ile ile. Goal alerts za wakati halisi
(kila dakika 1-2) zinahitaji mpango wa kulipia. FOOTBALL_DAILY_BUDGET (chaguo-msingi 60) inazuia cron
isimalize quota yote. Kwa Free: FOOTBALL_POLL_SECS=900.
KV Free ina kikomo cha writes 1,000/siku: weka FOOTBALL_POLL_SECS angalau 300 kwenye mpango wa bure.
News haitumii quota ya API-Football (BBC/Google News RSS).

========== UKAGUZI WA HARAKA (v25) ==========
GET https://JINA-LAKO.workers.dev/health   -> inaonyesha {"version":3,"fcm":true,"kv":true,"admin":true,...}
  version 3 = worker.js mpya. fcm:false = FCM_SERVICE_ACCOUNT haipo. kv:false = binding STATE haipo.
"Send test push" (app) -> jibu linaonyesha muda: app->server->FCM (ms) na muda wa kufika kwenye simu.

========== v26: SCORES ZIMEGANDA / HAKUNA ARIFA? (kwa nini na jinsi ya kukagua) ==========
SABABU YA MINUTES KUGANDA: quota ya API-Football (Free = 100/siku) iliisha. Seva ya zamani ilitoa data ya zamani
bila alama, na app ikaonyesha "updated" mpya. Sasa:
  - Maombi yote ya API (scores + cron) yanahesabiwa pamoja (API_DAILY_LIMIT, chaguo-msingi 90) na kusambazwa siku nzima.
  - Quota ikiisha seva inaweka alama stale/quota; app inaonyesha "delayed data" na minutes zinaendelea kwa makadirio (~67').
  - Free plan haiwezi kutoa minutes za kila dakika. Kwa live ya kweli: mpango wa kulipia + API_DAILY_LIMIT=7000.
UKAGUZI:  https://JINA-LAKO.workers.dev/health   -> cron_last (null = Cron Trigger haijawekwa!), cron_err, kv, fcm,
          api_used / api_limit / api_blocked, fb_note, fb_live, news_last.
ADMIN (/admin > Diagnostics): "Run news check now", "Send latest BBC headline" (jaribio la news push),
          "Run football check now", "Send TEST goal alert" (jaribio la topic football_goals).
