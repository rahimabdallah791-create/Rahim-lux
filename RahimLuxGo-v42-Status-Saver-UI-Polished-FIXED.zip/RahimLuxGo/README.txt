RAHIM LUX GO v29 - Android browser (Kotlin + WebView)
Mpya v29: matangazo halisi ya AdMob (IDs zako kwenye res/values/ads.xml).
Android Studio: Open folda hii > Run.


WEATHER AS A SEPARATE WORKER
- Deploy backend/weather-worker.js as a NEW Cloudflare Worker; do not replace backend/worker.js or your current Live Scores Worker.
- Add OPENWEATHER_API_KEY as a secret on the new Weather Worker.
- Optionally add APP_TOKEN as a secret; if set, enter the same value in the app's Weather access token setting.
- In app Settings > Weather, set Weather server URL to the new Worker URL. Live Scores keeps using its existing Scores server URL.
- Optional: bind a KV namespace named STATE for weather/geocoding cache.


STANDINGS SEPARATE WORKER (v32 source update)
- Default Standings Worker URL: https://standings.rahimabdallah791.workers.dev
- App requests /standings?league=epl, /standings?league=nbc, etc. Do not add /standings to the URL saved in Settings.
- In Settings > Standings server, edit the URL or enter Standings access token if APP_TOKEN is configured on that Worker.
- Live Scores continues using its own Scores server URL and is not changed by this setting.
- This ZIP is Android source code; build a new APK to install the updated Settings screen.


STANDINGS RESPONSE COMPATIBILITY (v34)
- Home standings UI supports both legacy rows and the Worker response format groups[].table with rank/played/win/draw/lose/goalsDiff/points.


V37 additions: estimated data-saved counter, text-focused Reader mode, save page offline, and offline pages list. Offline saves are text-focused copies and do not preserve all original images/scripts; data saved is an estimate based on blocked requests.


V39 RAHIM LUX AI
- AI assistant menu entry uses the configured Cloudflare Worker URL: https://obama.rahimabdallah791.workers.dev/chat
- Worker must accept POST /chat JSON fields message, action and pageText, and return JSON {"ok":true,"answer":"..."}.
- The OpenAI API key must remain stored as a Cloudflare Worker Secret named OPENAI_API_KEY. It is not embedded in this Android app.
- AI page actions send extracted page text (up to 8,000 characters) to the Worker when Ask page, Summarize or Kiswahili is selected. Review the page content before using this feature on private pages.
- This ZIP is source code; build and test an APK before installing or distributing.

V41 AI EVERYWHERE - SELECTED TEXT
- The floating ✨ AI button remains available from the browser screen.
- Long-press page text and, when WebView exposes a text selection, choose Ask AI, Explain simply, Translate to Kiswahili, or Summarize.
- Selected text is placed into the AI prompt for the user to review and send. Selection is limited to 5,000 characters.
- This feature sends selected text to the configured Cloudflare Worker only after the user chooses an action and sends the prompt. Avoid sending passwords or private information.
- Build and test on a real Android device: text selection behavior varies by Android System WebView version.
