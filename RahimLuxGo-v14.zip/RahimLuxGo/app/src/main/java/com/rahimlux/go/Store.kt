package com.rahimlux.go

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Bookmarks, history, Home sites, tabs na settings — zinahifadhiwa kwenye simu. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("rahimluxgo", Context.MODE_PRIVATE)

    private val betting = listOf(
        "Betway" to "https://www.betway.co.tz",
        "Betpawa" to "https://www.betpawa.co.tz",
        "SportyBet" to "https://www.sportybet.com",
        "1win" to "https://1win.com"
    )

    private val defaultSites = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://m.youtube.com",
        "Facebook" to "https://m.facebook.com",
        "Instagram" to "https://www.instagram.com",
        "WhatsApp" to "https://web.whatsapp.com",
        "TikTok" to "https://www.tiktok.com",
        "Wikipedia" to "https://en.wikipedia.org",
        "Mwananchi" to "https://www.mwananchi.co.tz"
    ) + betting

    @Volatile private var adOff: Set<String> = readSet("adoff")

    init {
        if (p.getInt("sv", 1) < 2) {
            if (p.contains("sites")) {
                val cur = read("sites")
                write("sites", cur + betting.filter { b -> cur.none { it.second == b.second } })
            }
            p.edit().putInt("sv", 2).apply()
        }
    }

    var lang: String
        get() = p.getString("lang", "en") ?: "en"
        set(v) = p.edit().putString("lang", v).apply()

    /** "google" | "ddg" | "bing" | "yahoo" */
    var engine: String
        get() = p.getString("eng", "google") ?: "google"
        set(v) = p.edit().putString("eng", v).apply()

    var desktop: Boolean
        get() = p.getBoolean("desk", false)
        set(v) = p.edit().putBoolean("desk", v).apply()

    var thirdCookies: Boolean
        get() = p.getBoolean("tc", true)
        set(v) = p.edit().putBoolean("tc", v).apply()

    var dataSaver: Boolean
        get() = p.getBoolean("ds", false)
        set(v) = p.edit().putBoolean("ds", v).apply()

    var adblock: Boolean
        get() = p.getBoolean("ab", true)
        set(v) = p.edit().putBoolean("ab", v).apply()

    var darkWeb: Boolean
        get() = p.getBoolean("dw", false)
        set(v) = p.edit().putBoolean("dw", v).apply()

    var blockLogJson: String
        get() = p.getString("blog", "{}") ?: "{}"
        set(v) = p.edit().putString("blog", v).apply()

    var tabsJson: String
        get() = p.getString("tabs", "{}") ?: "{}"
        set(v) = p.edit().putString("tabs", v).apply()

    fun resetBlocked() = p.edit().putInt("blocked", 0).apply()

    val blocked: Int get() = p.getInt("blocked", 0)

    @Synchronized
    fun addBlocked() = p.edit().putInt("blocked", blocked + 1).apply()

    /** Ad-block imezimwa kwa tovuti hii? (thread-safe, inatumika kwenye background thread) */
    fun isAdOff(host: String?): Boolean = host != null && adOff.contains(host.removePrefix("www."))

    /** Rudisha true ikiwa sasa ad-block IMEZIMWA kwa tovuti hii. */
    fun toggleAdOff(host: String): Boolean {
        val h = host.removePrefix("www.")
        val nowOff = h !in adOff
        adOff = if (nowOff) adOff + h else adOff - h
        p.edit().putString("adoff", JSONArray(adOff.toList()).toString()).apply()
        return nowOff
    }

    fun bookmarks() = read("bm")
    fun history() = read("hi")
    fun sites(): List<Pair<String, String>> = if (p.contains("sites")) read("sites") else defaultSites

    fun addBookmark(title: String, url: String) =
        write("bm", listOf(title to url) + read("bm").filter { it.second != url })

    fun addHistory(title: String, url: String) =
        write("hi", (listOf(title to url) + read("hi").filter { it.second != url }).take(200))

    fun addSite(name: String, url: String) =
        write("sites", sites().filter { it.second != url } + (name to url))

    fun removeSite(url: String) = write("sites", sites().filter { it.second != url })

    fun clearHistory() = p.edit().remove("hi").apply()

    private fun readSet(k: String): Set<String> {
        val a = JSONArray(p.getString(k, "[]"))
        return (0 until a.length()).map { a.getString(it) }.toSet()
    }

    private fun read(k: String): List<Pair<String, String>> {
        val a = JSONArray(p.getString(k, "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            o.getString("t") to o.getString("u")
        }
    }

    private fun write(k: String, l: List<Pair<String, String>>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.first).put("u", it.second)) }
        p.edit().putString(k, a.toString()).apply()
    }
}
