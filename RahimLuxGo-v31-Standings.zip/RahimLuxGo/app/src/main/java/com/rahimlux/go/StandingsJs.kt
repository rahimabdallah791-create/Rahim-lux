package com.rahimlux.go

/** JavaScript ya "Msimamo wa ligi" kwenye Home. Data inaingia kupitia textContent (si innerHTML). */
object StandingsJs {
    const val CODE = """
function stEl(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined&&x!==null)e.textContent=x;return e}
function stRead(k){try{return JSON.parse(localStorage.getItem('rlg-std-'+k)||'null')}catch(e){return null}}
function stWrite(k,b){try{localStorage.setItem('rlg-std-'+k,JSON.stringify({t:Date.now(),b:b}))}catch(e){}}
function stHm(ts){var d=new Date(ts);var h=d.getHours(),m=d.getMinutes();return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
function stSelect(k){STD.sel=k;try{localStorage.setItem('rlg-std-sel',k)}catch(e){}stRender();stLoad(k)}
function stLoad(k){
 var c=stRead(k);if(c&&Date.now()-c.t<1800000)return;
 if(!STD.base||STD.busy[k])return;STD.busy[k]=1;
 var h={};if(STD.token)h['X-App-Token']=STD.token;
 fetch(STD.base+'/standings?league='+encodeURIComponent(k),{headers:h})
  .then(function(r){return r.json()})
  .then(function(j){STD.busy[k]=0;if(j&&j.ok&&j.groups){stWrite(k,j);STD.err[k]=''}else{STD.err[k]=(j&&j.error)||'fail'}if(STD.sel===k)stRender()})
  .catch(function(){STD.busy[k]=0;STD.err[k]='network';if(STD.sel===k)stRender()})}
function stRender(){
 var chips=document.getElementById('stc'),box=document.getElementById('std');if(!chips||!box||!STD.cfg)return;
 chips.innerHTML='';
 STD.leagues.forEach(function(l){var bt=stEl('button','sc2'+(l.k===STD.sel?' on':''),l.s);bt.type='button';bt.onclick=function(){stSelect(l.k)};chips.appendChild(bt)});
 box.innerHTML='';
 var c=stRead(STD.sel),err=STD.err[STD.sel]||'';
 if(!c){box.appendChild(stEl('div','ste',err==='plan_limit'?STD.i.plan:err==='quota_exhausted'?STD.i.quota:err==='not_configured'?STD.i.setup:err?STD.i.fail:STD.i.load));return}
 var b=c.b;
 var meta=b.name+' \u00b7 '+b.country+(b.season?' \u00b7 '+b.season:'')+' \u00b7 '+STD.i.upd+stHm(Date.parse(b.updated)||c.t);
 if(b.stale||err||Date.now()-c.t>86400000)meta+=' \u00b7 \u26a0 '+STD.i.old;
 box.appendChild(stEl('div','stm',meta));
 var zones={};
 (b.groups||[]).forEach(function(g){
  if(g.name)box.appendChild(stEl('div','stg',g.name));
  var hd=stEl('div','str sth');['#',STD.i.team,'P','W','D','L','GD','Pts'].forEach(function(x,i){hd.appendChild(stEl('span',i===1?'stt':'',x))});box.appendChild(hd);
  (g.rows||[]).forEach(function(r){
   var row=stEl('div','str'+(r.zone?' z-'+r.zone:''));
   if(r.zone)zones[r.zone]=1;
   [r.pos,r.team,r.p,r.w,r.d,r.l,(r.gd>0?'+':'')+r.gd,r.pts].forEach(function(x,i){row.appendChild(stEl('span',i===1?'stt':(i===7?'stp':''),x))});
   box.appendChild(row)})});
 var zl=[['ucl',STD.i.zUcl],['uel',STD.i.zUel],['uecl',STD.i.zUecl],['promo',STD.i.zPromo],['rel',STD.i.zRel]].filter(function(z){return zones[z[0]]});
 if(zl.length){var lg=stEl('div','stl');zl.forEach(function(z){lg.appendChild(stEl('span','zc-'+z[0],'\u25cf '+z[1]))});box.appendChild(lg)}
}
try{var sv=localStorage.getItem('rlg-std-sel');if(sv&&STD.leagues.some(function(l){return l.k===sv}))STD.sel=sv}catch(e){}
STD.err={};STD.busy={};
stRender();
stLoad(STD.sel);if(STD.sel!=='epl')stLoad('epl');if(STD.sel!=='nbc')stLoad('nbc');
"""
}
