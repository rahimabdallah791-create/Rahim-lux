KIVINJARI - Android browser (Kotlin + WebView)

1. Fungua Android Studio > Open > chagua folda hii (Kivinjari).
2. Subiri Gradle sync imalize.
3. Unganisha simu (USB debugging) au tumia emulator > bonyeza Run.
4. APK: Build > Build Bundle(s)/APK(s) > Build APK(s).

Ad-block list: app/src/main/java/com/kivinjari/app/AdBlock.kt
