package com.kivinjari.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private val home = "https://duckduckgo.com"
    private lateinit var store: Store
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var tabsBtn: Button
    private val tabs = mutableListOf<WebView>()
    private var cur = 0
    private val web get() = tabs[cur]

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) load(said)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        urlBar = findViewById(R.id.url)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.container)
        tabsBtn = findViewById(R.id.tabs)

        urlBar.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                load(urlBar.text.toString()); true
            } else false
        }
        findViewById<View>(R.id.mic).setOnClickListener { startVoice() }
        findViewById<View>(R.id.back).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.fwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.reload).setOnClickListener { web.reload() }
        tabsBtn.setOnClickListener { showTabs() }
        findViewById<View>(R.id.menu).setOnClickListener { showMenu(it) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    web.canGoBack() -> web.goBack()
                    tabs.size > 1 -> closeTab()
                    else -> finish()
                }
            }
        })

        newTab(intent?.data?.toString() ?: home)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String) {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = store.dataSaver
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false)

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val host = r.url.host ?: return null
                if (store.adblock && AdBlock.isBlocked(host)) return empty()
                if (store.dataSaver && AdBlock.isHeavyMedia(r.url.path ?: "")) return empty()
                return null
            }

            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                if (v === web) { urlBar.setText(u); progress.visibility = View.VISIBLE }
            }

            override fun onPageFinished(v: WebView, u: String) {
                if (v === web) progress.visibility = View.GONE
                if (u.startsWith("http")) store.addHistory(v.title ?: u, u)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === web) progress.progress = p
            }
        }
        tabs.add(w)
        show(tabs.size - 1)
        w.loadUrl(url)
    }

    private fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    private fun show(i: Int) {
        cur = i
        container.removeAllViews()
        container.addView(web, FrameLayout.LayoutParams(-1, -1))
        urlBar.setText(web.url ?: "")
        tabsBtn.text = tabs.size.toString()
    }

    private fun closeTab() {
        if (tabs.size == 1) { web.loadUrl(home); return }
        container.removeAllViews()
        tabs.removeAt(cur).destroy()
        show(minOf(cur, tabs.size - 1))
    }

    private fun load(input: String) {
        val t = input.trim()
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(" ") && t.contains(".") -> "https://$t"
            else -> "$home/?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
        urlBar.clearFocus()
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "sw-TZ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Sema unachotafuta…")
        }
        try { voice.launch(i) } catch (e: Exception) {
            toast("Voice search haipatikani kwenye simu hii")
        }
    }

    private fun showTabs() {
        val names = tabs.map { it.title?.take(40) ?: it.url ?: "Tab" } + "＋ Tab mpya"
        AlertDialog.Builder(this).setTitle("Tabs")
            .setItems(names.toTypedArray()) { _, i ->
                if (i == tabs.size) newTab(home) else show(i)
            }.show()
    }

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Tab mpya")
        m.menu.add(0, 2, 0, "Funga tab hii")
        m.menu.add(0, 3, 0, "⭐ Hifadhi bookmark")
        m.menu.add(0, 4, 0, "Bookmarks")
        m.menu.add(0, 5, 0, "History")
        m.menu.add(0, 6, 0, (if (store.dataSaver) "✓ " else "") + "Data saver")
        m.menu.add(0, 7, 0, (if (store.adblock) "✓ " else "") + "Ad-block")
        m.menu.add(0, 8, 0, "Futa data zote")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newTab(home)
                2 -> closeTab()
                3 -> web.url?.let { u -> store.addBookmark(web.title ?: u, u); toast("Imehifadhiwa") }
                4 -> pick("Bookmarks", store.bookmarks())
                5 -> pick("History", store.history())
                6 -> {
                    store.dataSaver = !store.dataSaver
                    tabs.forEach { t -> t.settings.blockNetworkImage = store.dataSaver }
                    web.reload()
                    toast(if (store.dataSaver) "Data saver imewashwa" else "Data saver imezimwa")
                }
                7 -> {
                    store.adblock = !store.adblock
                    web.reload()
                    toast(if (store.adblock) "Ad-block imewashwa" else "Ad-block imezimwa")
                }
                8 -> {
                    store.clearHistory()
                    tabs.forEach { t -> t.clearCache(true); t.clearHistory() }
                    CookieManager.getInstance().removeAllCookies(null)
                    WebStorage.getInstance().deleteAllData()
                    toast("Data imefutwa")
                }
            }
            true
        }
        m.show()
    }

    private fun pick(title: String, items: List<Pair<String, String>>) {
        if (items.isEmpty()) { toast("Hakuna kitu bado"); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(items.map { it.first.take(40) + "\n" + it.second.take(50) }.toTypedArray()) { _, i ->
                web.loadUrl(items[i].second)
            }.show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
