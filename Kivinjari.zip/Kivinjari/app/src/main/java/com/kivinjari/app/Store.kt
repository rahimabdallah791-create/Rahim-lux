package com.kivinjari.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Bookmarks, history na settings — zinahifadhiwa kwenye simu. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("kivinjari", Context.MODE_PRIVATE)

    var dataSaver: Boolean
        get() = p.getBoolean("ds", false)
        set(v) = p.edit().putBoolean("ds", v).apply()

    var adblock: Boolean
        get() = p.getBoolean("ab", true)
        set(v) = p.edit().putBoolean("ab", v).apply()

    fun bookmarks() = read("bm")
    fun history() = read("hi")

    fun addBookmark(title: String, url: String) =
        write("bm", listOf(title to url) + read("bm").filter { it.second != url })

    fun addHistory(title: String, url: String) =
        write("hi", (listOf(title to url) + read("hi").filter { it.second != url }).take(200))

    fun clearHistory() = p.edit().remove("hi").apply()

    private fun read(k: String): List<Pair<String, String>> {
        val a = JSONArray(p.getString(k, "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            o.getString("t") to o.getString("u")
        }
    }

    private fun write(k: String, l: List<Pair<String, String>>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.first).put("u", it.second)) }
        p.edit().putString(k, a.toString()).apply()
    }
}
